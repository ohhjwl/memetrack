# MemeTrack

Live memecoin terminal. Trending coins, a full candle chart, paper trading, a wallet tracker, and a Buy button that opens Axiom, Pump, or Fomo.

## Run it

```bash
npm install
npm run dev
```

Then open http://localhost:8080

## What’s in the box

- Click a coin for the full candle chart (timeframes, volume, OHLC, moving averages)
- Settings gear: pick the primary venue (Axiom, Pump, or Fomo). The chart Buy button opens that venue. There is no referral program.
- Paper trading, the rug check, and the live tape are free.
- Learn is eight modules with quizzes, flashcards, and paper drills. It is free for 30 minutes of use, then it stops.
- Plans: Starter $5/mo (first 3 modules and quizzes), Desk $10/mo (full course, cards, drills), Unlimited $20/mo (adds the review log). 3 months is 10% off, 6 months is 15% off, a year is 20% off. Card checkout is not connected. An admin can set the plan.
- The first account is the admin. Creating an account requires joining the Discord. Admin lists every account, and can ban a member, clear a bio, or grant free Learn.
- Paper trading starts on. It is a $10,000 practice account with an equity curve, shareable PnL cards, take-profit and stop-loss, and quick buy/sell. It stays free.
- Pulse columns split new, almost-bonded, and graduated coins. Bonding percent on pump coins is an estimate
- Live tape of recent buys and sells, plus new launches. Sound is off until you turn it on. Copy turns a tape buy into a paper trade
- Wallet tracker for a Solana address, with copy filters. A wallet buy can raise an alert
- Theme presets: Dark, Light, Purple, Blue, Amber, Mint
- Download in the header installs it as an app on iPhone, Mac, or Windows
- A Solana wallet in the browser can sign a Jupiter swap. If none is injected, use the venue button. No keys are stored and no extra fee is added

Paper trades, watchlist, theme, venue, wallets, and alerts stay on the device. Nothing in paper is a real order.

Market data comes from DexScreener. Chart candles come from the pool feed when it answers; otherwise the chart draws an estimated path from the live price.
Safety is a note only. Risky and Bad coins can still be paper-bought in one tap.
