import { createFileRoute, Link } from "@tanstack/react-router";
import { SignedIn, SignedOut } from "@/lib/auth/gates";
import { PricingBoard } from "@/components/pricing-board";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
});

function PricingPage() {
  return (
    <div className="landing">
      <div className="landing-stars" />
      <div className="landing-glow" />
      <nav className="relative z-10 mx-auto flex h-16 w-full max-w-6xl items-center gap-4 px-5">
        <Link to="/" className="text-sm font-semibold tracking-tight">
          MemeTrack
        </Link>
        <Link to="/" className="ml-auto text-sm text-white/70">
          Home
        </Link>
        <SignedOut>
          <Link to="/login" className="text-sm text-white/80">
            Log in
          </Link>
        </SignedOut>
        <SignedIn>
          <Link to="/app" className="rounded-full bg-white px-3 py-1.5 text-sm font-semibold text-black">
            Open terminal
          </Link>
        </SignedIn>
      </nav>
      <main className="relative z-10 mx-auto max-w-5xl px-5 pb-24 pt-10">
        <p className="text-center text-sm text-white/55">Pricing</p>
        <h1 className="mt-3 text-center text-4xl font-semibold tracking-tight sm:text-6xl">Learn, after the free desk.</h1>
        <p className="mx-auto mt-4 max-w-xl text-center text-sm leading-relaxed text-white/65">
          Paper trading, the rug check, and the tape stay free. Learn is free for 30 minutes of use, then it stops. Starter is highly limited at $5. Desk is limited at $10. Unlimited is $20.
        </p>
        <div className="mt-8">
          <PricingBoard />
        </div>
      </main>
    </div>
  );
}
