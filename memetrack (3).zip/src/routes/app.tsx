import { createFileRoute } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Discover } from "@/components/discover";

export const Route = createFileRoute("/app")({
  component: AppHome,
});

function AppHome() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return <div className="grid h-dvh place-items-center bg-bg text-sm text-muted">Loading account…</div>;
  }
  if (!user) return <RedirectToSignIn />;
  return <Discover />;
}
