import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { confirmDiscord, getMe } from "@/lib/accounts";
import { useDiscordJoin } from "@/components/discord-join";

export const Route = createFileRoute("/login")({
  component: Login,
});

function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"create" | "enter">("create");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const discord = useDiscordJoin();
  const loadMe = useServerFn(getMe);
  const markDiscord = useServerFn(confirmDiscord);
  const creating = mode === "create";
  const canCreate = !creating || discord.ready;

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (creating && !discord.ready) {
      setError("Join the Discord before creating an account.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      if (creating) {
        const result = await authClient.signUp.email({ email, password, name: name || email.split("@")[0] || "Trader" });
        if (result.error) throw new Error(result.error.message || "Could not create the account");
        await loadMe();
        await markDiscord();
      } else {
        const result = await authClient.signIn.email({ email, password });
        if (result.error) throw new Error(result.error.message || "Could not sign in");
      }
      await navigate({ to: "/app" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="landing grid min-h-dvh place-items-center px-4 py-10">
      <div className="relative z-10 w-full max-w-sm">
        <Link to="/" className="text-sm text-white/60">
          MemeTrack
        </Link>
        <h1 className="mt-6 text-3xl font-semibold tracking-tight">{creating ? "Create an account" : "Log in"}</h1>
        <p className="mt-2 text-sm text-white/60">
          {creating ? "Join the Discord first. The account is not created until you do." : "Paper, the rug check, and the tape are waiting."}
        </p>
        <form onSubmit={submit} className="mt-6 space-y-2">
          {creating ? (
            <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Name" className="h-11 w-full rounded-full bg-white/10 px-4 text-sm outline-none" />
          ) : null}
          <input value={email} onChange={(event) => setEmail(event.target.value)} type="email" required placeholder="Email" className="h-11 w-full rounded-full bg-white/10 px-4 text-sm outline-none" />
          <input value={password} onChange={(event) => setPassword(event.target.value)} type="password" required minLength={8} placeholder="Password" className="h-11 w-full rounded-full bg-white/10 px-4 text-sm outline-none" />
          {creating ? (
            <div className="rounded-2xl border border-white/15 bg-white/5 p-3 text-left">
              <p className="text-sm font-medium">Join the Discord</p>
              <p className="mt-1 text-xs leading-relaxed text-white/55">Open the invite, join the server, then confirm. Create stays off until then.</p>
              <a
                href={discord.invite}
                target="_blank"
                rel="noreferrer"
                onClick={discord.markOpened}
                className="mt-3 grid h-10 w-full place-items-center rounded-full bg-white text-sm font-semibold text-black"
              >
                {discord.opened ? "Invite opened" : "Open the invite"}
              </a>
              <label className="mt-3 flex items-start gap-2 text-sm text-white/80">
                <input
                  type="checkbox"
                  className="mt-1"
                  checked={discord.agreed}
                  disabled={!discord.opened}
                  onChange={(event) => discord.setAgreed(event.target.checked)}
                />
                I joined the MemeTrack Discord
              </label>
            </div>
          ) : null}
          {error ? <p className="text-sm text-red-300">{error}</p> : null}
          <button type="submit" disabled={busy || !canCreate} className="landing-cta w-full disabled:opacity-40">
            {busy ? "Working…" : creating ? "Create account" : "Log in"}
          </button>
        </form>
        <button
          type="button"
          onClick={() => {
            setMode(creating ? "enter" : "create");
            setError("");
          }}
          className="mt-3 text-sm text-white/60"
        >
          {creating ? "Already have an account? Log in" : "Need an account? Create one"}
        </button>
        <div className="mt-6 space-y-2">
          {GROK_PROVIDERS.map((provider) => (
            <button
              key={provider.providerId}
              type="button"
              disabled={creating && !discord.ready}
              onClick={() => {
                if (creating && !discord.ready) {
                  setError("Join the Discord before creating an account.");
                  return;
                }
                signIn(provider.providerId, { callbackURL: "/app" });
              }}
              className="h-11 w-full rounded-full border border-white/15 text-sm disabled:opacity-40"
            >
              Continue with {provider.label}
            </button>
          ))}
          {creating ? <p className="text-center text-xs text-white/40">Google and X also wait until the Discord box is checked.</p> : null}
        </div>
      </div>
    </main>
  );
}
