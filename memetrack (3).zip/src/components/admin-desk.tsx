import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { listAccounts, moderateAccount, saveProfile, type AccountRow, type Me } from "@/lib/accounts";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export function ProfileCard({ me, onSaved }: { me: Me; onSaved: (me: Me) => void }) {
  const [handle, setHandle] = useState(me.handle);
  const [bio, setBio] = useState(me.bio);
  const save = useServerFn(saveProfile);
  return (
    <section className="mx-auto mt-3 w-full max-w-xl rounded-2xl border border-line bg-panel p-4">
      <h2 className="text-lg font-semibold">Your profile</h2>
      <p className="mt-1 text-xs text-faint">{me.email || "Signed in"} · {me.role === "admin" ? "Admin" : "Member"}</p>
      <input value={handle} onChange={(event) => setHandle(event.target.value)} placeholder="Handle" className="mt-3 h-10 w-full rounded-full bg-chip px-3 text-sm outline-none" />
      <textarea value={bio} onChange={(event) => setBio(event.target.value)} placeholder="Bio" rows={3} className="mt-2 w-full rounded-2xl bg-chip px-3 py-2 text-sm outline-none" />
      <button
        type="button"
        onClick={() => {
          void save({ data: { handle, bio } }).then(() => {
            onSaved({ ...me, handle, bio });
            toast("Profile saved");
          });
        }}
        className="mt-2 h-9 rounded-full bg-fg px-3 text-sm font-semibold text-bg"
      >
        Save profile
      </button>
    </section>
  );
}

export function AdminDesk({ onClose }: { onClose: () => void }) {
  const [rows, setRows] = useState<AccountRow[]>([]);
  const [error, setError] = useState("");
  const load = useServerFn(listAccounts);
  const mod = useServerFn(moderateAccount);

  function refresh() {
    void load()
      .then(setRows)
      .catch(() => setError("Only an admin can open this."));
  }

  useEffect(() => {
    refresh();
  }, [load]);

  function act(userId: string, patch: { banned?: boolean; plan?: string; clearBio?: boolean }) {
    void mod({ data: { userId, ...patch } }).then(() => {
      toast("Updated");
      refresh();
    }).catch(() => toast("Could not update that account"));
  }

  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-3">
      <div className="mx-auto flex max-w-3xl flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Accounts</h2>
            <p className="text-sm text-muted">The first account is the admin. Set a Learn plan, ban, or clear a bio. Paper stays free.</p>
          </div>
          <button type="button" className="text-sm text-muted" onClick={onClose}>
            Done
          </button>
        </div>
        {error ? <p className="text-sm text-down">{error}</p> : null}
        {rows.map((row) => (
          <article key={row.userId} className="rounded-2xl border border-line bg-panel p-3">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="text-sm font-semibold">{row.name}</p>
              <p className="text-xs text-faint">
                {row.role}
                {row.banned ? " · banned" : ""}
                {` · ${row.plan}`}
                {row.requestedPlan ? ` · asked ${row.requestedPlan} ${row.requestedTerm}` : ""}
              </p>
            </div>
            <p className="text-xs text-muted">{row.email}</p>
            <p className="mt-1 text-sm">{row.handle ? `@${row.handle}` : "No handle"}{row.bio ? ` — ${row.bio}` : ""}</p>
            {row.role !== "admin" ? (
              <div className="mt-2 flex flex-wrap gap-1">
                <button type="button" onClick={() => act(row.userId, { banned: !row.banned })} className="h-8 rounded-full bg-chip px-3 text-xs">
                  {row.banned ? "Unban" : "Ban"}
                </button>
                {(["free", "starter", "desk", "unlimited"] as const).map((plan) => (
                  <button key={plan} type="button" onClick={() => act(row.userId, { plan })} className={cn("h-8 rounded-full px-3 text-xs", row.plan === plan ? "bg-fg text-bg" : "bg-chip")}>
                    {plan}
                  </button>
                ))}
                <button type="button" onClick={() => act(row.userId, { clearBio: true })} className="h-8 rounded-full bg-chip px-3 text-xs">
                  Clear bio
                </button>
              </div>
            ) : null}
          </article>
        ))}
      </div>
    </div>
  );
}
