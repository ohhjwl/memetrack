import { useState } from "react";
import type { Book, CopyFilter } from "@/lib/paper";
import type { WalletEvent } from "@/lib/wallets";
import { cn, money, price, shortAddr } from "@/lib/utils";

export function WalletDesk({
  book,
  events,
  onClose,
  onAdd,
  onRemove,
  onToggleCopy,
  onFilter,
  onPick,
}: {
  book: Book;
  events: Record<string, WalletEvent[]>;
  onClose: () => void;
  onAdd: (address: string, label: string) => void;
  onRemove: (address: string) => void;
  onToggleCopy: (address: string) => void;
  onFilter: (address: string, patch: Partial<CopyFilter>) => void;
  onPick: (event: WalletEvent) => void;
}) {
  const [address, setAddress] = useState("");
  const [label, setLabel] = useState("");

  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-3">
      <div className="mx-auto flex max-w-3xl flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Wallet tracker</h2>
            <p className="text-sm text-muted">Watch a Solana wallet. Copy turns new buys into paper trades. Filters skip the ones you don't want.</p>
          </div>
          <button type="button" className="text-sm text-muted" onClick={onClose}>
            Done
          </button>
        </div>
        <form
          className="flex flex-col gap-2 rounded-2xl border border-line bg-panel p-3 sm:flex-row"
          onSubmit={(event) => {
            event.preventDefault();
            onAdd(address.trim(), label.trim());
            setAddress("");
            setLabel("");
          }}
        >
          <input
            value={label}
            onChange={(event) => setLabel(event.target.value)}
            placeholder="Name"
            className="h-10 rounded-full bg-chip px-3 text-sm outline-none placeholder:text-faint sm:w-32"
          />
          <input
            value={address}
            onChange={(event) => setAddress(event.target.value)}
            placeholder="Solana wallet"
            className="h-10 min-w-0 flex-1 rounded-full bg-chip px-3 text-sm outline-none placeholder:text-faint"
          />
          <button type="submit" className="h-10 rounded-full bg-fg px-4 text-sm font-semibold text-bg">
            Track
          </button>
        </form>
        {book.wallets.length === 0 ? <p className="text-sm text-muted">No wallets yet.</p> : null}
        {book.wallets.map((wallet) => {
          const rows = events[wallet.address] ?? [];
          const filter = wallet.filter;
          return (
            <section key={wallet.address} className="rounded-2xl border border-line bg-panel">
              <div className="flex items-center gap-2 px-3 py-3">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold">{wallet.label || "Wallet"}</div>
                  <div className="text-xs text-faint">{shortAddr(wallet.address)}</div>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleCopy(wallet.address)}
                  className={cn("h-8 rounded-full px-3 text-xs font-semibold", wallet.copy ? "bg-fg text-bg" : "bg-chip text-muted")}
                >
                  {wallet.copy ? "Copying" : "Copy"}
                </button>
                <button type="button" onClick={() => onRemove(wallet.address)} className="h-8 rounded-full bg-chip px-3 text-xs text-muted">
                  Remove
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 border-t border-line px-3 py-3 sm:grid-cols-3">
                <Field label="Min mcap" value={filter.minMcap} onChange={(value) => onFilter(wallet.address, { minMcap: value })} />
                <Field label="Min liq" value={filter.minLiq} onChange={(value) => onFilter(wallet.address, { minLiq: value })} />
                <Field label="Max age h" value={filter.maxAgeH} onChange={(value) => onFilter(wallet.address, { maxAgeH: value })} />
                <Field label="Size $" value={filter.size} onChange={(value) => onFilter(wallet.address, { size: value })} />
                <label className="col-span-2 text-xs text-faint sm:col-span-2">
                  Blacklist
                  <input
                    value={filter.blacklist}
                    onChange={(event) => onFilter(wallet.address, { blacklist: event.target.value })}
                    placeholder="symbol or mint, comma separated"
                    className="mt-1 h-9 w-full rounded-full bg-chip px-3 text-sm text-fg outline-none placeholder:text-faint"
                  />
                </label>
              </div>
              <p className="px-3 pb-2 text-xs text-faint">
                Zero means off. Size 0 uses the paper copy size. Max age only applies when a launch time is known, which wallet swaps usually lack.
              </p>
              {rows.length === 0 ? <p className="border-t border-line px-3 py-3 text-sm text-muted">No decoded swaps yet.</p> : null}
              {rows.map((row) => (
                <button
                  key={row.id}
                  type="button"
                  onClick={() => onPick(row)}
                  className="flex w-full items-center gap-2 border-t border-line px-3 py-2 text-left hover:bg-raise"
                >
                  <span className={cn("w-10 text-xs font-semibold", row.side === "buy" ? "text-up" : "text-down")}>{row.side}</span>
                  <span className="min-w-0 flex-1 truncate text-sm">{row.symbol}</span>
                  <span className="text-xs text-faint">{new Date(row.time).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}</span>
                  <span className="text-xs text-faint">{price(row.price)}</span>
                  <span className="text-sm tabular-nums">{row.usd > 0 ? money(row.usd) : "—"}</span>
                </button>
              ))}
            </section>
          );
        })}
      </div>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return (
    <label className="text-xs text-faint">
      {label}
      <input
        type="number"
        min={0}
        value={value || ""}
        placeholder="0"
        onChange={(event) => onChange(Math.max(0, Number(event.target.value) || 0))}
        className="mt-1 h-9 w-full rounded-full bg-chip px-3 text-sm text-fg outline-none placeholder:text-faint"
      />
    </label>
  );
}
