import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { MODULES, STARTER_MODULES, moduleIndex, quizId, type Module } from "@/lib/learn";
import { readProgress, saveProgress, tickLearn } from "@/lib/accounts";
import type { Me } from "@/lib/accounts";
import { FREE_LEARN_MS, clock } from "@/lib/pricing";
import { PricingBoard } from "@/components/pricing-board";
import { cn } from "@/lib/utils";

export function LearnDesk({
  me,
  onClose,
  onPaper,
  onUsed,
}: {
  me: Me;
  onClose: () => void;
  onPaper: (mission: string) => void;
  onUsed: (patch: Pick<Me, "learnUsedMs" | "learnOpen" | "plan">) => void;
}) {
  const [moduleId, setModuleId] = useState(MODULES[0]?.id ?? "");
  const [mode, setMode] = useState<"read" | "quiz" | "cards" | "review">("read");
  const [picked, setPicked] = useState<Record<number, number>>({});
  const [card, setCard] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<Record<string, boolean>>({});
  const [passed, setPassed] = useState<Record<string, boolean>>({});
  const [review, setReview] = useState<Record<string, boolean>>({});
  const load = useServerFn(readProgress);
  const save = useServerFn(saveProgress);
  const tick = useServerFn(tickLearn);
  const onUsedRef = useRef(onUsed);
  onUsedRef.current = onUsed;
  const mod = MODULES.find((item) => item.id === moduleId) ?? MODULES[0];

  useEffect(() => {
    void load().then((rows) => {
      const nextKnown: Record<string, boolean> = {};
      const nextPassed: Record<string, boolean> = {};
      const nextReview: Record<string, boolean> = {};
      for (const row of rows) {
        if (row.item_id.startsWith("card:") && row.score > 0) nextKnown[row.item_id.slice(5)] = true;
        if (row.item_id.startsWith("quiz:") && row.score >= 2) nextPassed[row.item_id.slice(5)] = true;
        if (row.item_id.startsWith("review:") && row.score > 0) nextReview[row.item_id.slice(7)] = true;
      }
      setKnown(nextKnown);
      setPassed(nextPassed);
      setReview(nextReview);
    }).catch(() => undefined);
  }, [load]);

  useEffect(() => {
    if (me.plan !== "free" || !me.learnOpen) return;
    const id = window.setInterval(() => {
      if (document.hidden) return;
      void tick({ data: 5000 }).then((next) => onUsedRef.current(next)).catch(() => undefined);
    }, 5000);
    return () => window.clearInterval(id);
  }, [me.plan, me.learnOpen, tick]);

  if (!me.learnOpen) {
    return (
      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        <Paywall used={me.learnUsedMs} onClose={onClose} />
      </div>
    );
  }

  const left = Math.max(0, FREE_LEARN_MS - me.learnUsedMs);
  const rank = mod ? moduleIndex(mod.id) : 0;
  const moduleLocked = me.plan === "starter" && rank >= STARTER_MODULES;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <h2 className="text-lg font-semibold">Learn</h2>
        <p className="text-xs text-faint">
          {me.plan === "free" ? `${clock(left)} free left` : me.plan === "starter" ? "Starter · 3 modules" : me.plan === "desk" ? "Desk" : "Unlimited"}
        </p>
        <button type="button" onClick={onClose} className="ml-auto h-9 rounded-full bg-chip px-3 text-sm text-muted">
          Done
        </button>
      </div>
      <div className="grid min-h-0 flex-1 lg:grid-cols-[260px_minmax(0,1fr)]">
        <div className="flex gap-2 overflow-x-auto border-b border-line p-3 lg:block lg:space-y-1 lg:overflow-y-auto lg:border-b-0 lg:border-r">
          {MODULES.map((item, index) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setModuleId(item.id);
                setMode("read");
                setPicked({});
                setCard(0);
                setFlipped(false);
              }}
              className={cn("shrink-0 rounded-xl px-3 py-2 text-left lg:w-full", moduleId === item.id ? "bg-fg text-bg" : "bg-raise")}
            >
              <span className="block text-sm font-semibold">
                {index + 1}. {item.title}
              </span>
              <span className={cn("mt-0.5 block text-xs", moduleId === item.id ? "opacity-70" : "text-faint")}>
                {item.minutes} min{passed[item.id] ? " · quiz passed" : ""}
                {me.plan === "starter" && index >= STARTER_MODULES ? " · Desk+" : ""}
              </span>
            </button>
          ))}
        </div>
        <div className="min-h-0 overflow-y-auto p-4">
          {mod ? (
            <ModuleView
              mod={mod}
              mode={mode}
              setMode={setMode}
              picked={picked}
              setPicked={setPicked}
              card={card}
              setCard={setCard}
              flipped={flipped}
              setFlipped={setFlipped}
              known={known}
              passed={passed[mod.id] === true}
              locked={moduleLocked}
              cards={me.plan !== "starter"}
              drills={me.plan !== "starter"}
              reviewOn={me.plan === "unlimited" || me.plan === "free"}
              retakes={me.plan === "unlimited" || me.plan === "free"}
              review={review}
              onReview={(id, yes) => {
                setReview((current) => ({ ...current, [id]: yes }));
                void save({ data: { itemId: `review:${id}`, score: yes ? 1 : 0 } });
              }}
              onKnow={(id, yes) => {
                setKnown((current) => ({ ...current, [id]: yes }));
                void save({ data: { itemId: `card:${id}`, score: yes ? 1 : 0 } });
              }}
              onPass={(score) => {
                setPassed((current) => ({ ...current, [mod.id]: score >= 2 }));
                void save({ data: { itemId: quizId(mod.id), score } });
              }}
              onPaper={onPaper}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}

function ModuleView({
  mod,
  mode,
  setMode,
  picked,
  setPicked,
  card,
  setCard,
  flipped,
  setFlipped,
  known,
  passed,
  locked,
  cards,
  drills,
  reviewOn,
  retakes,
  review,
  onReview,
  onKnow,
  onPass,
  onPaper,
}: {
  mod: Module;
  mode: "read" | "quiz" | "cards" | "review";
  setMode: (mode: "read" | "quiz" | "cards" | "review") => void;
  picked: Record<number, number>;
  setPicked: (next: Record<number, number>) => void;
  card: number;
  setCard: (n: number) => void;
  flipped: boolean;
  setFlipped: (v: boolean) => void;
  known: Record<string, boolean>;
  passed: boolean;
  locked: boolean;
  cards: boolean;
  drills: boolean;
  reviewOn: boolean;
  retakes: boolean;
  review: Record<string, boolean>;
  onReview: (id: string, yes: boolean) => void;
  onKnow: (id: string, yes: boolean) => void;
  onPass: (score: number) => void;
  onPaper: (mission: string) => void;
}) {
  const score = mod.quiz.reduce((sum, q, i) => sum + (picked[i] === q.answer ? 1 : 0), 0);
  const submitted = Object.keys(picked).length === mod.quiz.length;
  const current = mod.cards[card];
  return (
    <article className="mx-auto max-w-xl">
      <div className="flex flex-wrap gap-1">
        {(["read", "quiz", "cards"] as const).map((id) => (
          <button key={id} type="button" onClick={() => setMode(id)} className={cn("h-8 rounded-full px-3 text-xs font-medium", mode === id ? "bg-fg text-bg" : "bg-chip text-muted")}>
            {id === "read" ? "Lesson" : id === "quiz" ? "Quiz" : "Cards"}
          </button>
        ))}
        {reviewOn ? (
          <button type="button" onClick={() => setMode("review")} className={cn("h-8 rounded-full px-3 text-xs font-medium", mode === "review" ? "bg-fg text-bg" : "bg-chip text-muted")}>
            Review
          </button>
        ) : null}
      </div>
      {locked ? (
        <p className="mt-4 rounded-xl bg-raise px-3 py-3 text-sm text-muted">
          Starter includes the first three modules only. Desk and Unlimited open the rest.
        </p>
      ) : null}
      {mode === "read" && !locked ? (
        <>
          <p className="mt-4 text-xs text-faint">About {mod.minutes} minutes. This is a process, not a promise of profit.</p>
          <h3 className="mt-1 text-2xl font-semibold tracking-tight">{mod.title}</h3>
          <p className="mt-3 text-sm leading-relaxed text-muted">{mod.lead}</p>
          <div className="mt-4 space-y-3">
            {mod.sections.map((section) => (
              <section key={section.heading} className="rounded-xl bg-raise px-3 py-3">
                <h4 className="text-sm font-semibold">{section.heading}</h4>
                <p className="mt-1 text-sm leading-relaxed text-muted">{section.body}</p>
              </section>
            ))}
          </div>
          {drills && mod.paper ? (
            <button type="button" onClick={() => onPaper(mod.paper!)} className="mt-4 h-10 rounded-full bg-fg px-4 text-sm font-semibold text-bg">
              Practice this on paper
            </button>
          ) : null}
        </>
      ) : null}
      {mode === "quiz" && !locked ? (
        <div className="mt-4 space-y-4">
          <h3 className="text-xl font-semibold">Quiz · {mod.title}</h3>
          <p className="text-sm text-muted">Pass is 2 of 3. {passed ? "Passed." : "Not passed yet."}</p>
          {mod.quiz.map((q, qi) => (
            <fieldset key={q.prompt} className="space-y-1">
              <legend className="text-sm font-medium">{q.prompt}</legend>
              {q.choices.map((choice, ci) => {
                const on = picked[qi] === ci;
                const show = submitted && on;
                const right = submitted && ci === q.answer;
                return (
                  <button
                    key={choice}
                    type="button"
                    disabled={passed && !retakes}
                    onClick={() => {
                      if (passed && !retakes) return;
                      setPicked({ ...picked, [qi]: ci });
                    }}
                    className={cn(
                      "block w-full rounded-xl px-3 py-2 text-left text-sm",
                      right ? "bg-up text-bg" : show ? "bg-down text-bg" : on ? "bg-fg text-bg" : "bg-chip",
                    )}
                  >
                    {choice}
                  </button>
                );
              })}
            </fieldset>
          ))}
          {passed && !retakes ? (
            <p className="text-sm text-muted">Passed. Retakes are on Unlimited.</p>
          ) : submitted ? (
            <button type="button" onClick={() => onPass(score)} className="h-10 rounded-full bg-hot px-4 text-sm font-semibold text-bg">
              Save {score}/3
            </button>
          ) : (
            <p className="text-xs text-faint">Answer all three to score it.</p>
          )}
        </div>
      ) : null}
      {mode === "cards" && !locked && !cards ? (
        <p className="mt-4 text-sm text-muted">Flashcards are on Desk and Unlimited. Starter stops at the quiz.</p>
      ) : null}
      {mode === "cards" && !locked && cards && current ? (
        <div className="mt-4">
          <p className="text-xs text-faint">
            Card {card + 1} / {mod.cards.length}
            {known[current.id] ? " · known" : ""}
          </p>
          <button type="button" onClick={() => setFlipped(!flipped)} className="mt-2 min-h-40 w-full rounded-2xl bg-raise px-4 py-6 text-left">
            <p className="text-xs text-faint">{flipped ? "Back" : "Front"}</p>
            <p className="mt-2 text-lg font-semibold leading-snug">{flipped ? current.back : current.front}</p>
          </button>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => {
                onKnow(current.id, false);
                setCard((card + 1) % mod.cards.length);
                setFlipped(false);
              }}
              className="h-9 rounded-full bg-chip px-3 text-sm"
            >
              Again
            </button>
            <button
              type="button"
              onClick={() => {
                onKnow(current.id, true);
                setCard((card + 1) % mod.cards.length);
                setFlipped(false);
              }}
              className="h-9 rounded-full bg-up px-3 text-sm font-semibold text-bg"
            >
              Known
            </button>
          </div>
        </div>
      ) : null}
      {mode === "review" && reviewOn ? (
        <div className="mt-4 space-y-2">
          <h3 className="text-xl font-semibold">Session review</h3>
          <p className="text-sm text-muted">Unlimited only. Four lines. The grade is the rule.</p>
          {[
            ["filter", "Filter passed or I skipped"],
            ["playbook", "One playbook, written before the click"],
            ["result", "Result is in R, including a miss at 0R"],
            ["rule", "I followed the rule, or I stopped"],
          ].map(([id, label]) => (
            <button key={id} type="button" onClick={() => onReview(id, !review[id])} className="flex w-full items-start gap-2 rounded-xl bg-chip px-3 py-2 text-left text-sm">
              <span className={cn("mt-0.5 grid size-4 shrink-0 place-items-center rounded border border-line text-[10px]", review[id] && "bg-up text-bg")}>
                {review[id] ? "ok" : ""}
              </span>
              {label}
            </button>
          ))}
        </div>
      ) : null}
    </article>
  );
}

function Paywall({ used, onClose }: { used: number; onClose: () => void }) {
  return (
    <div className="mx-auto max-w-5xl">
      <p className="text-xs font-semibold text-faint">Free 30 minutes used · {clock(used)} on the clock</p>
      <h3 className="mt-1 text-2xl font-semibold tracking-tight">Learn stopped</h3>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
        Paper trading, the rug check, and the tape are still free. Learn needs a plan. Starter is the tight one. Desk opens the full course. Unlimited adds the review log.
      </p>
      <div className="mt-4">
        <PricingBoard surface="app" />
      </div>
      <button type="button" onClick={onClose} className="mt-4 h-10 rounded-full bg-chip px-4 text-sm">
        Back to the terminal
      </button>
    </div>
  );
}
