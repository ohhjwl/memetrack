import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import type { Token } from "@/lib/market";
import { loadSnaps, type Print, type Snap } from "@/lib/tape";
import { cn, money } from "@/lib/utils";

let audio: AudioContext | null = null;

function unlockAudio() {
  if (typeof window === "undefined") return;
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  if (!audio) audio = new Ctx();
  if (audio.state === "suspended") void audio.resume();
}

function beep() {
  if (!audio) unlockAudio();
  if (!audio) return;
  const osc = audio.createOscillator();
  const gain = audio.createGain();
  osc.frequency.value = 880;
  gain.gain.value = 0.04;
  osc.connect(gain);
  gain.connect(audio.destination);
  osc.start();
  gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 0.12);
  osc.stop(audio.currentTime + 0.13);
}

export function TradeTape({
  tokens,
  paperOn,
  sound,
  onToggleSound,
  onCopy,
  onPick,
}: {
  tokens: Token[];
  paperOn: boolean;
  sound: boolean;
  onToggleSound: () => void;
  onCopy: (print: Print) => void;
  onPick: (print: Print) => void;
}) {
  const [prints, setPrints] = useState<Print[]>([]);
  const snaps = useServerFn(loadSnaps);
  const prev = useRef(new Map<string, Snap>());
  const soundRef = useRef(sound);
  soundRef.current = sound;
  const mints = tokens
    .filter((token) => token.chain === "solana")
    .slice(0, 8)
    .map((token) => token.address)
    .join(",");

  useEffect(() => {
    if (!mints) return;
    const addresses = mints.split(",");
    let stop = false;
    const pull = () => {
      snaps({ data: { addresses } })
        .then((result) => {
          if (stop) return;
          const fresh: Print[] = [];
          let liveBuy = false;
          for (const row of result.rows) {
            const before = prev.current.get(row.address);
            prev.current.set(row.address, row);
            if (!(row.price > 0)) continue;
            if (!before) {
              const side = row.m5buys >= row.m5sells ? "buy" : "sell";
              const count = side === "buy" ? row.m5buys : row.m5sells;
              if (count <= 0) continue;
              const each = row.m5vol / Math.max(row.m5buys + row.m5sells, 1);
              fresh.push(toPrint(row, side, Math.min(count, 3) * each));
              continue;
            }
            const buyDelta = row.m5buys - before.m5buys;
            const sellDelta = row.m5sells - before.m5sells;
            const each = row.m5vol / Math.max(row.m5buys + row.m5sells, 1);
            if (buyDelta > 0 && buyDelta < 40) {
              fresh.push(toPrint(row, "buy", Math.min(buyDelta, 3) * each));
              liveBuy = true;
            } else if (sellDelta > 0 && sellDelta < 40) {
              fresh.push(toPrint(row, "sell", Math.min(sellDelta, 3) * each));
            }
          }
          if (fresh.length) setPrints((current) => [...fresh, ...current].slice(0, 40));
          if (liveBuy && soundRef.current) beep();
        })
        .catch(() => undefined);
    };
    pull();
    const id = window.setInterval(pull, 12000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [mints, snaps]);

  useEffect(() => {
    let ws: WebSocket | null = null;
    try {
      ws = new WebSocket("wss://pumpportal.fun/api/data");
    } catch {
      return;
    }
    ws.onopen = () => ws?.send(JSON.stringify({ method: "subscribeNewToken" }));
    ws.onmessage = (event) => {
      let body: { mint?: string; symbol?: string; name?: string; txType?: string; traderPublicKey?: string };
      try {
        body = JSON.parse(String(event.data));
      } catch {
        return;
      }
      if (!body.mint || body.txType !== "create") return;
      const print: Print = {
        id: `new-${body.mint}`,
        time: Date.now(),
        side: "new",
        symbol: body.symbol || "NEW",
        name: body.name || "New launch",
        address: body.mint,
        chain: "solana",
        pair: "",
        price: 0,
        usd: 0,
        liquidity: 0,
        marketCap: 0,
        wallet: body.traderPublicKey,
      };
      setPrints((current) => [print, ...current].slice(0, 40));
    };
    return () => ws?.close();
  }, []);

  return (
    <div className="flex max-h-72 min-h-36 flex-1 flex-col overflow-hidden rounded-2xl border border-line bg-panel">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-3 py-2">
        <h2 className="text-sm font-semibold">Live tape</h2>
        <div className="flex items-center gap-2">
          <span className="text-xs text-faint">{paperOn ? "Copy uses paper" : "Paper is off"}</span>
          <button
            type="button"
            onClick={() => {
              unlockAudio();
              onToggleSound();
            }}
            className={cn("h-7 rounded-full px-2.5 text-xs", sound ? "bg-fg text-bg" : "bg-chip text-muted")}
          >
            {sound ? "Sound on" : "Sound"}
          </button>
        </div>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto">
        {prints.length === 0 ? <p className="px-3 py-3 text-sm text-muted">Waiting for new buys and sells…</p> : null}
        {prints.map((print) => (
          <div key={print.id + print.time} className="flex items-center gap-2 border-t border-line px-3 py-2">
            <button type="button" onClick={() => onPick(print)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
              <span
                className={cn(
                  "w-10 text-xs font-semibold",
                  print.side === "sell" ? "text-down" : print.side === "new" ? "text-hot" : "text-up",
                )}
              >
                {print.side}
              </span>
              <span className="min-w-0 flex-1 truncate text-sm font-medium">{print.symbol}</span>
              <span className="text-xs tabular-nums text-muted">{print.usd > 0 ? money(print.usd) : "new"}</span>
            </button>
            {print.side === "buy" && print.price > 0 ? (
              <button type="button" onClick={() => onCopy(print)} className="h-8 rounded-full bg-chip px-2.5 text-xs">
                Copy
              </button>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
}

function toPrint(row: Snap, side: "buy" | "sell", usd: number): Print {
  return {
    id: `${row.address}-${side}-${row.m5buys}-${row.m5sells}`,
    time: Date.now(),
    side,
    symbol: row.symbol,
    name: row.name,
    address: row.address,
    chain: row.chain,
    pair: row.pair,
    price: row.price,
    usd,
    liquidity: row.liquidity,
    marketCap: row.marketCap,
  };
}
