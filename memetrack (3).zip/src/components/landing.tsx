import { Link } from "@tanstack/react-router";
import { SignedIn, SignedOut } from "@/lib/auth/gates";
import { PricingBoard } from "@/components/pricing-board";
import { MODULES } from "@/lib/learn";

const BARS = [22, 38, 30, 58, 36, 72, 44, 86, 40, 64, 28, 90, 48, 76];

export function Landing() {
  return (
    <div className="landing">
      <div className="landing-stars" />
      <div className="landing-horizon" />
      <div className="landing-glow" />
      <div className="landing-orbit" aria-hidden="true" />

      <nav className="relative z-10 mx-auto flex h-16 w-full max-w-6xl items-center gap-4 px-5">
        <span className="flex items-center gap-2 text-sm font-semibold tracking-tight">
          <span className="grid size-6 place-items-center rounded-full border border-white/20 text-[10px]">m</span>
          MemeTrack
        </span>
        <div className="ml-8 hidden items-center gap-6 text-sm text-white/70 sm:flex">
          <a href="#desk">Desk</a>
          <a href="#learn">Learn</a>
          <Link to="/pricing">Pricing</Link>
        </div>
        <SignedOut>
          <Link to="/login" className="ml-auto text-sm text-white/80">
            Log in
          </Link>
        </SignedOut>
        <SignedIn>
          <Link to="/app" className="ml-auto rounded-full bg-white px-3 py-1.5 text-sm font-semibold text-black">
            Open terminal
          </Link>
        </SignedIn>
      </nav>

      <header className="relative z-10 mx-auto flex min-h-[calc(100dvh-4rem)] max-w-5xl flex-col items-center px-5 pb-10 pt-10 text-center sm:pt-16">
        <p className="rise text-sm tracking-wide text-white/55">Paper. Rug check. Smarter tape. All free.</p>
        <h1 className="mt-5 text-[3.2rem] font-semibold leading-[0.92] tracking-tight sm:text-7xl">
          <span className="rise d1 block">Paper the trade.</span>
          <span className="rise d2 block text-white/75">Check the rug.</span>
        </h1>
        <p className="rise d3 mx-auto mt-6 max-w-xl text-base leading-relaxed text-white/65 sm:text-lg">
          A $10,000 paper account, a rug note that never blocks a buy, and a live tape with liquidity next to the print. That desk stays free. Learn is further down, and it stops after 30 minutes.
        </p>
        <div className="rise d4 mt-8 flex flex-wrap items-center justify-center gap-3">
          <SignedOut>
            <Link to="/login" className="landing-cta">
              Start paper free
            </Link>
          </SignedOut>
          <SignedIn>
            <Link to="/app" className="landing-cta">
              Open the desk
            </Link>
          </SignedIn>
          <Link to="/pricing" className="landing-ghost">
            Pricing
          </Link>
        </div>

        <div id="desk" className="mt-auto grid w-full gap-4 pt-12 md:grid-cols-3">
          {[
            ["Paper", "Fake $10,000. Equity, stops, and a PnL card. Nothing here is a real order."],
            ["Rug check", "Mint, freeze, and holders as a note. Risky and Bad can still be paper-bought."],
            ["Smarter tape", "Liquidity next to the candle, so size is a decision and not a mood."],
          ].map(([title, body], index) => (
            <article key={title} className={index === 0 ? "floaty landing-card text-left md:col-span-1" : "landing-card text-left"}>
              <p className="text-xs text-emerald-300">Free</p>
              <h2 className="mt-2 text-xl font-semibold">{title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-white/65">{body}</p>
              {index === 0 ? (
                <div className="mt-4 flex h-24 items-end gap-1">
                  {BARS.slice(0, 10).map((height, bar) => (
                    <span key={bar} className={bar % 4 === 2 ? "candle down" : "candle"} style={{ height: `${height}%` }} />
                  ))}
                </div>
              ) : null}
            </article>
          ))}
        </div>
        <a href="#learn" className="mt-8 text-xs text-white/45">
          Scroll for Learn
        </a>
      </header>

      <section id="learn" className="relative z-10 mx-auto max-w-3xl px-5 pb-16 pt-16 text-center">
        <p className="text-xs uppercase tracking-[0.18em] text-white/40">Further down · Learn</p>
        <h2 className="mt-3 text-4xl font-semibold tracking-tight sm:text-5xl">Thirty minutes. Then it stops.</h2>
        <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-white/65">
          The course is the only thing that is not free. Eight modules, quizzes, flashcards, and paper drills. The clock is 30 minutes of use, once. When it hits zero, Learn closes until a plan is on. The paper desk does not.
        </p>
        <div className="mx-auto mt-6 max-w-sm rounded-3xl border border-white/15 bg-black/40 p-5">
          <p className="text-5xl font-semibold tabular-nums">30:00</p>
          <p className="mt-1 text-xs text-white/50">free Learn, once, then it stops</p>
        </div>
        <ol className="mx-auto mt-8 grid max-w-lg gap-2 text-left">
          {MODULES.map((mod, index) => (
            <li key={mod.id} className="flex items-baseline gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
              <span className="w-6 shrink-0 text-xs tabular-nums text-white/35">{String(index + 1).padStart(2, "0")}</span>
              <span className="min-w-0">
                <span className="block text-sm font-medium">{mod.title}</span>
                <span className="text-xs text-white/45">{mod.minutes} min read</span>
              </span>
            </li>
          ))}
        </ol>
      </section>

      <section id="pricing" className="relative z-10 mx-auto max-w-5xl px-5 pb-24">
        <h2 className="text-center text-3xl font-semibold tracking-tight">Plans</h2>
        <p className="mx-auto mt-2 max-w-lg text-center text-sm text-white/60">
          Monthly, 3 months, 6 months, or a year. Longer ranges are cheaper per month.
        </p>
        <div className="mt-6">
          <PricingBoard />
        </div>
      </section>
    </div>
  );
}
