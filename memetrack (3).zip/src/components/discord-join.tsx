import { useState } from "react";
import { DISCORD_INVITE } from "@/lib/discord";

export function useDiscordJoin() {
  const [opened, setOpened] = useState(false);
  const [agreed, setAgreed] = useState(false);

  return {
    invite: DISCORD_INVITE,
    opened,
    agreed,
    setAgreed,
    markOpened: () => setOpened(true),
    ready: opened && agreed,
  };
}
