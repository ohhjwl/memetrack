import { useEffect, useMemo, useRef, useState, type ReactNode, type RefObject } from "react";
import { toast } from "sonner";
import { Bell, Copy, Search, Settings, Star } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { loadMentions, type Mention } from "@/lib/mentions";
import {
  TRADERS,
  changeOf,
  loadMajors,
  loadPerps,
  loadRug,
  loadTrending,
  searchTokens,
  searchTraders,
  type Major,
  type Perp,
  type RugReport,
  type Token,
  type WindowKey,
} from "@/lib/market";
import { cn, money, pct, pnl, price, shortAddr } from "@/lib/utils";
import { CoinChart } from "@/components/coin-chart";
import { DownloadApp } from "@/components/install-app";
import { LearnDesk } from "@/components/learn-desk";
import { AdminDesk, ProfileCard } from "@/components/admin-desk";
import { UserButton } from "@/lib/auth/gates";
import { getMe, confirmDiscord, type Me } from "@/lib/accounts";
import { useDiscordJoin } from "@/components/discord-join";
import { PaperDesk } from "@/components/paper-desk";
import { PulseBoard } from "@/components/pulse-board";
import { TradeTape } from "@/components/trade-tape";
import { WalletDesk } from "@/components/wallet-desk";
import { isVenueId, venueLabel, VENUES, type VenueId } from "@/lib/venues";
import { FREE_LEARN_MS, clock } from "@/lib/pricing";
import { DISCORD_INVITE } from "@/lib/discord";
import { applyTheme, DEFAULT_THEME, THEME_FIELDS, THEME_PRESETS, type Theme } from "@/lib/themes";
import { applyCopies, armAlert, checkSafety, copyPasses, emptyBook, emptyFilter, paperBuy, paperSell, readBook, setStops, summarize, START_CASH, type Book } from "@/lib/paper";
import { jupiterBuy } from "@/lib/jupiter";
import { downloadPnlCard } from "@/lib/pnl-card";
import { loadWalletActivity, type WalletEvent } from "@/lib/wallets";
import type { Print } from "@/lib/tape";

type FilterId = "trending" | "new" | "held" | "graduated" | "bonding" | "watch" | "perps" | "pulse";
type SortId = "mcap" | "liq" | "age";
type MobilePane = "hot" | "tokens" | "traders" | "feed";
type View = "discover" | "settings" | "paper" | "wallets" | "learn" | "admin";
type SavedView = { name: string; filter: FilterId; chain: string; sort: SortId; windowKey: WindowKey };

const WINDOWS: { id: WindowKey; label: string }[] = [
  { id: "m5", label: "5m" },
  { id: "h1", label: "1h" },
  { id: "h6", label: "6h" },
  { id: "h24", label: "24h" },
];

const FILTERS: { id: FilterId; label: string }[] = [
  { id: "trending", label: "Trending" },
  { id: "new", label: "New" },
  { id: "held", label: "Most held" },
  { id: "graduated", label: "Graduated" },
  { id: "bonding", label: "Bonding" },
  { id: "pulse", label: "Pulse" },
  { id: "watch", label: "Watchlist" },
  { id: "perps", label: "Perps" },
];

function readList(key: string) {
  if (typeof window === "undefined") return [];
  try {
    const parsed = JSON.parse(localStorage.getItem(key) || "[]") as unknown;
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "string") : [];
  } catch {
    return [];
  }
}

function readSnap() {
  if (typeof window === "undefined") return {} as Record<string, number>;
  try {
    const parsed = JSON.parse(localStorage.getItem("mt-snap") || "{}") as unknown;
    if (!parsed || typeof parsed !== "object") return {};
    return parsed as Record<string, number>;
  } catch {
    return {};
  }
}

function readViews(): SavedView[] {
  if (typeof window === "undefined") return [];
  try {
    const parsed = JSON.parse(localStorage.getItem("mt-views") || "[]") as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => item && typeof item === "object" && typeof (item as SavedView).name === "string") as SavedView[];
  } catch {
    return [];
  }
}

function lookalikes(token: Token, pool: Token[]) {
  const words = new Set(
    `${token.name} ${token.symbol}`
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter((word) => word.length > 3),
  );
  const scored = pool
    .filter((other) => other.id !== token.id)
    .map((other) => {
      const bits = `${other.name} ${other.symbol}`.toLowerCase().split(/[^a-z0-9]+/);
      const shared = bits.filter((bit) => words.has(bit)).length;
      return { other, score: shared * 3 + (other.chain === token.chain ? 1 : 0) };
    })
    .filter((row) => row.score > 1)
    .sort((a, b) => b.score - a.score);
  if (scored.length) return scored.slice(0, 4).map((row) => row.other);
  return pool
    .filter((other) => other.id !== token.id && other.chain === token.chain)
    .sort((a, b) => Math.abs(a.marketCap - token.marketCap) - Math.abs(b.marketCap - token.marketCap))
    .slice(0, 4);
}

function contractIn(text: string) {
  return (text.match(/[1-9A-HJ-NP-Za-km-z]{32,44}/g) ?? []).slice(0, 2);
}

function ping(title: string, body: string) {
  toast(title);
  if (typeof Notification !== "undefined" && Notification.permission === "granted") {
    new Notification(title, { body });
  }
}

function ago(ts?: number) {
  if (!ts) return "now";
  const mins = Math.max(1, Math.round((Date.now() - ts) / 60000));
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 48) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

function dollarMove(token: Token, windowKey: WindowKey) {
  const change = token.change[windowKey] / 100;
  if (change <= -0.95 || !token.marketCap) return 0;
  return token.marketCap - token.marketCap / (1 + change);
}

function Mark({ token, className }: { token: Pick<Token, "symbol" | "image">; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (!token.image || failed) {
    return (
      <span
        className={cn(
          "grid shrink-0 place-items-center rounded-lg bg-chip text-xs font-semibold text-fg",
          className,
        )}
      >
        {(token.symbol || "?").slice(0, 1).toUpperCase()}
      </span>
    );
  }
  return (
    <img
      src={token.image}
      alt=""
      className={cn("shrink-0 rounded-lg object-cover", className)}
      onError={() => setFailed(true)}
    />
  );
}

function Face({ handle }: { handle: string }) {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return (
      <span className="grid size-8 shrink-0 place-items-center rounded-full bg-chip text-xs font-semibold">
        {handle.slice(0, 1).toUpperCase()}
      </span>
    );
  }
  return (
    <img
      src={`https://unavatar.io/x/${handle}`}
      alt=""
      className="size-8 shrink-0 rounded-full object-cover"
      onError={() => setFailed(true)}
    />
  );
}

export function Discover() {
  const [tokens, setTokens] = useState<Token[]>([]);
  const [majors, setMajors] = useState<Major[]>([]);
  const [perps, setPerps] = useState<Perp[]>([]);
  const [view, setView] = useState<View>("discover");
  const [theme, setTheme] = useState<Theme>(DEFAULT_THEME);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<Token[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [windowKey, setWindowKey] = useState<WindowKey>("h24");
  const [filter, setFilter] = useState<FilterId>("trending");
  const [sort, setSort] = useState<SortId>("mcap");
  const [chain, setChain] = useState("all");
  const [selected, setSelected] = useState<Token | null>(null);
  const [rug, setRug] = useState<RugReport | null>(null);
  const [rugLoading, setRugLoading] = useState(false);
  const [trader, setTrader] = useState<(typeof TRADERS)[number] | null>(null);
  const [legal, setLegal] = useState<"privacy" | "terms" | null>(null);
  const [pane, setPane] = useState<MobilePane>("tokens");
  const [watch, setWatch] = useState<string[]>([]);
  const [followed, setFollowed] = useState<string[]>([]);
  const [followOnly, setFollowOnly] = useState(false);
  const [alerts, setAlerts] = useState(false);
  const [recap, setRecap] = useState<string[]>([]);
  const [views, setViews] = useState<SavedView[]>([]);
  const [viewName, setViewName] = useState("");
  const [venue, setVenue] = useState<VenueId>("axiom");
  const [paperOn, setPaperOn] = useState(false);
  const [book, setBook] = useState<Book>(emptyBook);
  const [walletEvents, setWalletEvents] = useState<Record<string, WalletEvent[]>>({});
  const [stored, setStored] = useState(false);
  const [me, setMe] = useState<Me | null>(null);
  const [mission, setMission] = useState("");
  const loadMe = useServerFn(getMe);
  const markDiscord = useServerFn(confirmDiscord);
  const searchRef = useRef<HTMLInputElement>(null);
  const booted = useRef(false);
  const hotSeen = useRef<Set<string>>(new Set());
  const seededWallets = useRef<Set<string>>(new Set());
  const alertsRef = useRef(false);
  const bookRef = useRef(book);
  bookRef.current = book;

  useEffect(() => {
    setWatch(readList("mt-watch"));
    setFollowed(readList("mt-follow"));
    setViews(readViews());
    setAlerts(localStorage.getItem("mt-alerts") === "1");
    const savedVenue = localStorage.getItem("mt-venue") ?? "";
    if (isVenueId(savedVenue)) setVenue(savedVenue);
    const paperFlag = localStorage.getItem("mt-paper-on");
    setPaperOn(paperFlag == null ? true : paperFlag === "1");
    setBook(readBook(localStorage.getItem("mt-paper")));
    try {
      const saved = JSON.parse(localStorage.getItem("mt-theme") || "null") as Partial<Theme> | null;
      if (saved) setTheme({ ...DEFAULT_THEME, ...saved });
    } catch {
      /* keep default */
    }
    setStored(true);
  }, []);

  useEffect(() => {
    void loadMe().then(setMe).catch(() => setMe(null));
  }, [loadMe]);

  useEffect(() => {
    if (!stored) return;
    localStorage.setItem("mt-watch", JSON.stringify(watch));
  }, [watch, stored]);

  useEffect(() => {
    if (!stored) return;
    localStorage.setItem("mt-follow", JSON.stringify(followed));
  }, [followed, stored]);

  useEffect(() => {
    if (!stored) return;
    localStorage.setItem("mt-theme", JSON.stringify(theme));
    applyTheme(theme);
  }, [theme, stored]);

  useEffect(() => {
    if (!stored) return;
    localStorage.setItem("mt-views", JSON.stringify(views));
  }, [views, stored]);

  useEffect(() => {
    if (!stored) return;
    localStorage.setItem("mt-alerts", alerts ? "1" : "0");
  }, [alerts, stored]);

  useEffect(() => {
    if (!stored) return;
    localStorage.setItem("mt-venue", venue);
  }, [venue, stored]);

  useEffect(() => {
    if (!stored) return;
    localStorage.setItem("mt-paper-on", paperOn ? "1" : "0");
    localStorage.setItem("mt-paper", JSON.stringify(book));
  }, [paperOn, book, stored]);

  const loadWallet = useServerFn(loadWalletActivity);
  alertsRef.current = alerts;

  useEffect(() => {
    if (!stored || book.wallets.length === 0) return;
    let stop = false;
    const watched = book.wallets;
    const pull = () => {
      Promise.all(
        watched.map((wallet) =>
          loadWallet({ data: { address: wallet.address } })
            .then((result) => ({ address: wallet.address, events: result.events, copy: wallet.copy, label: wallet.label }))
            .catch(() => ({ address: wallet.address, events: [] as WalletEvent[], copy: false, label: wallet.label })),
        ),
      ).then((groups) => {
        if (stop) return;
        setWalletEvents((current) => {
          const next = { ...current };
          for (const group of groups) next[group.address] = group.events;
          return next;
        });
        const notes: string[] = [];
        let next = bookRef.current;
        const freshIds: string[] = [];
        for (const group of groups) {
          const firstSight = !seededWallets.current.has(group.address);
          if (firstSight) seededWallets.current.add(group.address);
          for (const event of group.events) {
            if (next.alerted.includes(event.id) || freshIds.includes(event.id)) continue;
            freshIds.push(event.id);
            if (!firstSight && alertsRef.current && event.side === "buy") {
              notes.push(`${group.label || "Wallet"} bought ${event.symbol}`);
            }
          }
        }
        if (freshIds.length) next = { ...next, alerted: [...freshIds, ...next.alerted].slice(0, 400) };
        if (paperOn) {
          const buys = groups.flatMap((group) =>
            group.copy
              ? group.events
                  .filter((event) => event.side === "buy")
                  .map((event) => ({
                    id: event.id,
                    symbol: event.symbol,
                    name: event.name,
                    address: event.address,
                    chain: event.chain,
                    price: event.price,
                    liquidity: event.liquidity,
                    marketCap: event.marketCap,
                    wallet: group.address,
                    size: watched.find((wallet) => wallet.address === group.address)?.filter.size,
                  }))
              : [],
          );
          if (buys.length) {
            next = applyCopies(next, buys, (buy) => {
              const wallet = next.wallets.find((item) => item.address === buy.wallet);
              return wallet ? copyPasses(wallet.filter, buy) : false;
            });
          }
        }
        if (next !== bookRef.current) {
          bookRef.current = next;
          setBook(next);
        }
        if (alertsRef.current) notes.slice(0, 3).forEach((note) => ping(note, "Wallet tracker"));
      });
    };
    pull();
    const id = window.setInterval(pull, 25000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [stored, paperOn, book.wallets, loadWallet]);

  useEffect(() => {
    let stop = false;
    const pull = () => {
      loadTrending()
        .then((rows) => {
          if (stop) return;
          setTokens(rows);
          setError(rows.length ? "" : "No trending coins came back.");
        })
        .catch(() => {
          if (!stop) setError("Couldn't reach the market feed.");
        })
        .finally(() => {
          if (!stop) setLoading(false);
        });
    };
    pull();
    loadMajors()
      .then((rows) => {
        if (!stop) setMajors(rows);
      })
      .catch(() => undefined);
    loadPerps()
      .then((rows) => {
        if (!stop) setPerps(rows);
      })
      .catch(() => undefined);
    const id = window.setInterval(pull, 45000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "/" && document.activeElement?.tagName !== "INPUT") {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if (event.key === "Escape") {
        setSearchOpen(false);
        setSelected(null);
        setTrader(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setHits([]);
      return;
    }
    setSearching(true);
    const id = window.setTimeout(() => {
      searchTokens(q)
        .then(setHits)
        .catch(() => setHits([]))
        .finally(() => setSearching(false));
    }, 280);
    return () => window.clearTimeout(id);
  }, [query]);

  useEffect(() => {
    if (!selected || selected.chain !== "solana") {
      setRug(null);
      return;
    }
    let stop = false;
    setRugLoading(true);
    loadRug(selected.address)
      .then((report) => {
        if (!stop) setRug(report);
      })
      .finally(() => {
        if (!stop) setRugLoading(false);
      });
    return () => {
      stop = true;
    };
  }, [selected]);

  const chains = useMemo(() => {
    const set = new Set(tokens.map((token) => token.chain));
    return ["all", ...set];
  }, [tokens]);

  const visible = useMemo(() => {
    let rows = tokens.filter((token) => chain === "all" || token.chain === chain);
    if (filter === "watch") rows = rows.filter((token) => watch.includes(token.id));
    if (filter === "bonding") rows = rows.filter((token) => token.dex === "pumpfun");
    if (filter === "graduated") rows = rows.filter((token) => token.dex !== "pumpfun" && token.marketCap > 15000);
    if (filter === "new") {
      const cutoff = Date.now() - 72 * 60 * 60 * 1000;
      const young = rows.filter((token) => (token.created ?? 0) >= cutoff);
      rows = [...(young.length >= 4 ? young : rows)].sort((a, b) => (b.created ?? 0) - (a.created ?? 0));
    } else if (filter === "held") rows = [...rows].sort((a, b) => b.liquidity - a.liquidity);
    else if (filter === "trending") rows = [...rows].sort((a, b) => b.volume - a.volume);
    else if (sort === "liq") rows = [...rows].sort((a, b) => b.liquidity - a.liquidity);
    else if (sort === "age") rows = [...rows].sort((a, b) => (b.created ?? 0) - (a.created ?? 0));
    else rows = [...rows].sort((a, b) => b.marketCap - a.marketCap);
    return rows;
  }, [tokens, chain, filter, sort, watch]);

  const movers = useMemo(
    () => [...tokens].sort((a, b) => Math.abs(b.change.h24) - Math.abs(a.change.h24)).slice(0, 6),
    [tokens],
  );

  const callouts = useMemo(
    () => [...tokens].sort((a, b) => Math.abs(b.change.h1) - Math.abs(a.change.h1)).slice(0, 14),
    [tokens],
  );

  const paperStats = useMemo(
    () => summarize(book, (tokenId) => tokens.find((token) => token.id === tokenId)?.price ?? 0),
    [book, tokens],
  );

  const traderHits = searchTraders(query);

  useEffect(() => {
    if (!stored || loading || tokens.length === 0) return;
    const prev = readSnap();
    if (!booted.current) {
      booted.current = true;
      movers.forEach((token) => hotSeen.current.add(token.id));
      const lines = tokens
        .filter((token) => watch.includes(token.id) && prev[token.id] > 0)
        .map((token) => {
          const delta = ((token.price - prev[token.id]) / prev[token.id]) * 100;
          return Math.abs(delta) >= 10 ? `${token.symbol} ${delta >= 0 ? "+" : ""}${delta.toFixed(0)}%` : "";
        })
        .filter(Boolean);
      if (lines.length) setRecap(lines.slice(0, 4));
      localStorage.setItem("mt-snap", JSON.stringify(Object.fromEntries(tokens.map((token) => [token.id, token.price]))));
      return;
    }
    if (!alerts) return;
    const nextHot = new Set(movers.map((token) => token.id));
    for (const token of movers) {
      if (!hotSeen.current.has(token.id) && Math.abs(token.change.h1) >= 25) {
        ping(`${token.symbol} hit Hot`, `${pct(token.change.h1)} in the last hour`);
      }
    }
    hotSeen.current = nextHot;
    for (const token of tokens) {
      if (!watch.includes(token.id) || !(prev[token.id] > 0)) continue;
      const delta = ((token.price - prev[token.id]) / prev[token.id]) * 100;
      if (Math.abs(delta) >= 15) ping(`${token.symbol} ${delta >= 0 ? "up" : "down"} ${Math.abs(delta).toFixed(0)}%`, "Starred coin moved");
    }
    localStorage.setItem("mt-snap", JSON.stringify(Object.fromEntries(tokens.map((token) => [token.id, token.price]))));
  }, [tokens, stored, loading, alerts, watch, movers]);

  useEffect(() => {
    if (!stored || !paperOn) return;
    let next = bookRef.current;
    const notes: string[] = [];
    for (const lot of [...next.lots]) {
      if (!lot.tpPct && !lot.slPct) continue;
      const px = tokens.find((token) => token.id === lot.tokenId)?.price ?? 0;
      if (!(px > 0) || !(lot.qty > 0) || !(lot.cost > 0)) continue;
      const change = ((px - lot.cost / lot.qty) / (lot.cost / lot.qty)) * 100;
      if (lot.tpPct && change >= lot.tpPct) {
        const sold = paperSell(next, lot.tokenId, 1, px, "tp");
        if (!sold.error) {
          next = sold.book;
          notes.push(`${lot.symbol} take-profit filled`);
        }
      } else if (lot.slPct && change <= -lot.slPct) {
        const sold = paperSell(next, lot.tokenId, 1, px, "sl");
        if (!sold.error) {
          next = sold.book;
          notes.push(`${lot.symbol} stop-loss filled`);
        }
      }
    }
    if (next !== bookRef.current) {
      bookRef.current = next;
      setBook(next);
      notes.forEach((note) => toast(note));
    }
  }, [tokens, paperOn, stored]);

  useEffect(() => {
    if (!stored || tokens.length === 0) return;
    const equity = summarize(bookRef.current, (tokenId) => {
      const live = tokens.find((token) => token.id === tokenId)?.price ?? 0;
      if (live > 0) return live;
      return bookRef.current.fills.find((fill) => fill.tokenId === tokenId)?.price ?? 0;
    }).equity;
    const last = bookRef.current.equity[bookRef.current.equity.length - 1];
    if (last && Date.now() - last.t < 45_000) return;
    setBook((current) => {
      const point = current.equity[current.equity.length - 1];
      if (point && Date.now() - point.t < 45_000) return current;
      return { ...current, equity: [...current.equity, { t: Date.now(), v: equity }].slice(-160) };
    });
  }, [tokens, stored]);

  useEffect(() => {
    if (!stored || !alerts) return;
    const pending = bookRef.current.alerts.filter((alert) => !alert.fired);
    if (!pending.length) return;
    const hit: string[] = [];
    for (const alert of pending) {
      const token = tokens.find((item) => item.id === alert.tokenId);
      if (!token) continue;
      const crossed = alert.above ? token.price >= alert.target : token.price <= alert.target;
      if (!crossed) continue;
      ping(`${token.symbol} hit ${price(alert.target)}`, `Now ${price(token.price)}`);
      hit.push(alert.id);
    }
    if (!hit.length) return;
    setBook((current) => ({
      ...current,
      alerts: current.alerts.map((alert) => (hit.includes(alert.id) ? { ...alert, fired: true } : alert)),
    }));
  }, [tokens, alerts, stored]);

  function toggleWatch(token: Token) {
    setWatch((current) =>
      current.includes(token.id) ? current.filter((id) => id !== token.id) : [...current, token.id],
    );
  }

  function copyCa(address: string) {
    navigator.clipboard?.writeText(address).then(
      () => toast(`Copied ${shortAddr(address)}`),
      () => toast("Couldn't copy that address"),
    );
  }

  async function toggleAlerts() {
    if (!alerts) {
      if (typeof Notification !== "undefined" && Notification.permission === "default") {
        await Notification.requestPermission();
      }
      setAlerts(true);
      toast("Alerts on for starred coins and new Hot names");
      return;
    }
    setAlerts(false);
  }

  function saveView() {
    const name = viewName.trim() || `${filter} · ${chain}`;
    setViews((current) => [{ name, filter, chain, sort, windowKey }, ...current.filter((item) => item.name !== name)].slice(0, 8));
    setViewName("");
  }

  function applyView(item: SavedView) {
    setFilter(item.filter);
    setChain(item.chain);
    setSort(item.sort);
    setWindowKey(item.windowKey);
  }

  const watched = tokens.filter((token) => watch.includes(token.id));

  function markPrice(tokenId: string) {
    return tokens.find((token) => token.id === tokenId)?.price ?? book.fills.find((fill) => fill.tokenId === tokenId)?.price ?? 0;
  }

  function tradeBuy(token: Token, usd: number, source: "quick" | "copy" | "wallet") {
    if (!paperOn) {
      toast("Turn on paper trade in Settings");
      return;
    }
    const result = paperBuy(bookRef.current, token, usd, source);
    if (result.error) toast(result.error);
    else {
      bookRef.current = result.book;
      setBook(result.book);
      toast(`Paper bought $${usd} of ${token.symbol}`);
    }
  }

  function tradeSell(tokenId: string, fraction: number) {
    const result = paperSell(bookRef.current, tokenId, fraction, markPrice(tokenId));
    if (result.error) toast(result.error);
    else {
      bookRef.current = result.book;
      setBook(result.book);
      toast(fraction >= 0.999 ? "Paper sold the rest" : "Paper sold part of the position");
    }
  }

  function tradeStops(tokenId: string, tp: number | null, sl: number | null) {
    const next = setStops(bookRef.current, tokenId, tp, sl);
    bookRef.current = next;
    setBook(next);
  }

  function tradeAlert(token: Token, target: number) {
    if (!(target > 0)) {
      toast("Enter a price above zero");
      return;
    }
    const next = armAlert(bookRef.current, token, target);
    bookRef.current = next;
    setBook(next);
    if (!alerts) {
      setAlerts(true);
      toast("Alerts on. This one is armed.");
      return;
    }
    toast(`${token.symbol} alert armed at ${price(target)}`);
  }

  async function tradeSwap(token: Token, usd: number) {
    const sol = majors.find((major) => major.symbol === "SOL")?.price ?? 0;
    const result = await jupiterBuy(token.address, usd, sol);
    if (result.ok) {
      toast(`Swap sent ${shortAddr(result.signature)}`);
      return;
    }
    if (result.reason === "no-wallet") {
      toast(`No Solana wallet in this browser. Use Buy on ${venueLabel(venue)}.`);
      return;
    }
    toast(result.reason);
  }

  function tokenFromPrint(print: Print): Token {
    return (
      tokens.find((token) => token.address === print.address) ?? {
        id: `${print.chain}:${print.address}`,
        chain: print.chain,
        address: print.address,
        pair: print.pair,
        symbol: print.symbol,
        name: print.name,
        price: print.price,
        change: { m5: 0, h1: 0, h6: 0, h24: 0 },
        volume: 0,
        liquidity: print.liquidity,
        marketCap: print.marketCap,
        url: "",
        dex: "",
        buys24: 0,
        sells24: 0,
      }
    );
  }

  if (me?.banned) {
    return (
      <div className="grid h-dvh place-items-center bg-bg px-6 text-center text-fg">
        <div className="max-w-sm">
          <h1 className="text-2xl font-semibold tracking-tight">This account is suspended</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            An admin turned off this profile. The terminal, Learn, and profile edits stay closed until that changes.
          </p>
        </div>
      </div>
    );
  }

  if (me && !me.discordJoined) {
    return <DiscordHold onJoined={() => setMe({ ...me, discordJoined: true })} mark={() => markDiscord()} />;
  }

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-bg text-fg">
      <header className="flex h-14 shrink-0 items-center gap-3 border-b border-line px-3">
        <div className="flex items-center gap-2">
          <span className="grid size-8 place-items-center rounded-lg bg-fg text-sm font-bold text-bg">m</span>
          <span className="text-lg font-semibold tracking-tight">track</span>
          <span className="hidden text-sm text-muted sm:inline">Discover</span>
        </div>
        <div className="relative mx-auto hidden w-full max-w-xl md:block">
          <SearchBox
            inputRef={searchRef}
            query={query}
            setQuery={setQuery}
            open={searchOpen}
            setOpen={setSearchOpen}
            searching={searching}
            hits={hits}
            traders={query.trim().length > 0 ? traderHits : []}
            onToken={(token) => {
              setSelected(token);
              setSearchOpen(false);
            }}
            onTrader={(person) => {
              setTrader(person);
              setSearchOpen(false);
            }}
          />
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            onClick={() => setView(view === "paper" ? "discover" : "paper")}
            className={cn(
              "hidden h-8 items-center rounded-full px-3 text-xs font-semibold sm:flex",
              view === "paper" || paperOn ? "bg-fg text-bg" : "bg-chip text-muted",
            )}
          >
            {paperOn ? `Paper ${pnl(paperStats.equity - START_CASH)}` : "Paper"}
          </button>
          <button
            type="button"
            onClick={() => setView(view === "wallets" ? "discover" : "wallets")}
            className={cn(
              "hidden h-8 items-center rounded-full px-3 text-xs font-semibold md:flex",
              view === "wallets" ? "bg-fg text-bg" : "bg-chip text-muted",
            )}
          >
            Wallets
          </button>
          <button
            type="button"
            onClick={() => setView(view === "learn" ? "discover" : "learn")}
            className={cn(
              "hidden h-8 items-center rounded-full px-3 text-xs font-semibold sm:flex",
              view === "learn" ? "bg-fg text-bg" : "bg-chip text-faint",
            )}
          >
            {me && !me.learnOpen ? "Learn stopped" : "Learn"}
          </button>
          {me?.role === "admin" ? (
            <button
              type="button"
              onClick={() => setView(view === "admin" ? "discover" : "admin")}
              className={cn(
                "hidden h-8 items-center rounded-full px-3 text-xs font-semibold md:flex",
                view === "admin" ? "bg-fg text-bg" : "bg-chip text-muted",
              )}
            >
              Admin
            </button>
          ) : null}
          <DownloadApp />
          <button
            type="button"
            aria-label={alerts ? "Turn alerts off" : "Turn alerts on"}
            onClick={() => void toggleAlerts()}
            className={cn("grid size-8 place-items-center rounded-full", alerts ? "bg-fg text-bg" : "bg-chip text-muted")}
          >
            <Bell className="size-4" />
          </button>
          <button
            type="button"
            aria-label="Settings"
            onClick={() => setView(view === "settings" ? "discover" : "settings")}
            className={cn("grid size-8 place-items-center rounded-full", view === "settings" ? "bg-fg text-bg" : "bg-chip text-muted")}
          >
            <Settings className="size-4" />
          </button>
          <div className="acct-chip">
            <UserButton />
          </div>
        </div>
      </header>

      {recap.length ? (
        <div className="flex items-center gap-3 border-b border-line bg-raise px-3 py-2 text-xs">
          <span className="shrink-0 text-muted">While you were away</span>
          <span className="min-w-0 flex-1 truncate">{recap.join(" · ")}</span>
          <button type="button" className="text-faint" onClick={() => setRecap([])}>
            Dismiss
          </button>
        </div>
      ) : null}

      {view === "discover" ? (
        <div className="flex items-center gap-3 overflow-x-auto border-b border-line px-3 py-1.5 text-xs text-muted">
          <span className="shrink-0 font-semibold text-up">Free</span>
          <span className="shrink-0">{paperOn ? `Paper ${money(book.cash)}` : "Paper off"}</span>
          <span className="shrink-0">Rug check does not block</span>
          <span className="shrink-0">Tape is live</span>
          <button type="button" onClick={() => setView("learn")} className="ml-auto shrink-0 text-faint">
            {me && !me.learnOpen
              ? "Learn stopped"
              : me?.plan === "free"
                ? `Learn · ${clock(Math.max(0, FREE_LEARN_MS - me.learnUsedMs))} left`
                : "Learn"}
          </button>
        </div>
      ) : null}

      <div className="border-b border-line px-3 py-2 md:hidden">
        <SearchBox
          inputRef={searchRef}
          query={query}
          setQuery={setQuery}
          open={searchOpen}
          setOpen={setSearchOpen}
          searching={searching}
          hits={hits}
          traders={query.trim().length > 0 ? traderHits : []}
          onToken={(token) => {
            setSelected(token);
            setSearchOpen(false);
          }}
          onTrader={(person) => {
            setTrader(person);
            setSearchOpen(false);
          }}
        />
        <div className="mt-2 flex gap-1 overflow-x-auto">
          {(
            [
              ["hot", "Hot"],
              ["tokens", "Tokens"],
              ["traders", "Traders"],
              ["feed", "Tape"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                setView("discover");
                setPane(id);
              }}
              className={cn(
                "h-9 shrink-0 rounded-full px-3 text-xs font-medium",
                view === "discover" && pane === id ? "bg-fg text-bg" : "bg-chip text-muted",
              )}
            >
              {label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setView(view === "paper" ? "discover" : "paper")}
            className={cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium", view === "paper" ? "bg-fg text-bg" : "bg-chip text-muted")}
          >
            Paper{paperOn ? ` ${pnl(paperStats.equity - START_CASH)}` : ""}
          </button>
          <button
            type="button"
            onClick={() => setView(view === "wallets" ? "discover" : "wallets")}
            className={cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium", view === "wallets" ? "bg-fg text-bg" : "bg-chip text-muted")}
          >
            Wallets
          </button>
          <button
            type="button"
            onClick={() => setView(view === "learn" ? "discover" : "learn")}
            className={cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium", view === "learn" ? "bg-fg text-bg" : "bg-chip text-muted")}
          >
            {me && !me.learnOpen ? "Learn stopped" : "Learn"}
          </button>
          {me?.role === "admin" ? (
            <button
              type="button"
              onClick={() => setView(view === "admin" ? "discover" : "admin")}
              className={cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium", view === "admin" ? "bg-fg text-bg" : "bg-chip text-muted")}
            >
              Admin
            </button>
          ) : null}
        </div>
      </div>

      {view === "settings" ? (
        <div className="flex min-h-0 flex-1 flex-col">
          {me ? (
            <div className="shrink-0">
              <ProfileCard me={me} onSaved={setMe} />
            </div>
          ) : null}
          <SettingsPanel
            theme={theme}
            venue={venue}
            paperOn={paperOn}
            onPaper={setPaperOn}
            onVenue={setVenue}
            onChange={(key, value) => setTheme((current) => ({ ...current, [key]: value }))}
            onReset={() => setTheme(DEFAULT_THEME)}
            onImport={(next) => setTheme(next)}
            onClose={() => setView("discover")}
          />
        </div>
      ) : view === "learn" ? (
        me ? (
          <LearnDesk
            me={me}
            onClose={() => setView("discover")}
            onPaper={(text) => {
              setMission(text);
              setView("paper");
            }}
            onUsed={(patch) => setMe((current) => (current ? { ...current, ...patch } : current))}
          />
        ) : (
          <div className="grid flex-1 place-items-center text-sm text-muted">Opening Learn…</div>
        )
      ) : view === "admin" ? (
        <AdminDesk onClose={() => setView("discover")} />
      ) : view === "paper" ? (
        <PaperDesk
          book={book}
          tokens={tokens}
          mission={mission}
          onClose={() => setView("discover")}
          onSell={tradeSell}
          onStops={tradeStops}
          onReset={() =>
            setBook((current) => ({
              ...emptyBook(),
              wallets: current.wallets,
              copySize: current.copySize,
              sound: current.sound,
              alerted: current.alerted,
              alerts: current.alerts,
            }))
          }
          onCopySize={(usd) => setBook((current) => ({ ...current, copySize: Math.min(5000, Math.max(5, usd || 5)) }))}
        />
      ) : view === "wallets" ? (
        <WalletDesk
          book={book}
          events={walletEvents}
          onClose={() => setView("discover")}
          onAdd={(address, label) => {
            if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address)) {
              toast("That doesn't look like a Solana wallet");
              return;
            }
            setBook((current) =>
              current.wallets.some((wallet) => wallet.address === address)
                ? current
                : { ...current, wallets: [...current.wallets, { address, label: label || "Wallet", copy: false, filter: emptyFilter() }] },
            );
          }}
          onRemove={(address) => setBook((current) => ({ ...current, wallets: current.wallets.filter((wallet) => wallet.address !== address) }))}
          onToggleCopy={(address) =>
            setBook((current) => {
              const wallet = current.wallets.find((item) => item.address === address);
              const turningOn = wallet ? !wallet.copy : false;
              const seen = turningOn
                ? [...(walletEvents[address] ?? []).map((event) => event.id), ...current.seen].slice(0, 300)
                : current.seen;
              return {
                ...current,
                seen,
                wallets: current.wallets.map((item) => (item.address === address ? { ...item, copy: !item.copy } : item)),
              };
            })
          }
          onFilter={(address, patch) =>
            setBook((current) => ({
              ...current,
              wallets: current.wallets.map((wallet) =>
                wallet.address === address ? { ...wallet, filter: { ...wallet.filter, ...patch } } : wallet,
              ),
            }))
          }
          onPick={(event) => setSelected(tokenFromPrint({
            id: event.id,
            time: event.time,
            side: event.side,
            symbol: event.symbol,
            name: event.name,
            address: event.address,
            chain: event.chain,
            pair: event.pair,
            price: event.price,
            usd: event.usd,
            liquidity: event.liquidity,
            marketCap: event.marketCap,
          }))}
        />
      ) : (
      <div className="grid min-h-0 min-w-0 flex-1 gap-2 overflow-hidden p-2 lg:grid-cols-[248px_minmax(0,1fr)_280px]">
        <section className={cn("min-h-0 min-w-0 flex-col gap-2", pane === "hot" || pane === "traders" ? "flex" : "hidden", "lg:flex")}>
          <div className={cn("min-h-0 flex-col rounded-2xl border border-line bg-panel", pane === "traders" ? "hidden lg:flex" : "flex")}>
            <PanelHead title="Hot" extra={<span className="rounded-full bg-up/15 px-2 py-0.5 text-xs font-semibold text-up">Live</span>} />
            <div className="grid grid-cols-2 gap-2 p-2">
              {loading && movers.length === 0
                ? Array.from({ length: 6 }).map((_, index) => (
                    <div key={index} className="h-16 animate-pulse rounded-xl bg-raise" />
                  ))
                : movers.map((token) => {
                    const move = dollarMove(token, "h24");
                    return (
                      <button
                        key={token.id}
                        type="button"
                        onClick={() => setSelected(token)}
                        className="flex flex-col gap-2 rounded-xl bg-raise p-2.5 text-left transition hover:bg-chip"
                      >
                        <span className="flex items-center gap-2">
                          <Mark token={token} className="size-8" />
                          <span className="truncate text-sm font-semibold">{token.symbol}</span>
                        </span>
                        <span className={cn("text-sm font-semibold tabular-nums", move >= 0 ? "text-up" : "text-down")}>
                          {move >= 0 ? "+" : ""}
                          {money(move)}
                        </span>
                      </button>
                    );
                  })}
            </div>
          </div>
          <div className={cn("min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border border-line bg-panel", pane === "hot" ? "hidden lg:flex" : "flex")}>
            <div className="flex items-center justify-between border-b border-line px-3 py-2">
              <div className="flex gap-1">
                <span className="rounded-full bg-chip px-2.5 py-1 text-xs font-medium">Traders</span>
                <button
                  type="button"
                  onClick={() => setFollowOnly((on) => !on)}
                  className={cn("rounded-full px-2.5 py-1 text-xs", followOnly ? "bg-fg text-bg" : "text-faint")}
                >
                  Following
                </button>
              </div>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto">
              {TRADERS.filter((person) => person.pnl > 0)
                .filter((person) => !followOnly || followed.includes(person.handle))
                .map((person, index) => {
                const on = followed.includes(person.handle);
                return (
                  <button
                    key={person.handle}
                    type="button"
                    onClick={() => setTrader(person)}
                    className="flex w-full items-center gap-2 border-b border-line px-3 py-2.5 text-left hover:bg-raise"
                  >
                    <span className="w-4 text-xs text-faint">{index + 1}</span>
                    <Face handle={person.handle} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium">{person.handle}</span>
                    </span>
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(event) => {
                        event.stopPropagation();
                        setFollowed((current) =>
                          current.includes(person.handle)
                            ? current.filter((handle) => handle !== person.handle)
                            : [...current, person.handle],
                        );
                      }}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") {
                          event.stopPropagation();
                          setFollowed((current) =>
                            current.includes(person.handle)
                              ? current.filter((handle) => handle !== person.handle)
                              : [...current, person.handle],
                          );
                        }
                      }}
                      className={cn(
                        "rounded-full px-2 py-1 text-xs",
                        on ? "bg-fg text-bg" : "bg-chip text-muted",
                      )}
                    >
                      {on ? "Following" : "Follow"}
                    </span>
                    <span className="w-20 shrink-0 text-right text-xs font-semibold tabular-nums text-up">{pnl(person.pnl)}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        <section className={cn("min-h-0 min-w-0 flex-col overflow-hidden rounded-2xl border border-line bg-panel", pane === "tokens" ? "flex" : "hidden", "lg:flex")}>
          <div className="flex flex-wrap items-center gap-1 border-b border-line px-2 py-2">
            {FILTERS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setFilter(item.id)}
                className={cn(
                  "h-8 rounded-full px-3 text-xs font-medium",
                  filter === item.id ? "bg-fg text-bg" : "text-muted hover:bg-chip",
                )}
              >
                {item.label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-1 border-b border-line px-2 py-2">
            {WINDOWS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setWindowKey(item.id)}
                className={cn(
                  "h-7 rounded-full px-2.5 text-xs",
                  windowKey === item.id ? "bg-chip text-fg" : "text-faint hover:text-muted",
                )}
              >
                {item.label}
              </button>
            ))}
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value as SortId)}
              className="ml-auto h-7 rounded-full bg-chip px-2 text-xs text-fg outline-none"
            >
              <option value="mcap">Market cap</option>
              <option value="liq">Liquidity</option>
              <option value="age">Age</option>
            </select>
            <select
              value={chain}
              onChange={(event) => setChain(event.target.value)}
              className="h-7 rounded-full bg-chip px-2 text-xs capitalize text-fg outline-none"
            >
              {chains.map((item) => (
                <option key={item} value={item}>
                  {item === "all" ? "All chains" : item}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-wrap items-center gap-1 border-b border-line px-2 py-2">
            <input
              value={viewName}
              onChange={(event) => setViewName(event.target.value)}
              placeholder="Save this view"
              className="h-7 w-32 rounded-full bg-chip px-3 text-xs outline-none placeholder:text-faint"
            />
            <button type="button" onClick={saveView} className="h-7 rounded-full bg-chip px-2.5 text-xs text-muted">
              Save
            </button>
            {views.map((item) => (
              <button
                key={item.name}
                type="button"
                onClick={() => applyView(item)}
                className="h-7 rounded-full px-2.5 text-xs text-muted hover:bg-chip"
              >
                {item.name}
              </button>
            ))}
          </div>
          {filter === "perps" || filter === "pulse" ? null : (
          <div className="grid grid-cols-[minmax(0,1.4fr)_72px_88px_72px] items-center px-3 py-2 text-xs text-faint">
            <span>Token</span>
            <span className="text-right">Copy</span>
            <span className="text-right">Market cap</span>
            <span className="text-right">{WINDOWS.find((item) => item.id === windowKey)?.label}</span>
          </div>
          )}
          <div className="min-h-0 flex-1 overflow-y-auto">
            {filter === "perps" ? (
              perps.length === 0 ? (
                <p className="px-3 py-6 text-sm text-muted">Loading perps…</p>
              ) : (
                perps.map((row) => (
                  <div key={row.symbol} className="flex items-center gap-3 border-t border-line px-3 py-3">
                    <span className="grid size-8 place-items-center rounded-lg bg-chip text-xs font-semibold">{row.symbol}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-semibold">{row.symbol}</span>
                      <span className="block text-xs text-faint">{row.name}</span>
                    </span>
                    <span className="text-sm tabular-nums">{price(row.price)}</span>
                    <span className={cn("w-16 text-right text-sm font-medium tabular-nums", row.change >= 0 ? "text-up" : "text-down")}>
                      {pct(row.change)}
                    </span>
                  </div>
                ))
              )
            ) : filter === "pulse" ? (
              <PulseBoard tokens={tokens.filter((token) => chain === "all" || token.chain === chain)} onPick={setSelected} />
            ) : loading && tokens.length === 0 ? (
              <p className="px-3 py-6 text-sm text-muted">Loading live coins…</p>
            ) : error && tokens.length === 0 ? (
              <p className="px-3 py-6 text-sm text-down">{error}</p>
            ) : visible.length === 0 ? (
              <p className="px-3 py-6 text-sm text-muted">Nothing in this filter.</p>
            ) : (
              visible.map((token) => {
                const change = changeOf(token, windowKey);
                const hot = token.change.h24 > 40 || token.volume > 1_000_000;
                const starred = watch.includes(token.id);
                return (
                  <div
                    key={token.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => setSelected(token)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") setSelected(token);
                    }}
                    className="grid w-full grid-cols-[minmax(0,1.4fr)_72px_88px_72px] items-center border-t border-line px-3 py-2 text-left hover:bg-raise"
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <button
                        type="button"
                        aria-label={starred ? "Unstar" : "Star"}
                        onClick={(event) => {
                          event.stopPropagation();
                          toggleWatch(token);
                        }}
                        className={cn("text-faint", starred && "text-up")}
                      >
                        <Star className="size-3.5" fill={starred ? "currentColor" : "none"} />
                      </button>
                      <Mark token={token} className="size-8" />
                      <span className="min-w-0">
                        <span className="flex items-center gap-1">
                          <span className="truncate text-sm font-semibold">{token.symbol}</span>
                          {hot ? (
                            <span className="rounded bg-hot/15 px-1 text-xs font-bold text-hot">HOT</span>
                          ) : null}
                        </span>
                        <span className="block truncate text-xs text-faint">
                          {token.name} · {token.chain}
                          {filter === "new" && token.created ? ` · ${ago(token.created)}` : ""}
                        </span>
                      </span>
                    </span>
                    <span className="text-right">
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          copyCa(token.address);
                        }}
                        className="inline-flex h-7 items-center gap-1 rounded-full bg-chip px-2 text-xs text-muted"
                      >
                        <Copy className="size-3" />
                        CA
                      </button>
                    </span>
                    <span className="text-right text-sm tabular-nums">{money(token.marketCap)}</span>
                    <span className={cn("text-right text-sm font-medium tabular-nums", change >= 0 ? "text-up" : "text-down")}>
                      {pct(change)}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </section>

        <section className={cn("min-h-0 min-w-0 flex-col gap-2", pane === "feed" ? "flex" : "hidden", "lg:flex")}>
          <div className="rounded-2xl border border-line bg-panel">
            <PanelHead title="Your positions" />
            {watched.length === 0 ? (
              <p className="px-3 pb-3 text-sm text-faint">Star assets to pin them here</p>
            ) : (
              <div className="max-h-40 overflow-y-auto">
                {watched.map((token) => (
                  <button
                    key={token.id}
                    type="button"
                    onClick={() => setSelected(token)}
                    className="flex w-full items-center gap-2 border-t border-line px-3 py-2 text-left hover:bg-raise"
                  >
                    <Mark token={token} className="size-7" />
                    <span className="min-w-0 flex-1 truncate text-sm">{token.symbol}</span>
                    <span className={cn("text-xs font-medium", token.change.h24 >= 0 ? "text-up" : "text-down")}>
                      {pct(token.change.h24)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <TradeTape
            tokens={tokens}
            paperOn={paperOn}
            sound={book.sound}
            onToggleSound={() => setBook((current) => ({ ...current, sound: !current.sound }))}
            onPick={(print) => setSelected(tokenFromPrint(print))}
            onCopy={(print) => {
              const token = tokenFromPrint(print);
              if (!paperOn) {
                toast("Turn on paper trade in Settings");
                return;
              }
              tradeBuy(token, book.copySize, "copy");
            }}
          />
          <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-2xl border border-line bg-panel">
            <PanelHead title="Callouts" extra={<span className="text-xs text-faint">from live moves</span>} />
            <div className="min-h-0 flex-1 overflow-y-auto">
              {callouts.map((token) => (
                <button
                  key={token.id}
                  type="button"
                  onClick={() => setSelected(token)}
                  className="block w-full border-t border-line px-3 py-3 text-left hover:bg-raise"
                >
                  <span className="flex items-center gap-2">
                    <Mark token={token} className="size-8 rounded-full" />
                    <span className="text-sm font-semibold">{token.symbol}</span>
                    <span className="text-xs text-faint">{ago(token.created)}</span>
                  </span>
                  <span className="mt-2 block text-sm leading-snug text-fg">
                    {token.description ||
                      `${token.name} is ${pct(token.change.h1)} over the last hour, sitting at ${money(token.marketCap)} market cap.`}
                  </span>
                  {token.header ? (
                    <img src={token.header} alt="" className="mt-2 h-36 w-full rounded-xl object-cover" />
                  ) : null}
                  <span className="mt-2 flex items-center justify-between rounded-xl bg-raise px-2 py-2">
                    <span className="flex items-center gap-2">
                      <Mark token={token} className="size-8" />
                      <span>
                        <span className="block text-sm font-medium">{token.name}</span>
                        <span className="block text-xs text-faint">{token.symbol}</span>
                      </span>
                    </span>
                    <span className="text-right">
                      <span className="block text-sm tabular-nums">{price(token.price)}</span>
                      <span className={cn("block text-xs font-medium", token.change.h24 >= 0 ? "text-up" : "text-down")}>
                        {pct(token.change.h24)}
                      </span>
                    </span>
                  </span>
                </button>
              ))}
            </div>
          </div>
        </section>
      </div>
      )}

      <footer className="flex h-9 shrink-0 items-center gap-3 border-t border-line px-3 text-xs">
        <div className="flex min-w-0 flex-1 items-center gap-4 overflow-hidden">
          {majors.map((major) => (
            <span key={major.symbol} className="shrink-0 tabular-nums">
              <span className="text-faint">{major.symbol}</span> {price(major.price)}{" "}
              <span className={major.change >= 0 ? "text-up" : "text-down"}>{pct(major.change)}</span>
            </span>
          ))}
          <span className="hidden items-center gap-1 text-up sm:flex">
            <span className="size-1.5 rounded-full bg-up" /> Stable
          </span>
        </div>
        <div className="hidden items-center gap-3 md:flex">
          {perps.map((row) => (
            <span key={row.symbol} className="shrink-0 tabular-nums">
              <span className="text-faint">{row.symbol}</span> {price(row.price)}{" "}
              <span className={row.change >= 0 ? "text-up" : "text-down"}>{pct(row.change)}</span>
            </span>
          ))}
        </div>
        <div className="flex flex-1 items-center justify-end gap-3">
          <button type="button" className="text-faint" onClick={() => setLegal("privacy")}>
            Privacy
          </button>
          <button type="button" className="text-faint" onClick={() => setLegal("terms")}>
            Terms
          </button>
          <a className="text-muted" href={DISCORD_INVITE} target="_blank" rel="noreferrer">
            Discord
          </a>
          <a className="text-muted" href="https://instagram.com/oh.jwl" target="_blank" rel="noreferrer">
            Follow
          </a>
        </div>
      </footer>

      {selected ? (
        <CoinChart
          token={selected}
          venue={venue}
          rug={rug}
          rugLoading={rugLoading}
          similar={lookalikes(selected, tokens)}
          onPick={setSelected}
          onClose={() => setSelected(null)}
          onCopy={copyCa}
          onAlert={(target) => tradeAlert(selected, target)}
          onSwap={(usd) => void tradeSwap(selected, usd)}
          paper={{
            on: paperOn,
            cash: book.cash,
            qty: book.lots.find((lot) => lot.tokenId === selected.id)?.qty ?? 0,
            tp: book.lots.find((lot) => lot.tokenId === selected.id)?.tpPct ?? null,
            sl: book.lots.find((lot) => lot.tokenId === selected.id)?.slPct ?? null,
            safety: checkSafety(selected, rug),
            onBuy: (usd) => tradeBuy(selected, usd, "quick"),
            onSell: (fraction) => tradeSell(selected.id, fraction),
            onStops: (tp, sl) => tradeStops(selected.id, tp, sl),
            onCard: () => {
              const lot = book.lots.find((item) => item.tokenId === selected.id);
              if (!lot || !(lot.qty > 0)) {
                toast("Buy it on paper first, then save a card");
                return;
              }
              const mark = markPrice(lot.tokenId);
              const avg = lot.cost / lot.qty;
              downloadPnlCard({
                symbol: lot.symbol,
                entry: avg,
                mark: mark || avg,
                pnlUsd: mark > 0 ? lot.qty * mark - lot.cost : 0,
                pct: mark > 0 ? ((mark - avg) / avg) * 100 : 0,
                label: "Open",
              });
            },
          }}
        >
          <MentionList query={`$${selected.symbol}`} onCopy={copyCa} />
        </CoinChart>
      ) : null}

      {trader ? (
        <dialog open className="fixed inset-0 z-30 grid place-items-center bg-bg/80 p-4" onClick={() => setTrader(null)}>
          <div className="w-full max-w-sm rounded-2xl border border-line bg-panel p-4" onClick={(event) => event.stopPropagation()}>
            <div className="flex items-center gap-3">
              <Face handle={trader.handle} />
              <div>
                <div className="font-semibold">@{trader.handle}</div>
                <div className="text-xs text-faint">{trader.window} featured</div>
              </div>
            </div>
            <div className="mt-3 text-2xl font-semibold text-up">{pnl(trader.pnl)}</div>
            <p className="mt-2 text-xs text-faint">
              Latest posts from this handle. If a contract is in the text, copy it. Wallet fills are not published for these accounts.
            </p>
            <MentionList query={`from:${trader.handle}`} onCopy={copyCa} />
            <a
              href={`https://x.com/${trader.handle}`}
              target="_blank"
              rel="noreferrer"
              className="mt-4 grid h-10 place-items-center rounded-full bg-fg text-sm font-semibold text-bg"
            >
              Open on X
            </a>
          </div>
        </dialog>
      ) : null}

      {legal ? (
        <dialog open className="fixed inset-0 z-30 grid place-items-center bg-bg/80 p-4" onClick={() => setLegal(null)}>
          <div
            className="max-h-full w-full max-w-lg overflow-y-auto rounded-2xl border border-line bg-panel p-4"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">{legal === "privacy" ? "Privacy" : "Terms"}</h2>
              <button type="button" className="text-sm text-muted" onClick={() => setLegal(null)}>
                Close
              </button>
            </div>
            {legal === "privacy" ? <PrivacyBody /> : <TermsBody />}
          </div>
        </dialog>
      ) : null}
    </div>
  );
}

function LegalBlock({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-4">
      <h3 className="text-sm font-semibold">{title}</h3>
      <div className="mt-1 space-y-2 text-sm leading-relaxed text-muted">{children}</div>
    </section>
  );
}

function TermsBody() {
  return (
    <div>
      <p className="mt-2 text-xs text-faint">Last updated 12 November 2026</p>
      <LegalBlock title="What this is">
        <p>
          MemeTrack is a read-only tracker. It shows public market data, featured trader handles, and a simple
          perpetuals quote strip. It does not custody funds, execute trades, or act as your broker, agent, or advisor.
        </p>
      </LegalBlock>
      <LegalBlock title="Risk">
        <p>
          Memecoins can go to zero. Prices, liquidity, and rug labels come from third-party feeds and can be wrong,
          delayed, or incomplete. A “Good” rug label is not a guarantee. Perpetual quotes on the bottom bar are
          indicative only and are not an offer to trade.
        </p>
        <p>Nothing on MemeTrack is financial, legal, or tax advice. You are responsible for your own decisions and losses.</p>
      </LegalBlock>
      <LegalBlock title="Who can use it">
        <p>
          You must be at least 18 and allowed to use a crypto information site where you live. Do not use MemeTrack if
          doing so would break the law in your location.
        </p>
      </LegalBlock>
      <LegalBlock title="Data and links">
        <p>
          Coin prices, charts, and rug checks are pulled from public APIs. Trader names and PnL figures on the board
          are a snapshot of public handles, not a live leaderboard. External links (X, Discord, Instagram, chart sites)
          are third-party services we do not control.
        </p>
      </LegalBlock>
      <LegalBlock title="Your use">
        <p>
          Do not scrape the site in a way that overloads it, do not misrepresent MemeTrack as an exchange, and do not
          use it to spread false market information. We can change or remove features at any time.
        </p>
      </LegalBlock>
      <LegalBlock title="No warranty">
        <p>
          The site is provided as is. We do not promise it will be accurate, available, or error-free. To the extent
          the law allows, we are not liable for trading losses, missed data, or downtime.
        </p>
      </LegalBlock>
    </div>
  );
}

function DiscordHold({ onJoined, mark }: { onJoined: () => void; mark: () => Promise<unknown> }) {
  const discord = useDiscordJoin();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function finish() {
    if (!discord.ready) return;
    setBusy(true);
    setError("");
    try {
      await mark();
      onJoined();
    } catch {
      setError("Could not save that. Open the invite and try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid h-dvh place-items-center bg-bg px-6 text-fg">
      <div className="w-full max-w-sm text-center">
        <h1 className="text-2xl font-semibold tracking-tight">Join the Discord</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          This account is not finished until you join the MemeTrack Discord. The paper desk stays closed until you do.
        </p>
        <a
          href={discord.invite}
          target="_blank"
          rel="noreferrer"
          onClick={discord.markOpened}
          className="mt-5 grid h-11 w-full place-items-center rounded-full bg-fg text-sm font-semibold text-bg"
        >
          {discord.opened ? "Invite opened" : "Open the invite"}
        </a>
        <label className="mt-4 flex items-start justify-center gap-2 text-left text-sm">
          <input
            type="checkbox"
            className="mt-1"
            checked={discord.agreed}
            disabled={!discord.opened}
            onChange={(event) => discord.setAgreed(event.target.checked)}
          />
          I joined the server
        </label>
        {error ? <p className="mt-2 text-sm text-down">{error}</p> : null}
        <button
          type="button"
          disabled={!discord.ready || busy}
          onClick={() => void finish()}
          className="mt-4 grid h-11 w-full place-items-center rounded-full bg-hot text-sm font-semibold text-bg disabled:opacity-40"
        >
          {busy ? "Saving…" : "Continue"}
        </button>
      </div>
    </div>
  );
}

function PrivacyBody() {
  return (
    <div>
      <p className="mt-2 text-xs text-faint">Last updated 12 November 2026</p>
      <LegalBlock title="What we store">
        <p>
          An account holds your name, email, handle, bio, Learn progress, and whether you confirmed joining the Discord.
          Stars, follows, paper trades, alerts, and theme colors stay in this browser.
        </p>
      </LegalBlock>
      <LegalBlock title="What we do not collect">
        <p>
          We do not take custody of a wallet or store private keys. Buys open an outside venue, or you sign a swap in
          your own wallet. There is no referral program. We do not sell personal data, and we do not run voice chat or
          livestreams.
        </p>
      </LegalBlock>
      <LegalBlock title="Third-party feeds">
        <p>
          When the page loads coins, perps, or a rug check, your browser talks directly to public market APIs
          (DexScreener, Coinbase, RugCheck, and similar). Those services see a normal web request from your device and
          handle it under their own policies. Trader avatars may load from a public avatar service.
        </p>
      </LegalBlock>
      <LegalBlock title="Cookies">
        <p>
          MemeTrack does not set its own tracking cookies. Your browser or the preview host may set technical cookies
          needed to serve the page. You can block cookies in your browser settings.
        </p>
      </LegalBlock>
      <LegalBlock title="Age">
        <p>MemeTrack is not for anyone under 18. If a minor has used it, close the tab and clear site data.</p>
      </LegalBlock>
      <LegalBlock title="Your choices">
        <p>
          Clear this site’s local data to remove stars, follows, paper trades, and theme settings. Account profile and Learn
          progress stay until you delete the account with an admin.
        </p>
      </LegalBlock>
    </div>
  );
}
function MentionList({ query, onCopy }: { query: string; onCopy: (address: string) => void }) {
  const run = useServerFn(loadMentions);
  const [rows, setRows] = useState<Mention[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");

  useEffect(() => {
    setRows(null);
    setNote("");
  }, [query]);

  async function load() {
    setBusy(true);
    setNote("");
    try {
      const result = await run({ data: { query } });
      if (!result.ok) {
        setRows([]);
        setNote(result.error);
        return;
      }
      setRows(result.rows);
      if (result.rows.length === 0) setNote("No posts came back.");
    } catch {
      setRows([]);
      setNote("X search failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mt-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold text-faint">X</p>
        <button type="button" onClick={() => void load()} className="text-xs text-muted">
          {busy ? "Loading…" : rows ? "Refresh" : "Load posts"}
        </button>
      </div>
      {note ? <p className="mt-1 text-xs text-muted">{note}</p> : null}
      <div className="mt-1 space-y-2">
        {rows?.map((post) => (
          <div key={post.url} className="rounded-xl bg-raise px-3 py-2">
            <a href={post.url} target="_blank" rel="noreferrer" className="block text-sm hover:underline">
              <span className="text-muted">@{post.handle}</span> {post.text}
            </a>
            {contractIn(post.text).map((address) => (
              <button
                key={address}
                type="button"
                onClick={() => onCopy(address)}
                className="mt-1 mr-2 text-xs text-up"
              >
                Copy {shortAddr(address)}
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function PanelHead({ title, extra }: { title: string; extra?: ReactNode }) {
  return (
    <div className="flex items-center justify-between px-3 py-2">
      <h2 className="text-sm font-semibold">{title}</h2>
      {extra}
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "up" | "down" }) {
  return (
    <div className="rounded-xl bg-raise px-2 py-2">
      <div className="text-xs text-faint">{label}</div>
      <div className={cn("text-sm font-semibold tabular-nums", tone === "up" && "text-up", tone === "down" && "text-down")}>
        {value}
      </div>
    </div>
  );
}

function SearchBox({
  inputRef,
  query,
  setQuery,
  open,
  setOpen,
  searching,
  hits,
  traders,
  onToken,
  onTrader,
}: {
  inputRef: RefObject<HTMLInputElement | null>;
  query: string;
  setQuery: (value: string) => void;
  open: boolean;
  setOpen: (value: boolean) => void;
  searching: boolean;
  hits: Token[];
  traders: readonly { handle: string; pnl: number; window: string }[];
  onToken: (token: Token) => void;
  onTrader: (trader: (typeof TRADERS)[number]) => void;
}) {
  return (
    <div className="relative">
      <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-faint" />
      <input
        ref={inputRef}
        value={query}
        onChange={(event) => {
          setQuery(event.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder="Search for tokens, perps or traders..."
        className="h-9 w-full rounded-full border border-line bg-panel pr-16 pl-9 text-sm outline-none placeholder:text-faint"
      />
      <kbd className="absolute top-1/2 right-3 -translate-y-1/2 rounded-md bg-chip px-1.5 text-xs text-faint">/</kbd>
      {open && query.trim().length > 0 ? (
        <div className="absolute top-11 z-20 max-h-80 w-full overflow-y-auto rounded-2xl border border-line bg-panel p-1 shadow-2xl">
          <p className="px-2 pt-1 text-xs font-semibold text-faint">Traders</p>
          {traders.length === 0 ? (
            <p className="px-3 py-2 text-sm text-muted">No traders for that name.</p>
          ) : (
            traders.map((person) => (
              <button
                key={person.handle}
                type="button"
                onClick={() => onTrader(person as (typeof TRADERS)[number])}
                className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-left hover:bg-raise"
              >
                <Face handle={person.handle} />
                <span className="min-w-0 flex-1 truncate text-sm">@{person.handle}</span>
                {person.pnl > 0 ? <span className="text-xs text-up">{pnl(person.pnl)}</span> : null}
              </button>
            ))
          )}
          <p className="px-2 pt-2 text-xs font-semibold text-faint">Tokens</p>
          {searching ? <p className="px-3 py-2 text-sm text-muted">Searching…</p> : null}
          {hits.map((token) => (
            <button
              key={token.id}
              type="button"
              onClick={() => onToken(token)}
              className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-left hover:bg-raise"
            >
              <Mark token={token} className="size-7" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium">{token.symbol}</span>
                <span className="block truncate text-xs text-faint">{token.chain}</span>
              </span>
              <span className={cn("text-xs", token.change.h24 >= 0 ? "text-up" : "text-down")}>{pct(token.change.h24)}</span>
            </button>
          ))}
          {!searching && hits.length === 0 ? <p className="px-3 py-2 text-sm text-muted">No token matches.</p> : null}
        </div>
      ) : null}
    </div>
  );
}

function SettingsPanel({
  theme,
  venue,
  paperOn,
  onPaper,
  onVenue,
  onChange,
  onReset,
  onImport,
  onClose,
}: {
  theme: Theme;
  venue: VenueId;
  paperOn: boolean;
  onPaper: (on: boolean) => void;
  onVenue: (venue: VenueId) => void;
  onChange: (key: keyof Theme, value: string) => void;
  onReset: () => void;
  onImport: (theme: Theme) => void;
  onClose: () => void;
}) {
  const [code, setCode] = useState("");
  const share = btoa(unescape(encodeURIComponent(JSON.stringify(theme))));

  function copyCode() {
    navigator.clipboard?.writeText(share).then(
      () => toast("Theme code copied"),
      () => toast("Couldn't copy the theme code"),
    );
  }

  function applyCode() {
    try {
      const parsed = JSON.parse(decodeURIComponent(escape(atob(code.trim())))) as Partial<Theme>;
      const next = { ...DEFAULT_THEME };
      for (const field of THEME_FIELDS) {
        const value = parsed[field.key];
        if (typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value)) next[field.key] = value;
      }
      onImport(next);
      toast("Theme applied");
    } catch {
      toast("That theme code is not valid");
    }
  }

  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-3">
      <div className="mx-auto flex max-w-xl flex-col gap-3">
        <section className="rounded-2xl border border-line bg-panel p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Primary trading network</h2>
            <button type="button" className="text-sm text-muted" onClick={onClose}>
              Done
            </button>
          </div>
          <p className="mt-1 text-sm text-muted">The Buy button on every coin chart opens this venue.</p>
          <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
            {VENUES.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onVenue(item.id)}
                className={cn(
                  "rounded-xl px-3 py-3 text-left",
                  venue === item.id ? "bg-fg text-bg" : "bg-raise text-fg",
                )}
              >
                <span className="block text-sm font-semibold">{item.label}</span>
                <span className={cn("mt-1 block text-xs", venue === item.id ? "opacity-70" : "text-faint")}>{item.blurb}</span>
              </button>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-between gap-3 rounded-xl bg-raise px-3 py-3">
            <div>
              <p className="text-sm font-semibold">Paper trade</p>
              <p className="text-xs text-faint">
                Practice with a $10,000 account. Risky and Bad coins can still be bought. The rug note is informational.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onPaper(!paperOn)}
              className={cn("h-9 shrink-0 rounded-full px-3 text-sm font-semibold", paperOn ? "bg-fg text-bg" : "bg-chip text-muted")}
            >
              {paperOn ? "On" : "Off"}
            </button>
          </div>
        </section>
        <section className="rounded-2xl border border-line bg-panel p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Theme</h2>
        </div>
        <p className="mt-1 text-sm text-muted">Dark, grey, slate, and light sets. Changes apply immediately.</p>
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {THEME_PRESETS.map((preset) => {
            const selected = THEME_FIELDS.every((field) => preset.theme[field.key].toLowerCase() === theme[field.key].toLowerCase());
            return (
            <button
              key={preset.id}
              type="button"
              onClick={() => onImport(preset.theme)}
              className={cn("rounded-xl px-3 py-2 text-left", selected ? "bg-fg text-bg" : "bg-raise")}
            >
              <span className="flex items-center gap-2">
                <span className="size-4 rounded-full border border-line" style={{ background: preset.theme.hot }} />
                <span className="text-sm font-semibold">{preset.label}</span>
              </span>
            </button>
            );
          })}
        </div>
        <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {THEME_FIELDS.map((field) => (
            <label key={field.key} className="flex items-center justify-between gap-3 rounded-xl bg-raise px-3 py-2">
              <span className="text-sm">{field.label}</span>
              <span className="flex items-center gap-2">
                <span className="text-xs text-faint">{theme[field.key]}</span>
                <input
                  type="color"
                  value={theme[field.key]}
                  onChange={(event) => onChange(field.key, event.target.value)}
                  className="size-8 cursor-pointer rounded-md border border-line bg-transparent"
                />
              </span>
            </label>
          ))}
        </div>
        <div className="mt-4 rounded-xl bg-raise p-3">
          <p className="text-xs text-faint">Share this theme</p>
          <p className="mt-1 break-all text-xs text-muted">{share}</p>
          <button type="button" onClick={copyCode} className="mt-2 h-8 rounded-full bg-chip px-3 text-xs">
            Copy code
          </button>
          <input
            value={code}
            onChange={(event) => setCode(event.target.value)}
            placeholder="Paste a theme code"
            className="mt-2 h-9 w-full rounded-full bg-chip px-3 text-xs outline-none placeholder:text-faint"
          />
          <button type="button" onClick={applyCode} className="mt-2 h-8 rounded-full bg-chip px-3 text-xs">
            Apply code
          </button>
        </div>
        <button
          type="button"
          onClick={onReset}
          className="mt-4 h-10 w-full rounded-full bg-fg text-sm font-semibold text-bg"
        >
          Restore default
        </button>
        </section>
      </div>
    </div>
  );
}

function PerpsPanel({ rows, onClose }: { rows: Perp[]; onClose: () => void }) {
  const chains = rows.filter((row) => row.group === "chain");
  const stocks = rows.filter((row) => row.group === "stock");
  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-3">
      <div className="mx-auto flex max-w-3xl flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Perpetuals</h2>
          <button type="button" className="text-sm text-muted" onClick={onClose}>
            Back
          </button>
        </div>
        <section className="rounded-2xl border border-line bg-panel">
          <PanelHead title="Chains" extra={<span className="text-xs text-faint">BTC · XRP · SOL · ETH · BNB</span>} />
          {chains.length === 0 ? <p className="px-3 pb-3 text-sm text-muted">Loading quotes…</p> : chains.map((row) => <PerpRow key={row.symbol} row={row} />)}
        </section>
        <section className="rounded-2xl border border-line bg-panel">
          <PanelHead title="AI and crypto-linked stocks" extra={<span className="text-xs text-faint">moves that pull memecoins</span>} />
          {stocks.length === 0 ? <p className="px-3 pb-3 text-sm text-muted">Loading quotes…</p> : stocks.map((row) => <PerpRow key={row.symbol} row={row} />)}
        </section>
      </div>
    </div>
  );
}

function PerpRow({ row }: { row: Perp }) {
  return (
    <div className="flex items-center gap-3 border-t border-line px-3 py-3">
      <span className="grid size-9 place-items-center rounded-lg bg-chip text-xs font-semibold">{row.symbol.slice(0, 3)}</span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-semibold">{row.symbol}</span>
        <span className="block truncate text-xs text-faint">{row.name}</span>
      </span>
      <span className="text-sm tabular-nums">{price(row.price)}</span>
      <span className={cn("w-16 text-right text-sm font-medium tabular-nums", row.change >= 0 ? "text-up" : "text-down")}>
        {pct(row.change)}
      </span>
    </div>
  );
}
