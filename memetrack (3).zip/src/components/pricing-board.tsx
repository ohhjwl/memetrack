import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { requestPlan } from "@/lib/accounts";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { PLANS, TERMS, moneyExact, periodPrice, type TermId } from "@/lib/pricing";
import { cn } from "@/lib/utils";

export function PricingBoard({ surface = "dark" }: { surface?: "dark" | "app" }) {
  const [termId, setTermId] = useState<TermId>("month");
  const term = TERMS.find((item) => item.id === termId) ?? TERMS[0];
  const { user, isPending } = useCurrentUserState();
  const ask = useServerFn(requestPlan);
  const navigate = useNavigate();
  const dark = surface === "dark";

  function choose(plan: (typeof PLANS)[number]["id"]) {
    if (isPending) return;
    if (!user) {
      void navigate({ to: "/login" });
      return;
    }
    void ask({ data: { plan, term: term.id } })
      .then((result) => {
        if (!result.ok) toast("Could not save that plan");
        else toast("Request saved. A card is not charged yet.");
      })
      .catch(() => toast("Could not save that plan"));
  }

  return (
    <div>
      <div className={cn("flex flex-wrap justify-center gap-1", dark ? "" : "")}>
        {TERMS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTermId(item.id)}
            className={cn(
              "h-9 rounded-full px-3 text-xs font-medium",
              termId === item.id
                ? dark
                  ? "bg-white text-black"
                  : "bg-fg text-bg"
                : dark
                  ? "bg-white/10 text-white/70"
                  : "bg-chip text-muted",
            )}
          >
            {item.label}
            {item.off ? ` · ${Math.round(item.off * 100)}% off` : ""}
          </button>
        ))}
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-3">
        {PLANS.map((plan) => {
          const total = periodPrice(plan.monthly, term);
          const per = Math.round((total / term.months) * 100) / 100;
          return (
            <article
              key={plan.id}
              className={cn(
                "flex flex-col rounded-3xl border p-4 text-left",
                dark ? "border-white/15 bg-white/[0.04]" : "border-line bg-panel",
              )}
            >
              <p className={cn("text-xs uppercase tracking-[0.16em]", dark ? "text-white/45" : "text-faint")}>{plan.limit}</p>
              <h3 className="mt-1 text-xl font-semibold">{plan.name}</h3>
              <p className="mt-3 text-4xl font-semibold tabular-nums">{moneyExact(total)}</p>
              <p className={cn("text-xs", dark ? "text-white/55" : "text-faint")}>
                {term.months === 1 ? "per month" : `${moneyExact(per)} / mo · billed every ${term.months} months`}
                {term.off ? ` · save ${moneyExact(Math.round((plan.monthly * term.months - total) * 100) / 100)}` : ""}
              </p>
              <ul className={cn("mt-4 flex-1 space-y-2 text-sm", dark ? "text-white/75" : "text-muted")}>
                {plan.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() => choose(plan.id)}
                className={cn("mt-5 h-11 rounded-full text-sm font-semibold", dark ? "landing-cta" : "bg-hot text-bg")}
              >
                Get {plan.name}
              </button>
            </article>
          );
        })}
      </div>
      <p className={cn("mt-3 text-center text-xs leading-relaxed", dark ? "text-white/40" : "text-faint")}>
        Paper trading, the rug check, and the live tape stay free. Card checkout is not connected, so choosing a plan saves a request instead of charging you.
      </p>
    </div>
  );
}
