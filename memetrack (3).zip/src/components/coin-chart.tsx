import { useEffect, useRef, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CHART_FRAMES, estimateCandles, loadCandles, type Candle, type FrameId } from "@/lib/candles";
import type { RugReport, Token } from "@/lib/market";
import type { Safety } from "@/lib/paper";
import { cn, money, pct, price, shortAddr } from "@/lib/utils";
import { buyUrl, venueLabel, type VenueId } from "@/lib/venues";
import { bondingEstimate } from "@/lib/pulse";

type PlacedMark = {
  id: string;
  x: number;
  y: number;
  tag: string;
  fill: string;
  ink: string;
  size: number;
  z: number;
};

const MARK_FILLS = ["#f5c518", "#22c55e", "#60a5fa", "#a78bfa", "#fb923c", "#f472b6", "#34d399", "#38bdf8", "#facc15", "#fb7185"];
const MARK_TAGS = ["SB", "DB", "MJ", "KR", "AX", "NV", "LT", "WM", "HC", "JR", "PL", "QK"];

function cssColor(name: string, fallback: string) {
  if (typeof document === "undefined") return fallback;
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

export function CoinChart({
  token,
  venue,
  rug,
  rugLoading,
  similar,
  onPick,
  onClose,
  onCopy,
  onAlert,
  onSwap,
  children,
  paper,
}: {
  token: Token;
  venue: VenueId;
  rug: RugReport | null;
  rugLoading: boolean;
  similar: Token[];
  onPick: (token: Token) => void;
  onClose: () => void;
  onCopy: (address: string) => void;
  onAlert: (target: number) => void;
  onSwap: (usd: number) => void;
  children?: ReactNode;
  paper?: {
    on: boolean;
    cash: number;
    qty: number;
    tp: number | null;
    sl: number | null;
    safety: Safety | null;
    onBuy: (usd: number) => void;
    onSell: (fraction: number) => void;
    onStops: (tp: number | null, sl: number | null) => void;
    onCard: () => void;
  };
}) {
  const [frame, setFrame] = useState<FrameId>("5m");
  const [candles, setCandles] = useState<Candle[]>([]);
  const [live, setLive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [hover, setHover] = useState<Candle | null>(null);
  const [showMa, setShowMa] = useState(false);
  const [showVol, setShowVol] = useState(false);
  const [showMarks, setShowMarks] = useState(true);
  const [marks, setMarks] = useState<PlacedMark[]>([]);
  const [alertAt, setAlertAt] = useState("");
  const host = useRef<HTMLDivElement>(null);
  const run = useServerFn(loadCandles);
  const label = venueLabel(venue);
  const href = buyUrl(venue, token);
  const bond = bondingEstimate(token);
  const last = candles[candles.length - 1];
  const shown = hover ?? last;
  const up = shown ? shown.close >= shown.open : token.change.h24 >= 0;

  useEffect(() => {
    let stop = false;
    setLoading(true);
    setHover(null);
    run({ data: { chain: token.chain, pair: token.pair, address: token.address, frame } })
      .then((result) => {
        if (stop) return;
        if (result.candles.length) {
          setCandles(result.candles);
          setLive(result.live);
        } else {
          setCandles(estimateCandles(token.price, token.change.h24));
          setLive(false);
        }
      })
      .catch(() => {
        if (stop) return;
        setCandles(estimateCandles(token.price, token.change.h24));
        setLive(false);
      })
      .finally(() => {
        if (!stop) setLoading(false);
      });
    return () => {
      stop = true;
    };
  }, [run, token.id, token.chain, token.pair, token.address, token.price, token.change.h24, frame]);

  useEffect(() => {
    const node = host.current;
    if (!node || candles.length === 0) return;
    let dead = false;
    let chart: { remove: () => void } | null = null;
    let watcher: ResizeObserver | null = null;

    void import("lightweight-charts").then((lib) => {
      if (dead || !host.current) return;
      const rawBg = cssColor("--color-bg", "#07070a");
      const text = cssColor("--color-faint", "#6a6a74");
      const well = chartWell(rawBg);
      const grid = luminance(well) > 150 ? mixHex(well, "#64748b", 0.4) : mixHex(well, "#ffffff", 0.12);
      const upColor = cssColor("--color-up", "#3ddc84");
      const downColor = cssColor("--color-down", "#ff4d6d");
      const instance = lib.createChart(host.current, {
        autoSize: true,
        layout: {
          background: { type: lib.ColorType.Solid, color: well },
          textColor: text,
          fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif",
          fontSize: 11,
        },
        grid: {
          vertLines: { color: grid, style: lib.LineStyle.Solid },
          horzLines: { color: grid, style: lib.LineStyle.Solid },
        },
        rightPriceScale: {
          borderVisible: false,
          scaleMargins: { top: 0.14, bottom: showVol ? 0.2 : 0.08 },
        },
        timeScale: {
          borderVisible: false,
          timeVisible: frame !== "1D",
          secondsVisible: false,
          rightOffset: 6,
        },
        crosshair: {
          mode: lib.CrosshairMode.Normal,
          vertLine: { color: text, style: lib.LineStyle.Dashed, labelBackgroundColor: grid, width: 1 },
          horzLine: { color: text, style: lib.LineStyle.Dashed, labelBackgroundColor: grid, width: 1 },
        },
        handleScroll: true,
        handleScale: true,
      });
      chart = instance;
      if (dead) {
        instance.remove();
        return;
      }
      const series = instance.addSeries(lib.CandlestickSeries, {
        upColor,
        downColor,
        wickUpColor: upColor,
        wickDownColor: downColor,
        borderUpColor: upColor,
        borderDownColor: downColor,
        borderVisible: true,
      });
      if (showVol) {
        const volume = instance.addSeries(lib.HistogramSeries, {
          priceFormat: { type: "volume" },
          priceScaleId: "volume",
        });
        instance.priceScale("volume").applyOptions({ scaleMargins: { top: 0.84, bottom: 0 } });
        volume.setData(
          candles.map((bar) => ({
            time: bar.time as import("lightweight-charts").UTCTimestamp,
            value: bar.volume,
            color: fade(bar.close >= bar.open ? upColor : downColor, 0.35),
          })),
        );
      }
      series.setData(
        candles.map((bar) => ({
          time: bar.time as import("lightweight-charts").UTCTimestamp,
          open: bar.open,
          high: bar.high,
          low: bar.low,
          close: bar.close,
        })),
      );
      if (showMa) {
        const fast = movingAverage(candles, 7);
        const slow = movingAverage(candles, 21);
        const ma7 = instance.addSeries(lib.LineSeries, {
          color: cssColor("--color-hot", "#ff5a36"),
          lineWidth: 2,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
        });
        const ma21 = instance.addSeries(lib.LineSeries, {
          color: cssColor("--color-muted", "#9a9aa6"),
          lineWidth: 2,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
        });
        ma7.setData(fast);
        ma21.setData(slow);
      }
      instance.timeScale().fitContent();
      const flow = flowMarks(candles, token.address);
      const redraw = () => {
        if (dead || !showMarks) {
          setMarks([]);
          return;
        }
        const next: PlacedMark[] = [];
        for (const mark of flow) {
          const x = instance.timeScale().timeToCoordinate(mark.time as import("lightweight-charts").UTCTimestamp);
          const y = series.priceToCoordinate(mark.price);
          if (x == null || y == null) continue;
          next.push({ ...mark, x, y });
        }
        setMarks(next);
      };
      redraw();
      instance.timeScale().subscribeVisibleLogicalRangeChange(redraw);
      watcher = new ResizeObserver(() => redraw());
      if (host.current) watcher.observe(host.current);
      instance.subscribeCrosshairMove((param) => {
        const stamp = typeof param.time === "number" ? param.time : 0;
        const bar = param.seriesData.get(series);
        if (!stamp || !bar || !("close" in bar) || typeof bar.close !== "number") {
          setHover(null);
          return;
        }
        const match = candles.find((item) => item.time === stamp);
        setHover({
          time: stamp,
          open: "open" in bar && typeof bar.open === "number" ? bar.open : (match?.open ?? bar.close),
          high: "high" in bar && typeof bar.high === "number" ? bar.high : (match?.high ?? bar.close),
          low: "low" in bar && typeof bar.low === "number" ? bar.low : (match?.low ?? bar.close),
          close: bar.close,
          volume: match?.volume ?? 0,
        });
      });
    });

    return () => {
      dead = true;
      watcher?.disconnect();
      chart?.remove();
      setMarks([]);
    };
  }, [candles, frame, showMa, showVol, showMarks, token.address]);

  useEffect(() => {
    if (!paper?.on) return;
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      const buys: Record<string, number> = { "1": 25, "2": 50, "3": 100, "4": 250 };
      if (buys[event.key]) {
        event.preventDefault();
        paper.onBuy(buys[event.key]);
      } else if (event.key === "q" && paper.qty > 0) paper.onSell(0.25);
      else if (event.key === "w" && paper.qty > 0) paper.onSell(0.5);
      else if (event.key === "e" && paper.qty > 0) paper.onSell(1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [paper]);

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-bg text-fg">
      <header className="flex shrink-0 flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <button type="button" onClick={onClose} className="h-10 rounded-full bg-chip px-3 text-sm text-muted">
          Back
        </button>
        <div className="min-w-0">
          <div className="truncate text-base font-semibold">
            {token.symbol} <span className="text-sm font-normal text-faint">{token.name}</span>
          </div>
          <div className="text-xs text-faint">
            {token.chain} · {shortAddr(token.address)}
          </div>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          <div className="text-right">
            <div className="text-lg font-semibold tabular-nums">{price(shown?.close ?? token.price)}</div>
            <div className={cn("text-xs font-medium tabular-nums", token.change.h24 >= 0 ? "text-up" : "text-down")}>
              {pct(token.change.h24)} 24h
            </div>
          </div>
          <a
            href={href}
            target="_blank"
            rel="noreferrer"
            className="grid h-10 place-items-center rounded-full bg-fg px-4 text-sm font-semibold text-bg"
          >
            Buy on {label}
          </a>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <section className="flex min-h-0 min-w-0 flex-1 flex-col">
          <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
            <div className="flex gap-1">
              {CHART_FRAMES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setFrame(item.id)}
                  className={cn(
                    "h-8 rounded-full px-3 text-xs font-medium",
                    frame === item.id ? "bg-fg text-bg" : "bg-chip text-muted",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setShowMa((on) => !on)}
              className={cn("h-8 rounded-full px-3 text-xs font-medium", showMa ? "bg-hot text-bg" : "bg-chip text-muted")}
            >
              MA
            </button>
            <button
              type="button"
              onClick={() => setShowVol((on) => !on)}
              className={cn("h-8 rounded-full px-3 text-xs font-medium", showVol ? "bg-fg text-bg" : "bg-chip text-muted")}
            >
              Vol
            </button>
            <button
              type="button"
              onClick={() => setShowMarks((on) => !on)}
              className={cn("h-8 rounded-full px-3 text-xs font-medium", showMarks ? "bg-fg text-bg" : "bg-chip text-muted")}
            >
              Bubbles
            </button>
            <p className="text-xs text-faint">{live ? "Pool candles" : loading ? "Loading candles…" : "Estimated path"}</p>
          </div>
          <div className="relative min-h-80 flex-1 overflow-hidden">
            {loading && candles.length === 0 ? (
              <div className="absolute inset-0 grid place-items-center text-sm text-muted">Loading chart…</div>
            ) : null}
            <div ref={host} className="absolute inset-0" />
            <div className="pointer-events-none absolute inset-0 overflow-hidden">
              {marks.map((mark) => (
                <span
                  key={mark.id}
                  className="absolute grid place-items-center rounded-full font-bold leading-none"
                  style={{
                    left: mark.x,
                    top: mark.y,
                    width: mark.size,
                    height: mark.size,
                    fontSize: mark.size > 30 ? 11 : 9,
                    transform: "translate(-50%, -50%)",
                    background: mark.fill,
                    color: mark.ink,
                    boxShadow: "0 1px 2px rgba(0,0,0,0.45)",
                    zIndex: mark.z,
                  }}
                >
                  {mark.tag}
                </span>
              ))}
            </div>
            {shown ? (
              <div className="pointer-events-none absolute left-3 top-2 max-w-[70%]">
                <p className="text-xs text-muted">
                  {token.symbol}/USD · {frame} · {label}
                </p>
                <p className={cn("text-xs tabular-nums", up ? "text-up" : "text-down")}>
                  O {price(shown.open)} H {price(shown.high)} L {price(shown.low)} C {price(shown.close)}
                  {shown.volume > 0 ? ` · Vol ${money(shown.volume)}` : ""}
                </p>
              </div>
            ) : null}
          </div>
        </section>

        <aside className="max-h-[42dvh] shrink-0 overflow-y-auto border-t border-line lg:max-h-none lg:w-80 lg:border-t-0 lg:border-l">
          <div className="grid grid-cols-3 gap-2 p-3 text-center">
            <Cell label="Mcap" value={money(token.marketCap)} />
            <Cell label="Liq" value={money(token.liquidity)} />
            <Cell
              label="Rug"
              value={token.chain === "solana" ? (rugLoading ? "…" : (rug?.label ?? "—")) : "n/a"}
              tone={rug?.label === "Good" ? "up" : rug?.label === "Bad" || rug?.label === "Risky" ? "down" : undefined}
            />
            <Cell label="Vol" value={money(token.volume)} />
            <Cell label="5m" value={pct(token.change.m5)} tone={token.change.m5 >= 0 ? "up" : "down"} />
            <Cell label="1h" value={pct(token.change.h1)} tone={token.change.h1 >= 0 ? "up" : "down"} />
            {bond != null ? <Cell label="Bond est." value={`${bond.toFixed(0)}%`} tone="hot" /> : null}
          </div>
          <p className="px-3 text-xs text-muted">
            Buys {token.buys24} · Sells {token.sells24}
            {rug?.locked != null ? ` · LP locked ${rug.locked.toFixed(0)}%` : ""}
            {rug?.totalHolders != null ? ` · ${rug.totalHolders.toLocaleString()} holders` : ""}
          </p>
          {paper?.on ? (
            <div className="px-3 pt-3">
              <p className="text-xs text-muted">
                Paper cash {money(paper.cash)}
                {paper.qty > 0 ? ` · holding ${paper.qty < 1 ? paper.qty.toPrecision(3) : paper.qty.toFixed(2)}` : ""}
              </p>
              {paper.safety && paper.safety.reasons.length > 0 ? (
                <p className="mt-1 text-xs text-muted">{paper.safety.reasons.join(" · ")}. Buy is still open.</p>
              ) : (
                <p className="mt-1 text-xs text-up">Safety clear</p>
              )}
              <div className="mt-2 flex flex-wrap gap-1">
                {[25, 50, 100, 250].map((usd) => (
                  <button
                    key={usd}
                    type="button"
                    onClick={() => paper.onBuy(usd)}
                    className="h-9 rounded-full bg-up px-3 text-xs font-semibold text-bg"
                  >
                    {`Buy $${usd}`}
                  </button>
                ))}
              </div>
              {paper.qty > 0 ? (
                <div className="mt-1 flex flex-wrap gap-1">
                  {[0.25, 0.5, 1].map((fraction) => (
                    <button
                      key={fraction}
                      type="button"
                      onClick={() => paper.onSell(fraction)}
                      className="h-9 rounded-full bg-down px-3 text-xs font-semibold text-bg"
                    >
                      {fraction === 1 ? "Sell all" : `Sell ${fraction * 100}%`}
                    </button>
                  ))}
                  <button type="button" onClick={paper.onCard} className="h-9 rounded-full bg-chip px-3 text-xs">
                    Card
                  </button>
                </div>
              ) : null}
              {paper.qty > 0 ? (
                <div className="mt-1 flex flex-wrap gap-1">
                  {[50, 100].map((tp) => (
                    <button
                      key={tp}
                      type="button"
                      onClick={() => paper.onStops(paper.tp === tp ? null : tp, paper.sl)}
                      className={cn("h-8 rounded-full px-2.5 text-xs", paper.tp === tp ? "bg-up text-bg" : "bg-chip text-muted")}
                    >
                      TP +{tp}%
                    </button>
                  ))}
                  {[20, 35].map((sl) => (
                    <button
                      key={sl}
                      type="button"
                      onClick={() => paper.onStops(paper.tp, paper.sl === sl ? null : sl)}
                      className={cn("h-8 rounded-full px-2.5 text-xs", paper.sl === sl ? "bg-down text-bg" : "bg-chip text-muted")}
                    >
                      SL -{sl}%
                    </button>
                  ))}
                </div>
              ) : null}
              <p className="mt-1 text-xs text-faint">Keys 1–4 buy $25 to $250. Q W E sell 25, 50, all.</p>
            </div>
          ) : null}
          <div className="px-3 pt-3">
            <a
              href={href}
              target="_blank"
              rel="noreferrer"
              className="grid h-11 place-items-center rounded-full bg-hot text-sm font-semibold text-bg"
            >
              Buy on {label}
            </a>
            {token.chain === "solana" ? (
              <button
                type="button"
                onClick={() => onSwap(50)}
                className="mt-2 grid h-10 w-full place-items-center rounded-full bg-chip text-sm"
              >
                Swap $50 in wallet
              </button>
            ) : null}
            <p className="mt-2 text-xs text-faint">
              The wallet swap is non-custodial and takes no MemeTrack fee. If no wallet is injected here, use Buy on {label}.
            </p>
            <form
              className="mt-2 flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                const target = Number(alertAt);
                if (target > 0) onAlert(target);
              }}
            >
              <input
                value={alertAt}
                onChange={(event) => setAlertAt(event.target.value)}
                inputMode="decimal"
                placeholder="Alert price"
                className="h-9 min-w-0 flex-1 rounded-full bg-chip px-3 text-sm outline-none placeholder:text-faint"
              />
              <button type="submit" className="h-9 rounded-full bg-chip px-3 text-xs">
                Alert
              </button>
            </form>
          </div>
          <div className="flex gap-2 px-3 pt-3">
            <button type="button" onClick={() => onCopy(token.address)} className="h-10 flex-1 rounded-full bg-chip text-sm">
              Copy CA
            </button>
            <a href={token.url} target="_blank" rel="noreferrer" className="grid h-10 place-items-center rounded-full bg-chip px-4 text-sm">
              Pair
            </a>
          </div>
          {rug && rug.holders.length > 0 ? (
            <div className="px-3 pt-3">
              <p className="text-xs font-semibold text-faint">Top holders</p>
              <div className="mt-1 space-y-1">
                {rug.holders.map((holder, index) => {
                  const tags = holderTags(holder.pct, index, rug.mintOn);
                  return (
                    <div key={holder.address} className="flex items-center justify-between gap-2 text-xs">
                      <span className="text-muted">{shortAddr(holder.address)}</span>
                      <span className="text-faint">{tags}</span>
                      <span className={cn("tabular-nums", holder.pct >= 10 ? "text-down" : "text-fg")}>{holder.pct.toFixed(1)}%</span>
                    </div>
                  );
                })}
              </div>
              <p className="mt-1 text-xs text-faint">Concentrated means 10% or more. Possible dev is only a guess: largest holder while mint is still on.</p>
            </div>
          ) : null}
          {similar.length > 0 ? (
            <div className="px-3 pt-3">
              <p className="text-xs font-semibold text-faint">Similar</p>
              <div className="mt-1 flex flex-wrap gap-1">
                {similar.map((item) => (
                  <button key={item.id} type="button" onClick={() => onPick(item)} className="h-8 rounded-full bg-chip px-2.5 text-xs">
                    {item.symbol}
                  </button>
                ))}
              </div>
            </div>
          ) : null}
          <div className="px-3 pb-4">{children}</div>
        </aside>
      </div>
    </div>
  );
}

function movingAverage(candles: Candle[], length: number) {
  const rows: { time: import("lightweight-charts").UTCTimestamp; value: number }[] = [];
  let sum = 0;
  for (let i = 0; i < candles.length; i += 1) {
    sum += candles[i].close;
    if (i >= length) sum -= candles[i - length].close;
    if (i >= length - 1) rows.push({ time: candles[i].time as import("lightweight-charts").UTCTimestamp, value: sum / length });
  }
  return rows;
}

function holderTags(pctHeld: number, index: number, mintOn: boolean | null) {
  const tags: string[] = [];
  if (pctHeld >= 10) tags.push("Concentrated");
  if (index === 0 && mintOn) tags.push("Possible dev");
  return tags.join(" · ");
}

function Cell({ label, value, tone }: { label: string; value: string; tone?: "up" | "down" | "hot" }) {
  return (
    <div className="rounded-xl bg-raise px-2 py-2">
      <div className="text-xs text-faint">{label}</div>
      <div className={cn("text-sm font-semibold tabular-nums", tone === "up" && "text-up", tone === "down" && "text-down", tone === "hot" && "text-hot")}>{value}</div>
    </div>
  );
}

function fade(color: string, alpha: number) {
  if (color.startsWith("#") && (color.length === 7 || color.length === 4)) {
    const hex = color.length === 4 ? `#${color[1]}${color[1]}${color[2]}${color[2]}${color[3]}${color[3]}` : color;
    const a = Math.round(Math.min(1, Math.max(0, alpha)) * 255)
      .toString(16)
      .padStart(2, "0");
    return `${hex}${a}`;
  }
  return color;
}

function luminance(fill: string) {
  if (!fill.startsWith("#") || fill.length < 7) return 0;
  const n = Number.parseInt(fill.slice(1, 7), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return 0.299 * r + 0.587 * g + 0.114 * b;
}

function mixHex(from: string, to: string, amount: number) {
  if (!from.startsWith("#") || from.length < 7 || !to.startsWith("#") || to.length < 7) return from;
  const a = Number.parseInt(from.slice(1, 7), 16);
  const b = Number.parseInt(to.slice(1, 7), 16);
  const mix = (shift: number) => {
    const left = (a >> shift) & 255;
    const right = (b >> shift) & 255;
    return Math.round(left + (right - left) * amount);
  };
  const r = mix(16);
  const g = mix(8);
  const bl = mix(0);
  return `#${[r, g, bl].map((part) => part.toString(16).padStart(2, "0")).join("")}`;
}

function chartWell(bg: string) {
  if (luminance(bg) > 150) return bg;
  return mixHex(bg, "#243044", 0.78);
}

function inkFor(fill: string) {
  return luminance(fill) > 160 ? "#141418" : "#ffffff";
}

function hashSeed(seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i += 1) h = Math.imul(h ^ seed.charCodeAt(i), 16777619);
  return h >>> 0;
}

function mulberry(seed: number) {
  let h = seed || 1;
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };
}

function flowMarks(candles: Candle[], seed: string) {
  if (candles.length < 4) return [];
  const rand = mulberry(hashSeed(seed));
  const marks: { id: string; time: number; price: number; tag: string; fill: string; ink: string; size: number; z: number }[] = [];
  let z = 1;
  const push = (bar: Candle, price: number, tag: string, fill: string, k: number, size: number) => {
    const span = Math.max(bar.high - bar.low, bar.close * 0.004);
    const clamped = Math.min(bar.high + span * 0.85, Math.max(bar.low, price));
    marks.push({ id: `${bar.time}-${k}-${tag}-${marks.length}`, time: bar.time, price: clamped, tag, fill, ink: inkFor(fill), size, z });
    z += 1;
  };

  const stackAt = Math.min(candles.length - 8, Math.max(4, Math.floor(candles.length * (0.32 + rand() * 0.08))));
  const stackBar = candles[stackAt];
  const stackTag = MARK_TAGS[Math.floor(rand() * 4)];
  const stackFill = "#f5c518";
  for (let k = 0; k < 9; k += 1) {
    const t = k / 8;
    push(stackBar, stackBar.low + (stackBar.high - stackBar.low) * (0.15 + t * 1.15), stackTag, stackFill, k, 28);
  }

  candles.forEach((bar, i) => {
    if (i === stackAt) return;
    const t = i / (candles.length - 1);
    const rising = bar.close >= bar.open;
    let count = 0;
    if (t > 0.78) count = 5 + Math.floor(rand() * 5);
    else if (t > 0.58) count = 2 + Math.floor(rand() * 3);
    else if (t > 0.35 && rand() < 0.5) count = 1;
    else if (rand() < 0.12) count = 1;
    const span = Math.max(bar.high - bar.low, bar.close * 0.01);
    for (let k = 0; k < count; k += 1) {
      const fill = rising ? MARK_FILLS[Math.floor(rand() * MARK_FILLS.length)] : "#f43f5e";
      const tag = MARK_TAGS[Math.floor(rand() * MARK_TAGS.length)];
      const along = bar.close + (rand() - 0.35) * span * (t > 0.7 ? 1.4 : 0.6);
      const size = t > 0.8 && rand() < 0.35 ? 34 : 22 + Math.floor(rand() * 10);
      push(bar, along, tag, fill, k + 20, size);
    }
  });
  return marks.slice(-150);
}
