import { useMemo, useState, type Dispatch, type SetStateAction } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, YAxis } from "recharts";
import type { Book } from "@/lib/paper";
import { START_CASH, summarize } from "@/lib/paper";
import type { Token } from "@/lib/market";
import { downloadPnlCard } from "@/lib/pnl-card";
import { cn, money, pnl, price } from "@/lib/utils";

export function PaperDesk({
  book,
  tokens,
  onClose,
  onSell,
  onReset,
  onCopySize,
  onStops,
  mission,
}: {
  book: Book;
  tokens: Token[];
  onClose: () => void;
  onSell: (tokenId: string, fraction: number) => void;
  onReset: () => void;
  onCopySize: (usd: number) => void;
  onStops: (tokenId: string, tp: number | null, sl: number | null) => void;
  mission?: string;
}) {
  const [cursor, setCursor] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  });
  const mark = (tokenId: string) =>
    tokens.find((token) => token.id === tokenId)?.price ?? book.fills.find((fill) => fill.tokenId === tokenId)?.price ?? 0;
  const stats = summarize(book, mark);
  const monthLabel = new Date(cursor.year, cursor.month, 1).toLocaleString(undefined, { month: "long", year: "numeric" });
  const cells = useMemo(() => monthCells(cursor.year, cursor.month), [cursor.year, cursor.month]);
  let monthPnl = 0;
  for (const day of cells) {
    if (day) monthPnl += stats.byDay.get(`${cursor.year}-${cursor.month}-${day}`) ?? 0;
  }
  const curve = book.equity.map((point) => ({ t: point.t, v: point.v }));

  return (
    <div className="min-h-0 flex-1 overflow-y-auto p-3">
      <div className="mx-auto flex max-w-3xl flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Paper account</h2>
            <p className="text-sm text-muted">Live marks, fake money. Nothing here is a real order.</p>
          </div>
          <button type="button" className="text-sm text-muted" onClick={onClose}>
            Done
          </button>
        </div>
        {mission ? <p className="rounded-xl bg-raise px-3 py-2 text-sm text-muted">{mission}</p> : null}
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Card label="Equity" value={pnl(stats.equity - START_CASH)} hint={money(stats.equity)} tone={stats.equity - START_CASH} />
          <Card label="Cash" value={money(book.cash)} hint="available" />
          <Card label="Open PnL" value={pnl(stats.unrealized)} tone={stats.unrealized} />
          <Card label="Today" value={pnl(stats.today)} hint={`${stats.wins}/${stats.sells || 0} wins`} tone={stats.today} />
        </div>
        <section className="rounded-2xl border border-line bg-panel p-3">
          <h3 className="text-sm font-semibold">Equity</h3>
          {curve.length < 2 ? (
            <p className="mt-2 text-sm text-muted">The curve starts after the next price refresh.</p>
          ) : (
            <div className="mt-2 h-36">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={curve}>
                  <YAxis hide domain={["auto", "auto"]} />
                  <Tooltip
                    formatter={(value) => money(Number(value))}
                    labelFormatter={(label) => new Date(Number(label)).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
                    contentStyle={{
                      background: "var(--color-panel)",
                      border: "1px solid var(--color-line)",
                      borderRadius: 12,
                      color: "var(--color-fg)",
                    }}
                  />
                  <Area type="monotone" dataKey="v" stroke="var(--color-up)" fill="var(--color-up)" fillOpacity={0.15} strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>
        <section className="rounded-2xl border border-line bg-panel p-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold">Realized calendar</h3>
            <div className="flex items-center gap-2 text-sm">
              <span className={cn("hidden tabular-nums sm:inline", monthPnl >= 0 ? "text-up" : "text-down")}>{pnl(monthPnl)}</span>
              <button type="button" className="rounded-full bg-chip px-2 text-muted" onClick={() => shift(setCursor, -1)} aria-label="Previous month">
                ‹
              </button>
              <span className="text-muted">{monthLabel}</span>
              <button type="button" className="rounded-full bg-chip px-2 text-muted" onClick={() => shift(setCursor, 1)} aria-label="Next month">
                ›
              </button>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-7 gap-1 text-center text-xs text-faint">
            {["S", "M", "T", "W", "T", "F", "S"].map((day, index) => (
              <span key={`${day}-${index}`}>{day}</span>
            ))}
            {cells.map((day, index) => {
              const value = day ? stats.byDay.get(`${cursor.year}-${cursor.month}-${day}`) : undefined;
              return (
                <div
                  key={`${cursor.year}-${cursor.month}-${index}`}
                  className={cn(
                    "flex min-h-12 flex-col items-center justify-center rounded-lg",
                    day ? "bg-raise" : "",
                    value !== undefined && value > 0 && "bg-up/15 text-up",
                    value !== undefined && value < 0 && "bg-down/15 text-down",
                  )}
                >
                  {day ? <span className="text-xs text-faint">{day}</span> : null}
                  {value !== undefined ? <span className="text-xs font-semibold tabular-nums">{pnl(value)}</span> : null}
                </div>
              );
            })}
          </div>
        </section>
        <section className="rounded-2xl border border-line bg-panel">
          <div className="flex items-center justify-between px-3 py-2">
            <h3 className="text-sm font-semibold">Positions</h3>
            <label className="flex items-center gap-2 text-xs text-faint">
              Copy size
              <input
                type="number"
                min={5}
                max={5000}
                value={book.copySize}
                onChange={(event) => onCopySize(Number(event.target.value))}
                className="h-8 w-20 rounded-full bg-chip px-2 text-sm text-fg outline-none"
              />
            </label>
          </div>
          {book.lots.length === 0 ? <p className="px-3 pb-3 text-sm text-muted">No open paper positions yet.</p> : null}
          {book.lots.map((lot) => {
            const px = mark(lot.tokenId);
            const avg = lot.cost / lot.qty;
            const open = px > 0 ? lot.qty * px - lot.cost : 0;
            const change = px > 0 ? ((px - avg) / avg) * 100 : 0;
            return (
              <div key={lot.tokenId} className="border-t border-line px-3 py-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-semibold">{lot.symbol}</span>
                    <span className="block text-xs text-faint">
                      {price(px || avg)} · avg {price(avg)}
                      {lot.tpPct ? ` · TP +${lot.tpPct}%` : ""}
                      {lot.slPct ? ` · SL -${lot.slPct}%` : ""}
                    </span>
                  </span>
                  <span className={cn("text-sm font-semibold tabular-nums", open >= 0 ? "text-up" : "text-down")}>{pnl(open)}</span>
                  <button
                    type="button"
                    onClick={() =>
                      downloadPnlCard({
                        symbol: lot.symbol,
                        entry: avg,
                        mark: px || avg,
                        pnlUsd: open,
                        pct: change,
                        label: "Open",
                      })
                    }
                    className="h-8 rounded-full bg-chip px-2.5 text-xs"
                  >
                    Card
                  </button>
                  {[0.25, 0.5, 1].map((fraction) => (
                    <button
                      key={fraction}
                      type="button"
                      onClick={() => onSell(lot.tokenId, fraction)}
                      className="h-8 rounded-full bg-chip px-2.5 text-xs"
                    >
                      {fraction === 1 ? "Sell all" : `${fraction * 100}%`}
                    </button>
                  ))}
                </div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {[50, 100].map((tp) => (
                    <button
                      key={tp}
                      type="button"
                      onClick={() => onStops(lot.tokenId, lot.tpPct === tp ? null : tp, lot.slPct)}
                      className={cn("h-8 rounded-full px-2.5 text-xs", lot.tpPct === tp ? "bg-up text-bg" : "bg-chip text-muted")}
                    >
                      TP +{tp}%
                    </button>
                  ))}
                  {[20, 35].map((sl) => (
                    <button
                      key={sl}
                      type="button"
                      onClick={() => onStops(lot.tokenId, lot.tpPct, lot.slPct === sl ? null : sl)}
                      className={cn("h-8 rounded-full px-2.5 text-xs", lot.slPct === sl ? "bg-down text-bg" : "bg-chip text-muted")}
                    >
                      SL -{sl}%
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </section>
        {book.alerts.length > 0 ? (
          <section className="rounded-2xl border border-line bg-panel">
            <h3 className="px-3 py-2 text-sm font-semibold">Price alerts</h3>
            {book.alerts.map((alert) => (
              <div key={alert.id} className="flex items-center gap-2 border-t border-line px-3 py-2 text-sm">
                <span className="min-w-0 flex-1 truncate">{alert.symbol}</span>
                <span className="text-xs text-faint">{alert.above ? "at or above" : "at or below"}</span>
                <span className="tabular-nums">{price(alert.target)}</span>
                <span className={cn("text-xs", alert.fired ? "text-up" : "text-muted")}>{alert.fired ? "Hit" : "Armed"}</span>
              </div>
            ))}
          </section>
        ) : null}
        <section className="rounded-2xl border border-line bg-panel">
          <h3 className="px-3 py-2 text-sm font-semibold">Fills</h3>
          {book.fills.length === 0 ? <p className="px-3 pb-3 text-sm text-muted">Buys and sells land here.</p> : null}
          {book.fills.slice(0, 12).map((fill) => {
            const entry = fill.qty > 0 ? (fill.side === "sell" ? (fill.usd - fill.pnl) / fill.qty : fill.price) : fill.price;
            const change = entry > 0 && fill.side === "sell" ? ((fill.price - entry) / entry) * 100 : 0;
            return (
              <div key={fill.id} className="flex items-center gap-2 border-t border-line px-3 py-2 text-sm">
                <span className={cn("w-10 text-xs font-semibold", fill.side === "buy" ? "text-up" : "text-down")}>{fill.side}</span>
                <span className="min-w-0 flex-1 truncate">{fill.symbol}</span>
                <span className="text-xs text-faint">{fill.source}</span>
                <span className="tabular-nums">{money(fill.usd)}</span>
                {fill.side === "sell" ? (
                  <span className={cn("tabular-nums", fill.pnl >= 0 ? "text-up" : "text-down")}>{pnl(fill.pnl)}</span>
                ) : null}
                {fill.side === "sell" ? (
                  <button
                    type="button"
                    onClick={() =>
                      downloadPnlCard({
                        symbol: fill.symbol,
                        entry,
                        mark: fill.price,
                        pnlUsd: fill.pnl,
                        pct: change,
                        label: "Closed",
                      })
                    }
                    className="h-8 rounded-full bg-chip px-2.5 text-xs"
                  >
                    Card
                  </button>
                ) : null}
              </div>
            );
          })}
        </section>
        <button type="button" onClick={onReset} className="h-10 rounded-full bg-chip text-sm text-muted">
          Reset paper account
        </button>
      </div>
    </div>
  );
}

function Card({ label, value, hint, tone }: { label: string; value: string; hint?: string; tone?: number }) {
  return (
    <div className="rounded-2xl border border-line bg-panel px-3 py-3">
      <div className="text-xs text-faint">{label}</div>
      <div className={cn("mt-1 text-lg font-semibold tabular-nums", tone !== undefined && (tone >= 0 ? "text-up" : "text-down"))}>{value}</div>
      {hint ? <div className="text-xs text-faint">{hint}</div> : null}
    </div>
  );
}

function shift(setCursor: Dispatch<SetStateAction<{ year: number; month: number }>>, delta: number) {
  setCursor((current) => {
    const date = new Date(current.year, current.month + delta, 1);
    return { year: date.getFullYear(), month: date.getMonth() };
  });
}

function monthCells(year: number, month: number) {
  const first = new Date(year, month, 1).getDay();
  const count = new Date(year, month + 1, 0).getDate();
  const cells: Array<number | null> = Array.from({ length: first }, () => null);
  for (let day = 1; day <= count; day += 1) cells.push(day);
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}
