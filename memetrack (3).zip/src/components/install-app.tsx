import { useEffect, useState } from "react";
import { Download } from "lucide-react";

type InstallPrompt = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type DeviceKind = "ios" | "android" | "mac" | "windows" | "other";

function deviceKind(): DeviceKind {
  const ua = navigator.userAgent;
  const touch = navigator.maxTouchPoints || 0;
  const iPad = /iPad/.test(ua) || (/Macintosh/.test(ua) && touch > 1);
  if (/iPhone|iPod/.test(ua) || iPad) return "ios";
  if (/Android/i.test(ua)) return "android";
  if (/Win/.test(ua)) return "windows";
  if (/Mac/.test(ua)) return "mac";
  return "other";
}

function alreadyInstalled() {
  const nav = navigator as Navigator & { standalone?: boolean };
  return window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
}

export function DownloadApp() {
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState<InstallPrompt | null>(null);
  const [installed, setInstalled] = useState(false);
  const [kind, setKind] = useState<DeviceKind>("other");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setKind(deviceKind());
    setInstalled(alreadyInstalled());

    if ("serviceWorker" in navigator && import.meta.env.PROD) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }

    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPrompt(event as InstallPrompt);
    };
    const onInstalled = () => {
      setInstalled(true);
      setPrompt(null);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  async function install() {
    if (!prompt) return;
    setBusy(true);
    try {
      await prompt.prompt();
      const choice = await prompt.userChoice;
      if (choice.outcome === "accepted") setInstalled(true);
      setPrompt(null);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        type="button"
        aria-label="Download app"
        onClick={() => setOpen(true)}
        className="flex h-8 items-center gap-1.5 rounded-full bg-fg px-2.5 text-xs font-semibold text-bg"
      >
        <Download className="size-3.5" />
        <span className="hidden sm:inline">{installed ? "Installed" : "Download"}</span>
      </button>
      {open ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-bg/80 p-4" onClick={() => setOpen(false)}>
          <div
            role="dialog"
            aria-labelledby="download-title"
            className="max-h-full w-full max-w-md overflow-y-auto rounded-2xl border border-line bg-panel p-4"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 id="download-title" className="text-lg font-semibold">
                  Download MemeTrack
                </h2>
                <p className="mt-1 text-sm text-muted">
                  Install it on your iPhone, Mac, or Windows. It opens full screen. Your watchlist, theme, and venue stay on that device.
                </p>
              </div>
              <button type="button" className="text-sm text-muted" onClick={() => setOpen(false)}>
                Close
              </button>
            </div>

            {installed ? (
              <p className="mt-4 rounded-xl bg-raise px-3 py-3 text-sm">MemeTrack is already installed on this device.</p>
            ) : prompt ? (
              <button
                type="button"
                disabled={busy}
                onClick={() => void install()}
                className="mt-4 grid h-11 w-full place-items-center rounded-full bg-fg text-sm font-semibold text-bg disabled:opacity-60"
              >
                {busy ? "Installing…" : "Install MemeTrack"}
              </button>
            ) : (
              <p className="mt-4 text-xs text-faint">
                If you are viewing this inside another app, open MemeTrack in Safari, Chrome, or Edge to finish installing.
              </p>
            )}

            <ol className="mt-4 space-y-3">
              <Step
                title={kind === "ios" ? "This iPhone or iPad" : "iPhone or iPad"}
                body="In Safari, tap Share, then Add to Home Screen, then Add."
              />
              <Step
                title={kind === "mac" ? "This Mac" : "Mac"}
                body="Safari: File, then Add to Dock. Chrome: the install icon in the address bar, or the menu, then Install MemeTrack."
              />
              <Step
                title={kind === "windows" ? "This Windows PC" : "Windows"}
                body="In Chrome or Edge, open the menu and choose Install MemeTrack. You can also use the install icon in the address bar."
              />
              {kind === "android" ? (
                <Step title="This Android phone" body="Tap Install above, or open the browser menu and choose Install app or Add to Home screen." />
              ) : null}
            </ol>
          </div>
        </div>
      ) : null}
    </>
  );
}

function Step({ title, body }: { title: string; body: string }) {
  return (
    <li className="rounded-xl bg-raise px-3 py-3">
      <p className="text-sm font-semibold">{title}</p>
      <p className="mt-1 text-sm text-muted">{body}</p>
    </li>
  );
}
