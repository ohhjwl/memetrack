import type { Token } from "@/lib/market";
import { bondingEstimate, pulseColumns } from "@/lib/pulse";
import { money, pct } from "@/lib/utils";

export function PulseBoard({ tokens, onPick }: { tokens: Token[]; onPick: (token: Token) => void }) {
  const columns = pulseColumns(tokens);
  return (
    <div className="grid h-full min-h-0 grid-cols-1 gap-2 overflow-y-auto p-2 md:grid-cols-3 md:overflow-hidden">
      {columns.map((column) => (
        <div key={column.id} className="flex min-h-48 flex-col overflow-hidden rounded-xl bg-raise md:min-h-0">
          <div className="px-3 py-2">
            <p className="text-sm font-semibold">{column.title}</p>
            <p className="text-xs text-faint">{column.note}</p>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">
            {column.rows.length === 0 ? <p className="px-3 pb-3 text-sm text-muted">Nothing in this column yet.</p> : null}
            {column.rows.map((token) => {
              const bond = bondingEstimate(token);
              return (
                <button
                  key={token.id}
                  type="button"
                  onClick={() => onPick(token)}
                  className="flex w-full items-center gap-2 border-t border-line px-3 py-2 text-left hover:bg-chip"
                >
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold">{token.symbol}</span>
                    <span className="block truncate text-xs text-faint">{money(token.marketCap)}</span>
                  </span>
                  {bond != null ? <span className="text-xs tabular-nums text-hot">{bond.toFixed(0)}%</span> : null}
                  <span className={token.change.h1 >= 0 ? "text-xs text-up" : "text-xs text-down"}>{pct(token.change.h1)}</span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
