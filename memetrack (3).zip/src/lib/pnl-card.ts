function cssColor(name: string, fallback: string) {
  if (typeof document === "undefined") return fallback;
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

export function downloadPnlCard(input: {
  symbol: string;
  entry: number;
  mark: number;
  pnlUsd: number;
  pct: number;
  label: string;
}) {
  const canvas = document.createElement("canvas");
  canvas.width = 1200;
  canvas.height = 675;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const bg = cssColor("--color-bg", "#07070a");
  const panel = cssColor("--color-panel", "#101014");
  const fg = cssColor("--color-fg", "#f4f4f6");
  const muted = cssColor("--color-muted", "#9a9aa6");
  const up = cssColor("--color-up", "#3ddc84");
  const down = cssColor("--color-down", "#ff4d6d");
  const hot = cssColor("--color-hot", "#ff5a36");
  const positive = input.pnlUsd >= 0;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = panel;
  roundRect(ctx, 48, 48, 1104, 579, 36);
  ctx.fill();
  ctx.fillStyle = hot;
  ctx.fillRect(48, 48, 12, 579);
  ctx.fillStyle = muted;
  ctx.font = "500 28px Inter, sans-serif";
  ctx.fillText("MemeTrack paper", 96, 130);
  ctx.fillStyle = fg;
  ctx.font = "700 72px Inter, sans-serif";
  ctx.fillText(input.symbol, 96, 230);
  ctx.fillStyle = muted;
  ctx.font = "500 28px Inter, sans-serif";
  ctx.fillText(input.label, 96, 280);
  ctx.fillStyle = positive ? up : down;
  ctx.font = "700 92px Inter, sans-serif";
  const pctText = `${input.pct >= 0 ? "+" : ""}${input.pct.toFixed(2)}%`;
  ctx.fillText(pctText, 96, 400);
  ctx.font = "600 36px Inter, sans-serif";
  const usd = `${input.pnlUsd >= 0 ? "+" : "-"}$${Math.abs(input.pnlUsd).toFixed(2)}`;
  ctx.fillText(usd, 96, 460);
  ctx.fillStyle = muted;
  ctx.font = "500 26px Inter, sans-serif";
  ctx.fillText(`Entry ${fmt(input.entry)}    Mark ${fmt(input.mark)}`, 96, 540);
  ctx.fillText("Practice account. Not a real fill.", 96, 580);
  const link = document.createElement("a");
  link.href = canvas.toDataURL("image/png");
  link.download = `memetrack-${input.symbol.toLowerCase()}-pnl.png`;
  link.click();
}

function fmt(n: number) {
  if (!Number.isFinite(n) || n === 0) return "$0";
  if (n >= 1) return `$${n.toFixed(4)}`;
  return `$${n.toPrecision(3)}`;
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
