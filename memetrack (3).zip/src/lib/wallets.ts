import { createServerFn } from "@tanstack/react-start";

export type WalletEvent = {
  id: string;
  time: number;
  side: "buy" | "sell";
  symbol: string;
  name: string;
  address: string;
  chain: "solana";
  pair: string;
  price: number;
  usd: number;
  qty: number;
  liquidity: number;
  marketCap: number;
};

const STABLES = new Set([
  "So11111111111111111111111111111111111111112",
  "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
]);

const cache = new Map<string, { at: number; events: WalletEvent[] }>();

function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

async function rpc(method: string, params: unknown[]) {
  const res = await fetch("https://api.mainnet-beta.solana.com", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  if (!res.ok) throw new Error(String(res.status));
  const body = (await res.json()) as { result?: unknown; error?: { message?: string } };
  if (body.error) throw new Error(body.error.message || "rpc");
  return body.result;
}

type Bal = { mint?: string; owner?: string; uiTokenAmount?: { uiAmount?: number | null } };

function deltas(pre: Bal[], post: Bal[], owner: string) {
  const map = new Map<string, { pre: number; post: number }>();
  for (const row of pre) {
    if (row.owner !== owner || !row.mint) continue;
    const slot = map.get(row.mint) ?? { pre: 0, post: 0 };
    slot.pre += num(row.uiTokenAmount?.uiAmount);
    map.set(row.mint, slot);
  }
  for (const row of post) {
    if (row.owner !== owner || !row.mint) continue;
    const slot = map.get(row.mint) ?? { pre: 0, post: 0 };
    slot.post += num(row.uiTokenAmount?.uiAmount);
    map.set(row.mint, slot);
  }
  return [...map.entries()]
    .map(([mint, slot]) => ({ mint, delta: slot.post - slot.pre }))
    .filter((row) => !STABLES.has(row.mint) && Math.abs(row.delta) > 0);
}

export const loadWalletActivity = createServerFn({ method: "POST" })
  .validator((input: { address?: string }) => {
    const address = String(input?.address ?? "").trim();
    if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address)) throw new Error("Bad wallet");
    return { address };
  })
  .handler(async ({ data }) => {
    const hit = cache.get(data.address);
    if (hit && Date.now() - hit.at < 20_000) return { ok: true as const, events: hit.events };
    let signatures: { signature: string; blockTime?: number; err?: unknown }[] = [];
    try {
      const result = await rpc("getSignaturesForAddress", [data.address, { limit: 6 }]);
      signatures = Array.isArray(result) ? (result as { signature: string; blockTime?: number; err?: unknown }[]) : [];
    } catch {
      return { ok: true as const, events: [] as WalletEvent[] };
    }
    const parsed = await Promise.all(
      signatures.slice(0, 4).map(async (row) => {
        if (row.err || !row.signature) return null;
        try {
          const tx = (await rpc("getTransaction", [
            row.signature,
            { encoding: "jsonParsed", maxSupportedTransactionVersion: 1 },
          ])) as { meta?: { preTokenBalances?: Bal[]; postTokenBalances?: Bal[] } } | null;
          const moves = deltas(tx?.meta?.preTokenBalances ?? [], tx?.meta?.postTokenBalances ?? [], data.address);
          const move = moves.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta))[0];
          if (!move) return null;
          return {
            id: row.signature,
            time: (row.blockTime ?? Math.floor(Date.now() / 1000)) * 1000,
            side: move.delta > 0 ? ("buy" as const) : ("sell" as const),
            address: move.mint,
            qty: Math.abs(move.delta),
          };
        } catch {
          return null;
        }
      }),
    );
    const mints = [...new Set(parsed.flatMap((row) => (row ? [row.address] : [])))].slice(0, 4);
    const meta = new Map<string, { symbol: string; name: string; price: number; liquidity: number; marketCap: number; pair: string }>();
    if (mints.length) {
      try {
        const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${mints.join(",")}`);
        if (res.ok) {
          const body = (await res.json()) as {
            pairs?: {
              pairAddress?: string;
              priceUsd?: string;
              liquidity?: { usd?: number };
              marketCap?: number;
              fdv?: number;
              baseToken?: { address?: string; symbol?: string; name?: string };
            }[];
          };
          for (const pair of body.pairs ?? []) {
            const address = pair.baseToken?.address;
            if (!address) continue;
            const row = {
              symbol: pair.baseToken?.symbol || address.slice(0, 4),
              name: pair.baseToken?.name || "Token",
              price: num(pair.priceUsd),
              liquidity: num(pair.liquidity?.usd),
              marketCap: num(pair.marketCap) || num(pair.fdv),
              pair: pair.pairAddress || "",
            };
            const prev = meta.get(address);
            if (!prev || row.liquidity > prev.liquidity) meta.set(address, row);
          }
        }
      } catch {
        /* prices stay empty */
      }
    }
    const events: WalletEvent[] = parsed.flatMap((row) => {
      if (!row) return [];
      const info = meta.get(row.address);
      const price = info?.price ?? 0;
      return [
        {
          id: row.id,
          time: row.time,
          side: row.side,
          symbol: info?.symbol || row.address.slice(0, 4),
          name: info?.name || "Token",
          address: row.address,
          chain: "solana" as const,
          pair: info?.pair || "",
          price,
          usd: price > 0 ? price * row.qty : 0,
          qty: row.qty,
          liquidity: info?.liquidity ?? 0,
          marketCap: info?.marketCap ?? 0,
        },
      ];
    });
    cache.set(data.address, { at: Date.now(), events });
    return { ok: true as const, events };
  });
