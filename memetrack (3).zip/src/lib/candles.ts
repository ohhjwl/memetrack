import { createServerFn } from "@tanstack/react-start";

export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export const CHART_FRAMES = [
  { id: "1m", label: "1m", timeframe: "minute", aggregate: 1 },
  { id: "5m", label: "5m", timeframe: "minute", aggregate: 5 },
  { id: "15m", label: "15m", timeframe: "minute", aggregate: 15 },
  { id: "1H", label: "1H", timeframe: "hour", aggregate: 1 },
  { id: "4H", label: "4H", timeframe: "hour", aggregate: 4 },
  { id: "1D", label: "1D", timeframe: "day", aggregate: 1 },
] as const;

export type FrameId = (typeof CHART_FRAMES)[number]["id"];

const NET: Record<string, string> = {
  solana: "solana",
  ethereum: "eth",
  bsc: "bsc",
  base: "base",
};

const FRAMES = new Set(CHART_FRAMES.map((frame) => frame.id));

const cache = new Map<string, { at: number; candles: Candle[] }>();

function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function parseList(raw: unknown): Candle[] {
  if (!Array.isArray(raw)) return [];
  const rows: Candle[] = [];
  for (const item of raw) {
    if (!Array.isArray(item) || item.length < 5) continue;
    const time = Math.floor(num(item[0]));
    const open = num(item[1]);
    const high = num(item[2]);
    const low = num(item[3]);
    const close = num(item[4]);
    const volume = num(item[5]);
    if (time <= 0 || close <= 0 || open <= 0) continue;
    rows.push({ time, open, high: Math.max(high, open, close), low: Math.min(low || open, open, close), close, volume });
  }
  rows.sort((a, b) => a.time - b.time);
  const unique: Candle[] = [];
  for (const row of rows) {
    if (unique.length && unique[unique.length - 1].time === row.time) unique[unique.length - 1] = row;
    else unique.push(row);
  }
  return unique;
}

async function getJson(url: string, attempt = 0): Promise<{
  data?: { attributes?: { ohlcv_list?: unknown; address?: string } } | { attributes?: { address?: string } }[];
}> {
  const res = await fetch(url, { headers: { accept: "application/json" } });
  if (res.status === 429 && attempt < 1) {
    await new Promise((resolve) => setTimeout(resolve, 900));
    return getJson(url, attempt + 1);
  }
  if (!res.ok) throw new Error(String(res.status));
  return (await res.json()) as {
    data?: { attributes?: { ohlcv_list?: unknown; address?: string } } | { attributes?: { address?: string } }[];
  };
}

async function ohlcv(network: string, pool: string, timeframe: string, aggregate: number) {
  const body = await getJson(
    `https://api.geckoterminal.com/api/v2/networks/${network}/pools/${encodeURIComponent(pool)}/ohlcv/${timeframe}?aggregate=${aggregate}&limit=240&currency=usd`,
  );
  const list = body.data && !Array.isArray(body.data) ? body.data.attributes?.ohlcv_list : undefined;
  return parseList(list);
}

async function poolByToken(network: string, address: string) {
  const body = await getJson(`https://api.geckoterminal.com/api/v2/networks/${network}/tokens/${encodeURIComponent(address)}/pools?page=1`);
  const list = Array.isArray(body.data) ? body.data : [];
  const first = list[0]?.attributes?.address;
  return typeof first === "string" ? first : "";
}

export const loadCandles = createServerFn({ method: "POST" })
  .validator((input: { chain?: string; pair?: string; address?: string; frame?: string }) => {
    const chain = String(input?.chain ?? "").toLowerCase();
    const pair = String(input?.pair ?? "").trim().slice(0, 80);
    const address = String(input?.address ?? "").trim().slice(0, 80);
    const frame = String(input?.frame ?? "5m");
    if (!NET[chain]) throw new Error("Unsupported chain");
    if (!FRAMES.has(frame as FrameId)) throw new Error("Bad frame");
    if (!pair && !address) throw new Error("Missing pool");
    return { chain, pair, address, frame: frame as FrameId };
  })
  .handler(async ({ data }) => {
    const spec = CHART_FRAMES.find((frame) => frame.id === data.frame) ?? CHART_FRAMES[1];
    const key = `${data.chain}:${data.pair || data.address}:${spec.id}`;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.at < 45_000) return { ok: true as const, candles: hit.candles, live: hit.candles.length > 0 };

    const network = NET[data.chain];
    let candles: Candle[] = [];
    if (data.pair) {
      try {
        candles = await ohlcv(network, data.pair, spec.timeframe, spec.aggregate);
      } catch {
        candles = [];
      }
    }
    if (!candles.length && data.address) {
      try {
        const looked = await poolByToken(network, data.address);
        if (looked && looked !== data.pair) candles = await ohlcv(network, looked, spec.timeframe, spec.aggregate);
      } catch {
        candles = [];
      }
    }
    if (candles.length) cache.set(key, { at: Date.now(), candles });
    return { ok: true as const, candles, live: candles.length > 0 };
  });

/** Rough candles from the live price so the chart still draws if the pool feed is empty. */
export function estimateCandles(price: number, changePct: number, count = 96): Candle[] {
  if (!(price > 0)) return [];
  const start = price / (1 + changePct / 100 || 1);
  const step = 5 * 60;
  const now = Math.floor(Date.now() / 1000 / step) * step;
  const rows: Candle[] = [];
  let prev = start > 0 ? start : price;
  for (let i = 0; i < count; i += 1) {
    const t = i / (count - 1);
    const drift = start + (price - start) * t;
    const wobble = 1 + Math.sin(i * 1.7) * 0.012 + Math.cos(i * 0.45) * 0.008;
    const close = Math.max(drift * wobble, price * 0.0001);
    const open = prev;
    const high = Math.max(open, close) * (1 + 0.004);
    const low = Math.min(open, close) * (1 - 0.004);
    rows.push({
      time: now - (count - 1 - i) * step,
      open,
      high,
      low,
      close,
      volume: Math.abs(close - open) * (800 + (i % 7) * 120),
    });
    prev = close;
  }
  if (rows.length) rows[rows.length - 1].close = price;
  return rows;
}
