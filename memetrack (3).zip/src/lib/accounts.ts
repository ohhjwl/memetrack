import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { FREE_LEARN_MS, effectivePlan, isPlanId, isTermId, learnOpen, type PlanId } from "@/lib/pricing";
import { tierAllows } from "@/lib/learn";

export type Me = {
  userId: string;
  name: string;
  email: string;
  handle: string;
  bio: string;
  role: "admin" | "member";
  banned: boolean;
  plan: PlanId;
  learnUsedMs: number;
  learnOpen: boolean;
  discordJoined: boolean;
};

export type AccountRow = {
  userId: string;
  name: string;
  email: string;
  handle: string;
  bio: string;
  role: string;
  banned: boolean;
  plan: PlanId;
  requestedPlan: string;
  requestedTerm: string;
  learnUsedMs: number;
  createdAt: string;
};

function stamp(value: unknown) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString();
  return String(value);
}

function slug(name: string, id: string) {
  const base = name.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 16) || "trader";
  return `${base}${id.slice(0, 4)}`;
}

function asPlan(plan: string | null, grant: boolean): PlanId {
  return effectivePlan(grant ? "unlimited" : (plan ?? "free"), false);
}

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Me> => {
    const sql = await getSql();
    const users = await sql<{ id: string; name: string; email: string }>`
      select id, name, email from "user" where id = ${context.userId} limit 1
    `;
    const user = users[0] ?? { id: context.userId, name: "Trader", email: "" };
    const admins = await sql<{ n: number }>`select count(*)::int as n from profiles where role = 'admin'`;
    const role = (admins[0]?.n ?? 0) === 0 ? "admin" : "member";
    await sql`
      insert into profiles (user_id, handle, role)
      values (${user.id}, ${slug(user.name, user.id)}, ${role})
      on conflict (user_id) do nothing
    `;
    const rows = await sql<{
      handle: string;
      bio: string;
      role: string;
      banned: boolean;
      learn_grant: boolean;
      plan: string;
      learn_used_ms: number;
      discord_joined: boolean;
    }>`
      select handle, bio, role, banned, learn_grant, plan, learn_used_ms, discord_joined from profiles where user_id = ${user.id}
    `;
    const row = rows[0];
    const used = Math.max(0, Number(row?.learn_used_ms) || 0);
    const plan = row?.role === "admin" ? "unlimited" : asPlan(row?.plan ?? "free", row?.learn_grant === true);
    return {
      userId: user.id,
      name: user.name,
      email: user.email,
      handle: row?.handle ?? "",
      bio: row?.bio ?? "",
      role: row?.role === "admin" ? "admin" : "member",
      banned: row?.banned === true,
      plan,
      learnUsedMs: used,
      learnOpen: learnOpen(plan, used),
      discordJoined: row?.discord_joined === true,
    };
  });

export const confirmDiscord = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`update profiles set discord_joined = true where user_id = ${context.userId}`;
    return { discordJoined: true as const };
  });

export const tickLearn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((ms: number) => Math.min(15000, Math.max(1000, Math.round(Number(ms) || 0))))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ plan: string; learn_grant: boolean; learn_used_ms: number; banned: boolean; role: string }>`
      select plan, learn_grant, learn_used_ms, banned, role from profiles where user_id = ${context.userId}
    `;
    const row = rows[0];
    if (!row || row.banned) return { learnUsedMs: FREE_LEARN_MS, learnOpen: false, plan: "free" as PlanId };
    const plan = row.role === "admin" ? "unlimited" : asPlan(row.plan, row.learn_grant);
    const used = Math.max(0, Number(row.learn_used_ms) || 0);
    if (plan !== "free") return { learnUsedMs: used, learnOpen: true, plan };
    const next = Math.min(FREE_LEARN_MS, used + data);
    await sql`update profiles set learn_used_ms = ${next} where user_id = ${context.userId}`;
    return { learnUsedMs: next, learnOpen: next < FREE_LEARN_MS, plan };
  });

export const requestPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { plan?: string; term?: string }) => ({
    plan: String(input?.plan ?? ""),
    term: String(input?.term ?? "month"),
  }))
  .handler(async ({ context, data }) => {
    if (!isPlanId(data.plan) || data.plan === "free" || !isTermId(data.term)) return { ok: false as const };
    const sql = await getSql();
    await sql`
      update profiles set requested_plan = ${data.plan}, requested_term = ${data.term}
      where user_id = ${context.userId} and banned = false
    `;
    return { ok: true as const };
  });


export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { handle?: string; bio?: string }) => ({
    handle: String(input?.handle ?? "").trim().slice(0, 24),
    bio: String(input?.bio ?? "").trim().slice(0, 280),
  }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      update profiles set handle = ${data.handle}, bio = ${data.bio}
      where user_id = ${context.userId} and banned = false
    `;
    return { ok: true as const };
  });

export const listAccounts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<AccountRow[]> => {
    const sql = await getSql();
    const me = await sql<{ role: string }>`select role from profiles where user_id = ${context.userId}`;
    if (me[0]?.role !== "admin") throw new Error("Forbidden");
    const rows = await sql<{
      id: string;
      name: string;
      email: string;
      handle: string | null;
      bio: string | null;
      role: string | null;
      banned: boolean | null;
      learn_grant: boolean | null;
      plan: string | null;
      learn_used_ms: number | null;
      requested_plan: string | null;
      requested_term: string | null;
      created_at: unknown;
    }>`
      select u.id, u.name, u.email, p.handle, p.bio, p.role, p.banned, p.learn_grant, p.plan, p.learn_used_ms,
        p.requested_plan, p.requested_term, u."createdAt" as created_at
      from "user" u
      left join profiles p on p.user_id = u.id
      order by u."createdAt" desc
      limit 200
    `;
    return rows.map((row) => ({
      userId: row.id,
      name: row.name,
      email: row.email,
      handle: row.handle ?? "",
      bio: row.bio ?? "",
      role: row.role ?? "member",
      banned: row.banned === true,
      plan: asPlan(row.plan, row.learn_grant === true),
      requestedPlan: row.requested_plan ?? "",
      requestedTerm: row.requested_term ?? "",
      learnUsedMs: Math.max(0, Number(row.learn_used_ms) || 0),
      createdAt: stamp(row.created_at) ?? "",
    }));
  });

export const moderateAccount = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId?: string; banned?: boolean; plan?: string; clearBio?: boolean }) => ({
    userId: String(input?.userId ?? ""),
    banned: typeof input?.banned === "boolean" ? input.banned : undefined,
    plan: typeof input?.plan === "string" ? input.plan : undefined,
    clearBio: input?.clearBio === true,
  }))
  .handler(async ({ context, data }) => {
    if (!data.userId || data.userId === context.userId) throw new Error("Cannot moderate yourself");
    const sql = await getSql();
    const me = await sql<{ role: string }>`select role from profiles where user_id = ${context.userId}`;
    if (me[0]?.role !== "admin") throw new Error("Forbidden");
    if (data.banned !== undefined) {
      await sql`update profiles set banned = ${data.banned} where user_id = ${data.userId} and role <> 'admin'`;
    }
    if (data.plan && isPlanId(data.plan)) {
      const grant = data.plan === "unlimited";
      await sql`
        update profiles
        set plan = ${data.plan}, learn_grant = ${grant}, requested_plan = '', requested_term = ''
        where user_id = ${data.userId}
      `;
    }
    if (data.clearBio) {
      await sql`update profiles set bio = '' where user_id = ${data.userId}`;
    }
    return { ok: true as const };
  });

export const readProgress = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ item_id: string; score: number }>`
      select item_id, score from learn_progress where user_id = ${context.userId}
    `;
    return rows;
  });

export const saveProgress = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { itemId?: string; score?: number }) => ({
    itemId: String(input?.itemId ?? "").slice(0, 80),
    score: Math.max(0, Math.min(100, Math.round(Number(input?.score) || 0))),
  }))
  .handler(async ({ context, data }) => {
    if (!data.itemId) return { ok: false as const };
    const sql = await getSql();
    const access = await sql<{ plan: string; learn_grant: boolean; learn_used_ms: number; banned: boolean; role: string }>`
      select plan, learn_grant, learn_used_ms, banned, role from profiles where user_id = ${context.userId}
    `;
    const row = access[0];
    const plan = row?.role === "admin" ? "unlimited" : asPlan(row?.plan ?? "free", row?.learn_grant === true);
    if (!row || row.banned || !learnOpen(plan, Number(row.learn_used_ms) || 0)) return { ok: false as const };
    if (!tierAllows(plan, data.itemId)) return { ok: false as const };
    if (data.itemId.startsWith("quiz:") && plan !== "unlimited" && plan !== "free") {
      const prior = await sql<{ score: number }>`
        select score from learn_progress where user_id = ${context.userId} and item_id = ${data.itemId}
      `;
      if ((prior[0]?.score ?? 0) >= 2) return { ok: false as const };
    }
    await sql`
      insert into learn_progress (user_id, item_id, score)
      values (${context.userId}, ${data.itemId}, ${data.score})
      on conflict (user_id, item_id) do update set score = excluded.score
    `;
    return { ok: true as const };
  });
