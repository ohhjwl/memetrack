export type Theme = {
  bg: string;
  panel: string;
  raise: string;
  chip: string;
  line: string;
  fg: string;
  muted: string;
  faint: string;
  up: string;
  down: string;
  hot: string;
};

export const DEFAULT_THEME: Theme = {
  bg: "#07070a",
  panel: "#101014",
  raise: "#17171d",
  chip: "#1c1c24",
  line: "#2a2a33",
  fg: "#f4f4f6",
  muted: "#9a9aa6",
  faint: "#6a6a74",
  up: "#3ddc84",
  down: "#ff4d6d",
  hot: "#ff5a36",
};

export const THEME_FIELDS: { key: keyof Theme; label: string }[] = [
  { key: "bg", label: "Background" },
  { key: "panel", label: "Panels" },
  { key: "raise", label: "Raised" },
  { key: "chip", label: "Chips" },
  { key: "line", label: "Borders" },
  { key: "fg", label: "Text" },
  { key: "muted", label: "Muted" },
  { key: "faint", label: "Faint" },
  { key: "up", label: "Up" },
  { key: "down", label: "Down" },
  { key: "hot", label: "Hot" },
];

export const THEME_PRESETS: { id: string; label: string; theme: Theme }[] = [
  { id: "dark", label: "Dark", theme: DEFAULT_THEME },
  {
    id: "light",
    label: "Light",
    theme: {
      bg: "#f3f3f6",
      panel: "#ffffff",
      raise: "#ececf1",
      chip: "#e1e1e8",
      line: "#d0d0d8",
      fg: "#141418",
      muted: "#555560",
      faint: "#6e6e7a",
      up: "#0c8a46",
      down: "#d01842",
      hot: "#e24a1b",
    },
  },
  {
    id: "purple",
    label: "Purple",
    theme: {
      bg: "#120c18",
      panel: "#1c1228",
      raise: "#261833",
      chip: "#321e44",
      line: "#4a3264",
      fg: "#f6f0ff",
      muted: "#b9a8cc",
      faint: "#8d7a9e",
      up: "#3ddc84",
      down: "#ff4d6d",
      hot: "#c084fc",
    },
  },
  {
    id: "blue",
    label: "Blue",
    theme: {
      bg: "#071018",
      panel: "#0e1c2a",
      raise: "#132536",
      chip: "#1a3148",
      line: "#2a4a66",
      fg: "#eef6ff",
      muted: "#9eb4c8",
      faint: "#6e879c",
      up: "#3ddc97",
      down: "#ff5d73",
      hot: "#38bdf8",
    },
  },
  {
    id: "amber",
    label: "Amber",
    theme: {
      bg: "#14110c",
      panel: "#221c12",
      raise: "#2c2416",
      chip: "#3a2e1c",
      line: "#5a4630",
      fg: "#fff6e8",
      muted: "#cbb89a",
      faint: "#8f7d64",
      up: "#7dce4a",
      down: "#ff5a4a",
      hot: "#f5b942",
    },
  },
  {
    id: "mint",
    label: "Mint",
    theme: {
      bg: "#071410",
      panel: "#0e1c16",
      raise: "#13261d",
      chip: "#1a3328",
      line: "#2a5240",
      fg: "#eefaf3",
      muted: "#9ec4b0",
      faint: "#6e9482",
      up: "#3ddc84",
      down: "#ff5d73",
      hot: "#2ee6a6",
    },
  },
  {
    id: "grey",
    label: "Grey",
    theme: {
      bg: "#2a2d33",
      panel: "#34383f",
      raise: "#3e434c",
      chip: "#4a505a",
      line: "#5c6370",
      fg: "#f4f5f7",
      muted: "#c5c8ce",
      faint: "#9aa0aa",
      up: "#3ddc84",
      down: "#ff5d73",
      hot: "#f0b429",
    },
  },
  {
    id: "slate",
    label: "Slate",
    theme: {
      bg: "#1b1e27",
      panel: "#232733",
      raise: "#2a3040",
      chip: "#343b4d",
      line: "#3e465c",
      fg: "#eef1f6",
      muted: "#b7c0d0",
      faint: "#8b95a8",
      up: "#26c281",
      down: "#f0546a",
      hot: "#7aa2ff",
    },
  },
  {
    id: "fog",
    label: "Fog",
    theme: {
      bg: "#e6e8ee",
      panel: "#f5f6f8",
      raise: "#ffffff",
      chip: "#d8dbe3",
      line: "#c5cad4",
      fg: "#1c1e24",
      muted: "#4e5563",
      faint: "#6a7180",
      up: "#0c8a46",
      down: "#d01842",
      hot: "#c2410c",
    },
  },
  {
    id: "cream",
    label: "Cream",
    theme: {
      bg: "#f6f0e4",
      panel: "#fffaf2",
      raise: "#fffdf8",
      chip: "#efe4d2",
      line: "#e0d2ba",
      fg: "#2a241c",
      muted: "#5c5144",
      faint: "#7a6d5c",
      up: "#0f7a3a",
      down: "#c81e3a",
      hot: "#c2410c",
    },
  },
  {
    id: "sky",
    label: "Sky",
    theme: {
      bg: "#e4f0fb",
      panel: "#f7fbff",
      raise: "#ffffff",
      chip: "#d3e6f7",
      line: "#c0d7ee",
      fg: "#122033",
      muted: "#3d536b",
      faint: "#5c738c",
      up: "#0c8a46",
      down: "#d01842",
      hot: "#0369a1",
    },
  },
  {
    id: "blush",
    label: "Blush",
    theme: {
      bg: "#fbecef",
      panel: "#fff7f8",
      raise: "#ffffff",
      chip: "#f6d8df",
      line: "#ecc4ce",
      fg: "#2c1820",
      muted: "#6a4450",
      faint: "#8a6270",
      up: "#0c8a46",
      down: "#c81e3a",
      hot: "#be185d",
    },
  },
  {
    id: "sage",
    label: "Sage",
    theme: {
      bg: "#e6f2ea",
      panel: "#f6fbf7",
      raise: "#ffffff",
      chip: "#d3e8da",
      line: "#bdd6c6",
      fg: "#14241b",
      muted: "#3d5c4a",
      faint: "#5d7a68",
      up: "#0f7a3a",
      down: "#c81e3a",
      hot: "#047857",
    },
  },
];

export function applyTheme(theme: Theme) {
  const root = document.documentElement;
  (Object.keys(theme) as (keyof Theme)[]).forEach((key) => {
    root.style.setProperty(`--color-${key}`, theme[key]);
  });
}
