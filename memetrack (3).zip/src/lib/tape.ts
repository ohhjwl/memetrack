import { createServerFn } from "@tanstack/react-start";

export type Snap = {
  address: string;
  chain: string;
  pair: string;
  symbol: string;
  name: string;
  price: number;
  liquidity: number;
  marketCap: number;
  m5buys: number;
  m5sells: number;
  m5vol: number;
};

export type Print = {
  id: string;
  time: number;
  side: "buy" | "sell" | "new";
  symbol: string;
  name: string;
  address: string;
  chain: string;
  pair: string;
  price: number;
  usd: number;
  liquidity: number;
  marketCap: number;
  wallet?: string;
};

const cache = new Map<string, { at: number; rows: Snap[] }>();

function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

export const loadSnaps = createServerFn({ method: "POST" })
  .validator((input: { addresses?: string[] }) => {
    const addresses = [...new Set((input?.addresses ?? []).map((item) => String(item).trim()))]
      .filter((item) => item.length >= 20 && item.length <= 80)
      .slice(0, 8);
    if (!addresses.length) throw new Error("No tokens");
    return { addresses };
  })
  .handler(async ({ data }) => {
    const key = data.addresses.slice().sort().join(",");
    const hit = cache.get(key);
    if (hit && Date.now() - hit.at < 8_000) return { ok: true as const, rows: hit.rows };
    const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${data.addresses.join(",")}`);
    if (!res.ok) return { ok: true as const, rows: [] as Snap[] };
    const body = (await res.json()) as {
      pairs?: {
        chainId?: string;
        pairAddress?: string;
        priceUsd?: string;
        liquidity?: { usd?: number };
        marketCap?: number;
        fdv?: number;
        volume?: { m5?: number };
        txns?: { m5?: { buys?: number; sells?: number } };
        baseToken?: { address?: string; symbol?: string; name?: string };
      }[];
    };
    const best = new Map<string, Snap>();
    for (const pair of body.pairs ?? []) {
      const address = pair.baseToken?.address;
      if (!address || !data.addresses.includes(address)) continue;
      const row: Snap = {
        address,
        chain: pair.chainId || "solana",
        pair: pair.pairAddress || "",
        symbol: pair.baseToken?.symbol || "?",
        name: pair.baseToken?.name || pair.baseToken?.symbol || "Unknown",
        price: num(pair.priceUsd),
        liquidity: num(pair.liquidity?.usd),
        marketCap: num(pair.marketCap) || num(pair.fdv),
        m5buys: pair.txns?.m5?.buys ?? 0,
        m5sells: pair.txns?.m5?.sells ?? 0,
        m5vol: num(pair.volume?.m5),
      };
      const prev = best.get(address);
      if (!prev || row.liquidity > prev.liquidity) best.set(address, row);
    }
    const rows = [...best.values()];
    cache.set(key, { at: Date.now(), rows });
    return { ok: true as const, rows };
  });
