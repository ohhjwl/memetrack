const SOL = "So11111111111111111111111111111111111111112";

type WalletProvider = {
  connect: () => Promise<{ publicKey: { toString: () => string } }>;
  signTransaction: (tx: unknown) => Promise<{ serialize: () => Uint8Array }>;
  signAndSendTransaction?: (tx: unknown) => Promise<{ signature: string }>;
};

function wallet(): WalletProvider | null {
  if (typeof window === "undefined") return null;
  const injected = (window as unknown as { solana?: WalletProvider }).solana;
  if (!injected?.connect || !injected.signTransaction) return null;
  return injected;
}

export async function jupiterBuy(mint: string, usd: number, solPrice: number): Promise<{ ok: true; signature: string } | { ok: false; reason: string }> {
  const injected = wallet();
  if (!injected) return { ok: false, reason: "no-wallet" };
  if (!(solPrice > 0)) return { ok: false, reason: "No SOL price yet. Use the venue button." };
  const lamports = Math.floor((usd / solPrice) * 1e9);
  if (lamports < 10_000) return { ok: false, reason: "That size is too small in SOL." };
  let pubkey = "";
  try {
    const connected = await injected.connect();
    pubkey = connected.publicKey.toString();
  } catch {
    return { ok: false, reason: "Wallet connection was cancelled." };
  }
  try {
    const quoteRes = await fetch(
      `https://lite-api.jup.ag/swap/v1/quote?inputMint=${SOL}&outputMint=${encodeURIComponent(mint)}&amount=${lamports}&slippageBps=150`,
    );
    if (!quoteRes.ok) return { ok: false, reason: "Jupiter quote failed. Use the venue button." };
    const quote = (await quoteRes.json()) as { outAmount?: string };
    if (!quote.outAmount) return { ok: false, reason: "Jupiter has no route for this coin." };
    const swapRes = await fetch("https://lite-api.jup.ag/swap/v1/swap", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ quoteResponse: quote, userPublicKey: pubkey, dynamicComputeUnitLimit: true }),
    });
    if (!swapRes.ok) return { ok: false, reason: "Jupiter could not build the swap. Use the venue button." };
    const swap = (await swapRes.json()) as { swapTransaction?: string };
    if (!swap.swapTransaction) return { ok: false, reason: "Jupiter returned no transaction." };
    const { VersionedTransaction } = await import("@solana/web3.js");
    const raw = Uint8Array.from(atob(swap.swapTransaction), (char) => char.charCodeAt(0));
    const tx = VersionedTransaction.deserialize(raw);
    if (injected.signAndSendTransaction) {
      const sent = await injected.signAndSendTransaction(tx);
      return { ok: true, signature: sent.signature };
    }
    const signed = await injected.signTransaction(tx);
    const { Connection } = await import("@solana/web3.js");
    const connection = new Connection("https://api.mainnet-beta.solana.com", "confirmed");
    const signature = await connection.sendRawTransaction(signed.serialize(), { skipPreflight: false });
    return { ok: true, signature };
  } catch {
    return { ok: false, reason: "The swap was cancelled or the wallet could not send it." };
  }
}
