export const STARTER_MODULES = 3;

export function moduleIndex(id: string) {
  return MODULES.findIndex((item) => item.id === id);
}

export type QuizQ = { prompt: string; choices: string[]; answer: number };
export type Card = { id: string; front: string; back: string };
export type Module = {
  id: string;
  title: string;
  minutes: number;
  lead: string;
  sections: { heading: string; body: string }[];
  quiz: QuizQ[];
  cards: Card[];
  paper?: string;
};

export const MODULES: Module[] = [
  {
    id: "expectancy",
    title: "Expectancy, not a hot take",
    minutes: 18,
    lead: "A professional sizes a process that has a positive expectancy. A call is just someone else's position.",
    sections: [
      {
        heading: "R is the unit",
        body: "Risk one R per idea: the dollars you lose if your invalidation hits. A winner of twice that is +2R. A full stop is -1R. Talking in R stops a $40 coin and a $4 coin from feeling like different sports. They are the same sport at different size.",
      },
      {
        heading: "Expectancy",
        body: "Expectancy is win rate times average win, minus loss rate times average loss, all in R. A 40% win rate is a business if winners average +2.5R and losers are cut at -1R. A 70% win rate is a leak if the losses are -4R because you refuse to sell. You do not need to be right often. You need the average to be positive after fees.",
      },
      {
        heading: "Sample size",
        body: "Ten trades prove nothing. A run of four losers is normal inside a 45% system. The review window is the last twenty to thirty closed trades, not this morning. If you change the rules after one red candle, you do not have a system. You have a mood.",
      },
      {
        heading: "What you actually write down",
        body: "Before the buy: thesis in one sentence, invalidation, size in R, and the first scale-out. After the close: did you follow that, and what was the result in R. Profit screenshots without R and without the losers are advertising.",
      },
    ],
    quiz: [
      {
        prompt: "A system wins 40% of the time, winners average +2.5R, losers are -1R. What is the rough expectancy per trade?",
        choices: ["Negative, because you lose more often than you win", "About +0.4R before fees", "About +2.5R", "Impossible to say without the coin's name"],
        answer: 1,
      },
      {
        prompt: "Why price the risk in R instead of dollars?",
        choices: ["R hides losses from you", "It makes a small coin and a large coin comparable", "Exchanges require it", "It raises the win rate"],
        answer: 1,
      },
      {
        prompt: "When is a four-loss streak evidence the system is broken?",
        choices: ["Always", "Never", "Only after a real sample, not after one session", "When the chart is red"],
        answer: 2,
      },
    ],
    cards: [
      { id: "ex-r", front: "What is 1R?", back: "The amount you lose if the invalidation is hit. Every result is measured against it." },
      { id: "ex-e", front: "Expectancy formula in words", back: "Win rate × average win minus loss rate × average loss, in R, after fees." },
      { id: "ex-sample", front: "How big a sample before you judge a rule?", back: "Tens of closed trades. A single session is noise." },
    ],
  },
  {
    id: "liquidity",
    title: "Liquidity is the market",
    minutes: 20,
    lead: "Market cap is a sticker price. Liquidity is whether the sticker can be sold.",
    sections: [
      {
        heading: "Pool versus cap",
        body: "A memecoin's tradable market is the pool, not the fully diluted number. A two million dollar cap sitting on eight thousand dollars of liquidity cannot pay out the people who think they own a two million dollar asset. Your exit has to be a small fraction of that pool or you are the exit liquidity.",
      },
      {
        heading: "Slippage is a cost, not a surprise",
        body: "The chart prints the last price. Your fill is worse by the impact of your size plus the fee. A tight stop on a thin pool often fills through the stop. If the honest slippage turns a -1R plan into -2R, the size is wrong, not the stop.",
      },
      {
        heading: "One-sided tape",
        body: "A launch that only prints buys is not demand. It is a market that has not been allowed to trade both ways. Wait until you can see sells that do not instantly gap the coin to zero, and buys that are not a single wallet painting the candle. Volume with no pool depth is noise.",
      },
      {
        heading: "The professional filter",
        body: "Before any setup: liquidity large enough for your size, both sides printing, age long enough that a red candle has already happened, and no mint or freeze authority you are unwilling to underwrite. Fail one and the setup is skipped. Skipping is a completed decision.",
      },
    ],
    quiz: [
      {
        prompt: "Which number tells you if you can get out?",
        choices: ["Market cap", "Holder count on a badge", "Pool liquidity relative to your size", "How many green candles printed"],
        answer: 2,
      },
      {
        prompt: "A stop on a thin pool most often fails because",
        choices: ["Stops are banned on memecoins", "The fill slips through the level", "Candles cannot be red", "Liquidity rises when you sell"],
        answer: 1,
      },
      {
        prompt: "A chart with only buys in the first minutes means",
        choices: ["Guaranteed continuation", "The market has not shown a real two-sided auction yet", "The dev is locked", "You should market-buy"],
        answer: 1,
      },
    ],
    cards: [
      { id: "lq-pool", front: "Cap versus liquidity", back: "Cap is the sticker. Liquidity is the cash that can take the other side of your sell." },
      { id: "lq-slip", front: "When is a stop dishonest?", back: "When expected slippage makes the real loss much larger than the 1R you wrote down." },
      { id: "lq-skip", front: "Name one automatic skip", back: "Pool too small for your size, one-sided tape, or mint/freeze you will not underwrite." },
    ],
    paper: "Pick a live coin. Write cap, liquidity, and the largest size you could sell without being the whole candle. Paper-buy only that size, or skip and log the skip.",
  },
  {
    id: "auction",
    title: "Candles are an auction",
    minutes: 18,
    lead: "You do not need a stack of indicators. You need to see where buyers failed.",
    sections: [
      {
        heading: "Body and wick",
        body: "The body is where the auction settled. The wick is the price that was rejected. A long upper wick after a vertical move is not 'bullish volatility'. It is sellers overwhelming the bid at that high. A long lower wick at a level you already marked is the only dip that has information.",
      },
      {
        heading: "Do not buy the impulse",
        body: "The expansion candle is where early inventory is distributed. Professionals wait for the first pause: a pullback that holds above the origin of the move, on less urgency than the spike. If the pullback gives the entire move back, there was no acceptance. There was a print.",
      },
      {
        heading: "Timeframe matches the job",
        body: "The higher timeframe decides whether you are allowed to be involved. The lower timeframe only times the entry. A pretty 1 minute flag inside a coin that has already round-tripped its range on the 15 minute is a trap, not a setup.",
      },
      {
        heading: "Levels before patterns",
        body: "Mark the high of the impulse, the origin of the impulse, and the last higher low. Those three prices are the plan. Patterns without prices are stories. If price is already through your 'do not chase' line, you are late and the correct order is nothing.",
      },
    ],
    quiz: [
      {
        prompt: "A long upper wick means",
        choices: ["Buy immediately", "Price was offered and rejected", "Liquidity increased", "The trend is confirmed"],
        answer: 1,
      },
      {
        prompt: "The higher timeframe is for",
        choices: ["Timing the exact click", "Deciding if you should be in the coin at all", "Ignoring liquidity", "Replacing a stop"],
        answer: 1,
      },
      {
        prompt: "The right order when price is already past your chase line",
        choices: ["Market buy and hope", "No trade", "Double size", "Move the line up"],
        answer: 1,
      },
    ],
    cards: [
      { id: "au-wick", front: "What does the wick show?", back: "Prices that traded and were rejected before the candle settled." },
      { id: "au-impulse", front: "Why not buy the vertical candle?", back: "That is where early inventory is sold to late buyers. Wait for a pause that holds." },
      { id: "au-levels", front: "Three prices to mark", back: "Impulse high, impulse origin, and the last higher low." },
    ],
  },
  {
    id: "playbooks",
    title: "Two playbooks, used boringly",
    minutes: 22,
    lead: "A playbook is a repeatable auction, not a signal. You only need two until they are dull.",
    sections: [
      {
        heading: "Playbook A: first pullback",
        body: "Conditions: both sides of the tape are alive, liquidity fits your size, and an impulse has printed and paused. Entry is the hold of the first higher low, not the high. Invalidation is a close back through the origin of the impulse. First scale is a partial at about +1R so the rest is less emotional. If the pullback is a straight line back to the open, the playbook is off. That is a failed impulse, which is a different trade.",
      },
      {
        heading: "Playbook B: failed break",
        body: "Conditions: price pushes a prior high and is immediately rejected back inside the range, with the wick doing the work. Entry is the failure, after the candle closes back inside, not while it is still making the high. Invalidation is a fresh close beyond that high. This is a fade. Size it smaller than the trend playbook. You are trading the people who chased.",
      },
      {
        heading: "One playbook per coin",
        body: "If you can narrate both A and B on the same coin at the same time, you do not have a read. You have two excuses. Pick the one the last completed candle supports. Write it down. The other is not a backup. It is a new trade that needs its own pass through the filter.",
      },
      {
        heading: "Time stop",
        body: "If the idea has not worked within the window you named (a few candles on the timeframe you used), you are wrong on timing even if you are not wrong on direction. Flat is a valid exit. Holding because 'it might still' turns a time stop into a hope position.",
      },
    ],
    quiz: [
      {
        prompt: "Playbook A is invalidated when",
        choices: ["The first candle is green", "Price closes back through the impulse origin", "Someone posts the coin", "You are in profit"],
        answer: 1,
      },
      {
        prompt: "A failed break entry happens",
        choices: ["While price is still making the high", "After a close back inside the range", "Only on the daily chart", "Before any high exists"],
        answer: 1,
      },
      {
        prompt: "A time stop means",
        choices: ["You never use a price stop", "If the idea does not work in the window you set, you exit", "You add size", "You switch playbooks mid-trade"],
        answer: 1,
      },
    ],
    cards: [
      { id: "pb-a", front: "First pullback entry", back: "After an impulse, buy the hold of the higher low. Not the high. Stop through the origin." },
      { id: "pb-b", front: "Failed break entry", back: "A push through a high that closes back inside. Enter the failure. Stop beyond the high. Size smaller." },
      { id: "pb-time", front: "Time stop", back: "Exit if the idea has not worked inside the candle window you wrote down before entry." },
    ],
    paper: "On paper, take either the first pullback or the failed break, never both. Write the playbook name, invalidation, and a time stop before you click.",
  },
  {
    id: "risk",
    title: "Size, ruin, and the stop you will keep",
    minutes: 18,
    lead: "Memecoins go to zero often enough that survival is the whole edge.",
    sections: [
      {
        heading: "Fixed fractional risk",
        body: "Risk a small fixed fraction of equity per idea, small enough that ten losses in a row are painful and not fatal. If you cannot name that fraction before you see the coin, you will size from excitement. Position size is the distance to invalidation divided into that dollar risk. Wider stop means fewer coins, not a bigger loss.",
      },
      {
        heading: "No averaging down as a strategy",
        body: "Adding to a loser only makes sense if the original evidence got stronger and the invalidation has not hit. 'Cheaper' is not evidence. On a coin that can mint more supply, averaging down is how a -1R becomes an account event.",
      },
      {
        heading: "Partials",
        body: "Sell a piece at the first planned target so the remainder is paid for by the house. The remainder still has the same invalidation. Moving the stop further away to 'give it room' after you are in is not room. It is a new, larger R you did not agree to.",
      },
      {
        heading: "Correlation",
        body: "Three coins on the same narrative are one trade. If they all die when the same wallet sells or the same headline fades, you are triple risked. Cap the narrative, not just the ticker.",
      },
    ],
    quiz: [
      {
        prompt: "A wider invalidation should make you",
        choices: ["Buy more coins so the profit is bigger", "Buy fewer coins so the dollar risk stays fixed", "Skip the stop", "Use market orders only"],
        answer: 1,
      },
      {
        prompt: "Averaging down is allowed when",
        choices: ["The price is lower", "The original evidence improved and invalidation has not hit", "You are bored", "The coin is new"],
        answer: 1,
      },
      {
        prompt: "Three coins in one narrative count as",
        choices: ["Diversification", "One correlated risk", "Three separate R budgets automatically", "A hedge"],
        answer: 1,
      },
    ],
    cards: [
      { id: "rk-frac", front: "Fixed fractional sizing", back: "Dollar risk stays constant. Coin count falls when the stop is further away." },
      { id: "rk-add", front: "When is adding allowed?", back: "Only if the thesis got stronger and the invalidation is still intact." },
      { id: "rk-corr", front: "Narrative cap", back: "Coins that die together are one position. Count the theme, not the tickers." },
    ],
    paper: "Name your fraction of equity before you look at a coin. Paper-size one idea so a stop is exactly 1R, then write what you would refuse to average.",
  },
  {
    id: "supply",
    title: "Supply, holders, and the review",
    minutes: 20,
    lead: "Price is the last thing that changes. Who can sell, and whether you followed the plan, change first.",
    sections: [
      {
        heading: "Authorities",
        body: "Mint authority means new supply can appear after you buy. Freeze authority means a wallet can be stopped from moving. Neither is automatically a scam, and neither is a detail. If you cannot explain who holds the authority and why you still want the risk, you do not take the trade. A badge that says safe is not a substitute for reading the holder list.",
      },
      {
        heading: "Concentration",
        body: "If a few wallets can dump more than the pool can absorb, your stop is theoretical. Clusters that buy in the same seconds and never sell are often one person wearing several addresses. Holder count goes up. Real distribution does not.",
      },
      {
        heading: "The dev is a position",
        body: "A quiet dev wallet is not bullish. Watch whether supply moves to fresh wallets that sell into the next green candle. 'Dev sold some' is only useful next to how much is left and whether the pool can eat it.",
      },
      {
        heading: "The review hour",
        body: "End the session with four lines: filter passed or skipped, playbook used, R result, rule followed yes or no. The grade is the rule, not the dollars. Once a week, total the R and the rule-breaks. If the breaks are where the losses live, you do not need a new indicator. You need to stop breaking the rule. This is not a promise of profit. It is how you stop paying tuition twice.",
      },
    ],
    quiz: [
      {
        prompt: "Mint authority still on means",
        choices: ["The coin cannot fall", "More supply can be created", "Liquidity is locked", "You must buy"],
        answer: 1,
      },
      {
        prompt: "A concentrated top holder matters because",
        choices: ["They post good memes", "Their sell can be larger than the pool", "It raises the win rate", "It removes slippage"],
        answer: 1,
      },
      {
        prompt: "The weekly review grades",
        choices: ["How you felt", "Whether the rule was followed and what the R total was", "The loudest coin", "Follower count"],
        answer: 1,
      },
    ],
    cards: [
      { id: "su-mint", front: "Mint and freeze", back: "Mint can create supply. Freeze can block a wallet. Read them before you size." },
      { id: "su-top", front: "Why top-holder percent matters", back: "If one wallet can sell more than the pool absorbs, your stop will not fill where you drew it." },
      { id: "su-review", front: "Four-line review", back: "Filter, playbook, R result, rule followed. Grade the rule." },
    ],
    paper: "Run one paper trade only if mint, freeze, and top holder are written down first. Then log the four review lines, even if the result is a skip.",
  },
  {
    id: "session",
    title: "The hour you actually trade",
    minutes: 16,
    lead: "A session has a start, a quota, and a stop. Open-ended screen time is how rules get rewritten mid-candle.",
    sections: [
      {
        heading: "Before the first click",
        body: "Write the day's risk budget in R before the board is interesting. Two or three ideas is a full session for a new trader. The budget is spent when it is spent, including skips that you almost took and then chased. If you raise the budget because the board looks hot, you did not have a budget.",
      },
      {
        heading: "A scan is a filter, not a tour",
        body: "Pass every coin through the same four questions: is the pool large enough for your size, has a red candle already printed, is mint or freeze something you will underwrite, and is there one playbook and only one. A coin that fails is removed. You do not 'watch it anyway'. Watching is how a skip becomes a market buy.",
      },
      {
        heading: "One open idea",
        body: "Until the playbooks are dull, one open paper position is the rule. A second coin is a second decision with its own invalidation, not a hedge you invent after the first one goes red. If you cannot watch the first plan, you cannot watch two.",
      },
      {
        heading: "The hard close",
        body: "The session ends when the quota is filled, the clock you set is up, or you break a rule. Breaking a rule ends the day even if you are green. The point of the hour is reps of the process. Extra time after a rule break is where the tuition is paid.",
      },
    ],
    quiz: [
      {
        prompt: "When is the day's risk budget written?",
        choices: ["After the first winner, so you know the mood", "Before the board gets interesting", "Only if you lose", "When a friend sends a coin"],
        answer: 1,
      },
      {
        prompt: "A coin that fails the scan should be",
        choices: ["Left on a side monitor", "Removed. Watching is not a softer entry", "Bought smaller", "Averaged if it dips"],
        answer: 1,
      },
      {
        prompt: "A rule break during the session means",
        choices: ["You size up to get it back", "The session is over, even if you are green", "You switch playbooks", "You hide the trade from the review"],
        answer: 1,
      },
    ],
    cards: [
      { id: "se-budget", front: "When do you set the R budget?", back: "Before the first coin looks exciting. Raising it because the board is hot means you had no budget." },
      { id: "se-scan", front: "What is a scan?", back: "The same four questions on every coin. A fail is a removal, not a coin you keep watching." },
      { id: "se-close", front: "What ends the session?", back: "The quota, the clock, or a rule break. Green does not extend a broken rule." },
    ],
    paper: "Set a session of one paper idea and a hard stop of three candles after entry. If you break the written invalidation, close the idea and stop for the day.",
  },
  {
    id: "execution",
    title: "Fills, fees, and the journal",
    minutes: 18,
    lead: "The plan is not the fill. Fees, slippage, and the sentence you write afterward are part of the trade.",
    sections: [
      {
        heading: "Limit versus chase",
        body: "A market buy into a thin candle is a different trade from the one you drew. If the playbook entry is a hold of a higher low, the order belongs near that price, not wherever the last print is. If you cannot get filled without moving your invalidation, the idea is gone. Missing it is a completed trade with a result of zero R.",
      },
      {
        heading: "Fees are in the expectancy",
        body: "A round trip that looks like +0.4R before costs can be flat after the pool fee, priority, and slippage. Professionals subtract the round trip before they call a target '1R'. If the distance to the first scale-out is smaller than two times the expected cost, the target is not a target. It is noise.",
      },
      {
        heading: "Partials are planned, not felt",
        body: "The first sale is written before entry: a fraction of the position at a named price, usually around +1R. You do not invent a new target because the candle is still green. The remainder keeps the original invalidation. Cancelling the partial because 'it might be the one' is a rule break, and the session rule applies.",
      },
      {
        heading: "The sentence",
        body: "After every close, one sentence: playbook, whether the fill matched the plan, R result, rule followed yes or no. If you cannot write it, you did not have a trade. You had a click. The weekly total of those sentences is the only scoreboard that tells you if the course is working. Dollars without the sentence are a story.",
      },
    ],
    quiz: [
      {
        prompt: "You cannot get filled without moving the invalidation. The correct result is",
        choices: ["Market buy and widen the stop", "No trade, scored as zero R", "Half size with no stop", "A second playbook on the same coin"],
        answer: 1,
      },
      {
        prompt: "A +1R target that is smaller than the round-trip cost is",
        choices: ["Still a win if the candle is green", "Not a real target", "Fixed by adding size", "Fine on memecoins"],
        answer: 1,
      },
      {
        prompt: "The journal sentence exists to record",
        choices: ["How confident you felt", "Playbook, fill versus plan, R, and whether the rule was followed", "Only the winners", "The coin's market cap"],
        answer: 1,
      },
    ],
    cards: [
      { id: "ex-miss", front: "A missed fill is", back: "A finished decision at zero R, if taking it would have moved the invalidation." },
      { id: "ex-fee", front: "Where do fees sit?", back: "Inside expectancy. A target closer than the round trip is noise, not +1R." },
      { id: "ex-sent", front: "The after-trade sentence", back: "Playbook, fill versus plan, R result, rule followed. No sentence means it was a click." },
    ],
    paper: "Place one paper buy only at the price you wrote. If the live price has already left it, log a missed fill at 0R instead of chasing. Then write the one-sentence review.",
  },
];

export function quizId(moduleId: string) {
  return `quiz:${moduleId}`;
}

export function tierAllows(plan: "free" | "starter" | "desk" | "unlimited", itemId: string) {
  const quiz = itemId.startsWith("quiz:");
  const card = itemId.startsWith("card:");
  const review = itemId.startsWith("review:");
  if (!quiz && !card && !review) return false;
  if (plan === "free" || plan === "unlimited") return true;
  if (review) return false;
  if (plan === "starter") {
    if (!quiz) return false;
    const rank = moduleIndex(itemId.slice(5));
    return rank >= 0 && rank < STARTER_MODULES;
  }
  if (card) return MODULES.some((mod) => mod.cards.some((item) => item.id === itemId.slice(5)));
  return moduleIndex(itemId.slice(5)) >= 0;
}
