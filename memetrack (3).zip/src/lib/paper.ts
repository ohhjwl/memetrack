import type { RugReport, Token } from "@/lib/market";

export const START_CASH = 10_000;

export type Fill = {
  id: string;
  time: number;
  side: "buy" | "sell";
  tokenId: string;
  symbol: string;
  name: string;
  address: string;
  chain: string;
  price: number;
  usd: number;
  qty: number;
  pnl: number;
  source: "quick" | "copy" | "wallet" | "tp" | "sl";
};

export type Lot = {
  tokenId: string;
  symbol: string;
  name: string;
  address: string;
  chain: string;
  qty: number;
  cost: number;
  tpPct: number | null;
  slPct: number | null;
};

export type CopyFilter = {
  minMcap: number;
  maxAgeH: number;
  minLiq: number;
  size: number;
  blacklist: string;
};

export type WalletWatch = {
  address: string;
  label: string;
  copy: boolean;
  filter: CopyFilter;
};

export type EquityPoint = { t: number; v: number };

export type PriceAlert = {
  id: string;
  tokenId: string;
  symbol: string;
  target: number;
  above: boolean;
  fired: boolean;
};

export type Book = {
  cash: number;
  lots: Lot[];
  fills: Fill[];
  wallets: WalletWatch[];
  copySize: number;
  seen: string[];
  equity: EquityPoint[];
  alerts: PriceAlert[];
  alerted: string[];
  sound: boolean;
};

export type Safety = { level: "ok" | "warn" | "block"; reasons: string[] };

export type CopiedBuy = {
  id: string;
  symbol: string;
  name: string;
  address: string;
  chain: string;
  price: number;
  liquidity: number;
  marketCap: number;
  created?: number;
  wallet?: string;
  size?: number;
};

export function emptyFilter(): CopyFilter {
  return { minMcap: 0, maxAgeH: 0, minLiq: 0, size: 0, blacklist: "" };
}

export function emptyBook(): Book {
  return {
    cash: START_CASH,
    lots: [],
    fills: [],
    wallets: [],
    copySize: 100,
    seen: [],
    equity: [],
    alerts: [],
    alerted: [],
    sound: false,
  };
}

function num(value: unknown, fallback = 0) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function optionalPct(value: unknown) {
  const n = num(value, 0);
  if (!(n > 0)) return null;
  return Math.min(500, n);
}

function normalizeFilter(value: unknown): CopyFilter {
  const row = (value && typeof value === "object" ? value : {}) as Partial<CopyFilter>;
  return {
    minMcap: Math.max(0, num(row.minMcap)),
    maxAgeH: Math.max(0, num(row.maxAgeH)),
    minLiq: Math.max(0, num(row.minLiq)),
    size: Math.max(0, num(row.size)),
    blacklist: typeof row.blacklist === "string" ? row.blacklist.slice(0, 180) : "",
  };
}

export function readBook(raw: string | null): Book {
  try {
    const parsed = JSON.parse(raw || "null") as Partial<Book> | null;
    if (!parsed || typeof parsed !== "object") return emptyBook();
    return {
      cash: num(parsed.cash, START_CASH),
      lots: Array.isArray(parsed.lots) ? parsed.lots.filter(isLot).map(normalizeLot).slice(0, 40) : [],
      fills: Array.isArray(parsed.fills) ? parsed.fills.filter(isFill).slice(0, 200) : [],
      wallets: Array.isArray(parsed.wallets) ? parsed.wallets.filter(isWallet).map(normalizeWallet).slice(0, 12) : [],
      copySize: Math.min(5000, Math.max(5, num(parsed.copySize, 100))),
      seen: Array.isArray(parsed.seen) ? parsed.seen.filter((item) => typeof item === "string").slice(0, 300) : [],
      equity: Array.isArray(parsed.equity) ? parsed.equity.filter(isPoint).slice(-180) : [],
      alerts: Array.isArray(parsed.alerts) ? parsed.alerts.filter(isAlert).slice(0, 24) : [],
      alerted: Array.isArray(parsed.alerted) ? parsed.alerted.filter((item) => typeof item === "string").slice(0, 400) : [],
      sound: parsed.sound === true,
    };
  } catch {
    return emptyBook();
  }
}

function isLot(value: unknown): value is Lot {
  if (!value || typeof value !== "object") return false;
  const row = value as Lot;
  return typeof row.tokenId === "string" && typeof row.symbol === "string" && num(row.qty) > 0;
}

function normalizeLot(row: Lot): Lot {
  return {
    tokenId: row.tokenId,
    symbol: row.symbol,
    name: typeof row.name === "string" ? row.name : row.symbol,
    address: typeof row.address === "string" ? row.address : "",
    chain: typeof row.chain === "string" ? row.chain : "",
    qty: num(row.qty),
    cost: num(row.cost),
    tpPct: optionalPct(row.tpPct),
    slPct: optionalPct(row.slPct),
  };
}

function isFill(value: unknown): value is Fill {
  if (!value || typeof value !== "object") return false;
  const row = value as Fill;
  return typeof row.id === "string" && (row.side === "buy" || row.side === "sell") && typeof row.symbol === "string";
}

function isWallet(value: unknown): value is WalletWatch {
  if (!value || typeof value !== "object") return false;
  const row = value as WalletWatch;
  return typeof row.address === "string" && row.address.length >= 32;
}

function normalizeWallet(row: WalletWatch): WalletWatch {
  return {
    address: row.address,
    label: typeof row.label === "string" ? row.label : "Wallet",
    copy: row.copy === true,
    filter: normalizeFilter(row.filter),
  };
}

function isPoint(value: unknown): value is EquityPoint {
  if (!value || typeof value !== "object") return false;
  const row = value as EquityPoint;
  return num(row.t) > 0 && Number.isFinite(num(row.v));
}

function isAlert(value: unknown): value is PriceAlert {
  if (!value || typeof value !== "object") return false;
  const row = value as PriceAlert;
  return typeof row.id === "string" && typeof row.tokenId === "string" && num(row.target) > 0;
}

function id() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function checkSafety(token: Pick<Token, "liquidity" | "marketCap" | "created" | "buys24" | "sells24" | "chain">, rug: RugReport | null): Safety {
  const reasons: string[] = [];
  if (rug?.label === "Bad") reasons.push("Rug check is Bad");
  else if (rug?.label === "Risky") reasons.push("Rug check is Risky");
  if (rug?.mintOn) reasons.push("Mint authority is still on");
  const top = rug?.holders[0]?.pct ?? 0;
  if (top >= 60) reasons.push(`Top holder owns ${top.toFixed(0)}%`);
  if (token.liquidity > 0 && token.liquidity < 200) reasons.push("Pool is tiny");
  return { level: "ok", reasons: [...new Set(reasons)].slice(0, 3) };
}

export function copyPasses(filter: CopyFilter, buy: Pick<CopiedBuy, "symbol" | "address" | "marketCap" | "liquidity" | "created">) {
  if (filter.minMcap > 0 && buy.marketCap < filter.minMcap) return false;
  if (filter.minLiq > 0 && buy.liquidity < filter.minLiq) return false;
  if (filter.maxAgeH > 0 && buy.created) {
    const age = (Date.now() - buy.created) / 3_600_000;
    if (age > filter.maxAgeH) return false;
  }
  const banned = filter.blacklist
    .toLowerCase()
    .split(/[,\s]+/)
    .map((item) => item.trim())
    .filter(Boolean);
  const symbol = buy.symbol.toLowerCase();
  const address = buy.address.toLowerCase();
  if (banned.some((item) => item === symbol || item === address)) return false;
  return true;
}

export function paperBuy(book: Book, token: Token, usd: number, source: Fill["source"]): { book: Book; error?: string } {
  const spend = Math.round(usd * 100) / 100;
  if (!(spend >= 5)) return { book, error: "Minimum paper buy is $5" };
  if (spend > book.cash + 0.001) return { book, error: "Not enough paper cash" };
  if (!(token.price > 0)) return { book, error: "No price for that coin" };
  const qty = spend / token.price;
  const lot = book.lots.find((item) => item.tokenId === token.id);
  const lots = lot
    ? book.lots.map((item) => (item.tokenId === token.id ? { ...item, qty: item.qty + qty, cost: item.cost + spend } : item))
    : [
        ...book.lots,
        {
          tokenId: token.id,
          symbol: token.symbol,
          name: token.name,
          address: token.address,
          chain: token.chain,
          qty,
          cost: spend,
          tpPct: null,
          slPct: null,
        },
      ];
  const fill: Fill = {
    id: id(),
    time: Date.now(),
    side: "buy",
    tokenId: token.id,
    symbol: token.symbol,
    name: token.name,
    address: token.address,
    chain: token.chain,
    price: token.price,
    usd: spend,
    qty,
    pnl: 0,
    source,
  };
  return { book: { ...book, cash: book.cash - spend, lots, fills: [fill, ...book.fills].slice(0, 200) } };
}

export function paperSell(
  book: Book,
  tokenId: string,
  fraction: number,
  mark: number,
  source: Fill["source"] = "quick",
): { book: Book; error?: string } {
  const lot = book.lots.find((item) => item.tokenId === tokenId);
  if (!lot) return { book, error: "You don't hold that coin" };
  if (!(mark > 0)) return { book, error: "No price to sell at" };
  const part = fraction >= 0.999 ? 1 : fraction;
  const qty = lot.qty * part;
  const cost = lot.cost * part;
  const proceeds = qty * mark;
  const pnl = proceeds - cost;
  const lots =
    part >= 0.999
      ? book.lots.filter((item) => item.tokenId !== tokenId)
      : book.lots.map((item) =>
          item.tokenId === tokenId ? { ...item, qty: item.qty - qty, cost: item.cost - cost, tpPct: item.tpPct, slPct: item.slPct } : item,
        );
  const fill: Fill = {
    id: id(),
    time: Date.now(),
    side: "sell",
    tokenId,
    symbol: lot.symbol,
    name: lot.name,
    address: lot.address,
    chain: lot.chain,
    price: mark,
    usd: proceeds,
    qty,
    pnl,
    source,
  };
  return { book: { ...book, cash: book.cash + proceeds, lots, fills: [fill, ...book.fills].slice(0, 200) } };
}

export function setStops(book: Book, tokenId: string, tpPct: number | null, slPct: number | null): Book {
  return {
    ...book,
    lots: book.lots.map((lot) => (lot.tokenId === tokenId ? { ...lot, tpPct: optionalPct(tpPct), slPct: optionalPct(slPct) } : lot)),
  };
}

export function armAlert(book: Book, token: Pick<Token, "id" | "symbol" | "price">, target: number): Book {
  if (!(target > 0)) return book;
  const row: PriceAlert = {
    id: id(),
    tokenId: token.id,
    symbol: token.symbol,
    target,
    above: target >= token.price,
    fired: false,
  };
  const alerts = [row, ...book.alerts.filter((alert) => !(alert.tokenId === token.id && !alert.fired && alert.target === target))].slice(0, 24);
  return { ...book, alerts };
}

export function applyCopies(book: Book, buys: CopiedBuy[], allow: (buy: CopiedBuy) => boolean): Book {
  let next = book;
  for (const buy of buys) {
    if (next.seen.includes(buy.id)) continue;
    const seen = [buy.id, ...next.seen].slice(0, 300);
    next = { ...next, seen };
    if (!(buy.price > 0) || !allow(buy)) continue;
    const token: Token = {
      id: `${buy.chain}:${buy.address}`,
      chain: buy.chain,
      address: buy.address,
      pair: "",
      symbol: buy.symbol,
      name: buy.name,
      price: buy.price,
      change: { m5: 0, h1: 0, h6: 0, h24: 0 },
      volume: 0,
      liquidity: buy.liquidity,
      marketCap: buy.marketCap,
      url: "",
      dex: "",
      created: buy.created,
      buys24: 0,
      sells24: 0,
    };
    const spend = buy.size && buy.size >= 5 ? buy.size : next.copySize;
    const bought = paperBuy(next, token, spend, "wallet");
    if (!bought.error) next = { ...bought.book, seen };
  }
  return next;
}

export function summarize(book: Book, mark: (tokenId: string) => number) {
  let market = 0;
  let cost = 0;
  for (const lot of book.lots) {
    const px = mark(lot.tokenId);
    market += lot.qty * (px > 0 ? px : 0);
    cost += lot.cost;
  }
  const realized = book.fills.reduce((sum, fill) => sum + (fill.pnl || 0), 0);
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const today = book.fills.filter((fill) => fill.time >= start.getTime()).reduce((sum, fill) => sum + (fill.pnl || 0), 0);
  const sells = book.fills.filter((fill) => fill.side === "sell");
  const wins = sells.filter((fill) => fill.pnl > 0).length;
  const byDay = new Map<string, number>();
  for (const fill of book.fills) {
    if (!fill.pnl) continue;
    const date = new Date(fill.time);
    const key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
    byDay.set(key, (byDay.get(key) ?? 0) + fill.pnl);
  }
  return {
    equity: book.cash + market,
    market,
    unrealized: market - cost,
    realized,
    today,
    wins,
    sells: sells.length,
    byDay,
  };
}

export function asToken(buy: CopiedBuy): Token {
  return {
    id: `${buy.chain}:${buy.address}`,
    chain: buy.chain,
    address: buy.address,
    pair: "",
    symbol: buy.symbol,
    name: buy.name,
    price: buy.price,
    change: { m5: 0, h1: 0, h6: 0, h24: 0 },
    volume: 0,
    liquidity: buy.liquidity,
    marketCap: buy.marketCap,
    url: "",
    dex: "",
    created: buy.created,
    buys24: 0,
    sells24: 0,
  };
}
