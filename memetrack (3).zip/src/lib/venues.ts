import type { Token } from "@/lib/market";

export type VenueId = "axiom" | "pump" | "fomo";

export const VENUES: { id: VenueId; label: string; blurb: string }[] = [
  { id: "axiom", label: "Axiom", blurb: "Terminal with charts, filters, and limit orders" },
  { id: "pump", label: "Pump", blurb: "Launchpad buys, especially fresh Solana coins" },
  { id: "fomo", label: "Fomo", blurb: "Social feed and one-tap buys" },
];

export function venueLabel(id: VenueId) {
  return VENUES.find((venue) => venue.id === id)?.label ?? "Axiom";
}

export function isVenueId(value: string): value is VenueId {
  return value === "axiom" || value === "pump" || value === "fomo";
}

export function buyUrl(venue: VenueId, token: Pick<Token, "chain" | "address" | "url">) {
  const mint = encodeURIComponent(token.address);
  if (venue === "axiom") {
    return token.chain === "solana" ? `https://axiom.trade/t/${mint}` : token.url;
  }
  if (venue === "pump") {
    return token.chain === "solana" ? `https://pump.fun/coin/${mint}` : token.url;
  }
  return "https://fomo.family";
}
