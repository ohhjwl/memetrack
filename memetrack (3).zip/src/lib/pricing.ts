export const FREE_LEARN_MS = 30 * 60 * 1000;

export type PlanId = "free" | "starter" | "desk" | "unlimited";
export type TermId = "month" | "quarter" | "half" | "year";

export type Term = { id: TermId; label: string; months: number; off: number };

export const TERMS: Term[] = [
  { id: "month", label: "Monthly", months: 1, off: 0 },
  { id: "quarter", label: "3 months", months: 3, off: 0.1 },
  { id: "half", label: "6 months", months: 6, off: 0.15 },
  { id: "year", label: "Year", months: 12, off: 0.2 },
];

export type Plan = {
  id: Exclude<PlanId, "free">;
  name: string;
  limit: string;
  monthly: number;
  features: string[];
};

export const PLANS: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    limit: "Highly limited",
    monthly: 5,
    features: [
      "Learn stays open after the free 30 minutes",
      "Modules 1–3 and their quizzes",
      "Quiz scores saved on the account",
      "No flashcards",
      "No course paper drills",
      "No retakes and no review log",
    ],
  },
  {
    id: "desk",
    name: "Desk",
    limit: "Limited",
    monthly: 10,
    features: [
      "All 8 modules",
      "Quizzes and flashcards",
      "Course paper drills",
      "Scores stay on the account",
      "A passed quiz stays passed",
      "No session review log",
    ],
  },
  {
    id: "unlimited",
    name: "Unlimited",
    limit: "Everything",
    monthly: 20,
    features: [
      "Full course, cards, and drills",
      "Session review log",
      "Retake any quiz",
      "Paper, rug check, and the tape stay free",
    ],
  },
];

export function isPlanId(value: string): value is PlanId {
  return value === "free" || value === "starter" || value === "desk" || value === "unlimited";
}

export function isTermId(value: string): value is TermId {
  return TERMS.some((term) => term.id === value);
}

export function effectivePlan(plan: string, grant: boolean): PlanId {
  if (grant) return "unlimited";
  return isPlanId(plan) ? plan : "free";
}

export function learnOpen(plan: PlanId, usedMs: number) {
  if (plan !== "free") return true;
  return usedMs < FREE_LEARN_MS;
}

export function periodPrice(monthly: number, term: Term) {
  return Math.round(monthly * term.months * (1 - term.off) * 100) / 100;
}

export function moneyExact(value: number) {
  return Number.isInteger(value) ? `$${value}` : `$${value.toFixed(2)}`;
}

export function clock(ms: number) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}
