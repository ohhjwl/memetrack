import type { Token } from "@/lib/market";

/** Historical pump.fun graduation is about $69k market cap. Shown as an estimate, not a curve reading. */
export const PUMP_GRAD_MCAP = 69_000;

export function bondingEstimate(token: Pick<Token, "chain" | "dex" | "marketCap">) {
  if (token.chain !== "solana" || token.dex !== "pumpfun" || !(token.marketCap > 0)) return null;
  return Math.max(0, Math.min(100, (token.marketCap / PUMP_GRAD_MCAP) * 100));
}

export type PulseColumn = { id: string; title: string; note: string; rows: Token[] };

export function pulseColumns(tokens: Token[]): PulseColumn[] {
  const now = Date.now();
  const sol = tokens.filter((token) => token.chain === "solana");
  const fresh = sol
    .filter((token) => token.created && now - token.created < 6 * 60 * 60 * 1000)
    .sort((a, b) => (b.created ?? 0) - (a.created ?? 0));
  const newest = [...sol].sort((a, b) => (b.created ?? 0) - (a.created ?? 0)).slice(0, 8);
  const almost = sol.filter((token) => token.dex === "pumpfun" && token.marketCap >= 40_000 && token.marketCap < PUMP_GRAD_MCAP);
  const graduated = sol
    .filter((token) => token.dex !== "pumpfun" && token.marketCap >= PUMP_GRAD_MCAP && token.created && now - token.created < 72 * 60 * 60 * 1000)
    .sort((a, b) => (b.created ?? 0) - (a.created ?? 0));
  return [
    {
      id: "new",
      title: "New",
      note: fresh.length ? "Created in the last 6 hours." : "No 6-hour launches in this feed. Showing the newest instead. Brand-new mints also hit the tape.",
      rows: (fresh.length ? fresh : newest).slice(0, 12),
    },
    {
      id: "bond",
      title: "Almost bonded",
      note: "Pump.fun pools from $40k to $69k. The percent is market cap over $69k, not a live curve.",
      rows: almost.slice(0, 12),
    },
    {
      id: "grad",
      title: "Graduated",
      note: "Left pump.fun, above about $69k, and under 3 days old. Approximate.",
      rows: graduated.slice(0, 12),
    },
  ];
}
