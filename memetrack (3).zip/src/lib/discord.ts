export const DISCORD_INVITE = "https://discord.gg/xbZUNUPkE";
