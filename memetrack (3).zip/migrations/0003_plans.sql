alter table profiles add column if not exists plan text not null default 'free';
alter table profiles add column if not exists learn_used_ms integer not null default 0;
alter table profiles add column if not exists requested_plan text not null default '';
alter table profiles add column if not exists requested_term text not null default '';
