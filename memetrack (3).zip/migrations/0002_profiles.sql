create table if not exists profiles (
  user_id text primary key,
  handle text not null default '',
  bio text not null default '',
  role text not null default 'member',
  banned boolean not null default false,
  learn_grant boolean not null default false,
  trial_started_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists learn_progress (
  user_id text not null,
  item_id text not null,
  score integer not null default 0,
  primary key (user_id, item_id)
);

create index if not exists learn_progress_user_idx on learn_progress (user_id);
