alter table profiles add column if not exists discord_joined boolean not null default false;

-- Accounts that already existed before this rule do not have to join again.
update profiles set discord_joined = true;
